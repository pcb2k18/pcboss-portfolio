# Vision-Based Plant Health Assessment

Portfolio case study for https://pcboss.me. Live Groq inference: not verified (see Verification status). A public live demo is not hosted, due to API access limits. Visitors can run the code locally with their own Groq key.

## Summary

A small web application that accepts a plant leaf photo and returns a cautious, structured first look at visible symptoms, possible severity, and general care steps. It uses a pretrained vision-language model through the Groq API. No model was trained or fine-tuned.

## Problem

Plant owners often notice spots, yellowing, or wilting but do not know how to describe what they see or what to check next. A photo-based first look can help a user organise observations, while clearly stating that the result is not a diagnosis.

## Solution

- Streamlit interface for upload, context, and readable results.
- FastAPI backend with `GET /health` and `POST /assess`.
- Groq vision model `qwen/qwen3.8-27b` (set by environment variable, checked against Groq docs on 2026-10-20).
- Structured JSON prompt that requires uncertainty language and plain symptom descriptions.
- Demo mode with fixed mock output, so the app can be tested with no key and no external call.

## My role and independence

I inspected the reference repository at https://github.com/shukur-alom/leaf-diseases-detect (MIT License) for its concept, dependencies, and API approach. I then wrote this application independently. No code, images, or text were copied. The reference example model had been retired by Groq, so I selected a currently supported vision model from the official Groq documentation.

## Key design choices

- Safety first wording: every screen and API response repeats that results are model-generated and not verified diagnoses.
- Validation before inference: file type, readability, size limit, and dimension checks run before any API call.
- Secrets by environment only: the Groq key is read from `.env` or environment variables and is never in source code.
- Mock and live results are labelled by a `source` field (`mock` or `live`) in both the API and the interface.
- Minimal stack: FastAPI, Streamlit, Pillow, Pydantic, and the Groq SDK. No database and no custom model.

## Pretrained model, not a model trained by me

This system does not train, fine-tune, or evaluate a custom model. It calls a pretrained vision-language model hosted by Groq. My work was the application around that model: image validation, prompt design, API integration, response parsing, user interface, safety wording, and tests. No training data was collected and no model weights were created or modified.

## Groq model and API integration

- Provider: Groq, using its OpenAI-compatible chat completions API through the official `groq` Python SDK.
- Default model: `qwen/qwen3.8-27b`, read from the `GROQ_MODEL` environment variable so it can be changed without code edits. The name was checked against the Groq vision documentation on 2026-10-20.
- Request: the validated image is encoded as a base64 data URL and sent as an `image_url` content part, together with a system prompt and a user prompt that ask for JSON only, plain symptom descriptions, and uncertainty language. Temperature is 0.2 and the completion limit is 1024 tokens.
- Response: the reply is parsed as JSON, with a fallback that keeps the raw text as a low confidence summary when the reply is not valid JSON. Results are returned in a fixed schema with a `source` field set to `mock` or `live`.
- Key handling: the key is read only from the `GROQ_API_KEY` environment variable or a local `.env` file. It is never stored in source code, and upstream error details are not shown to users.
- Endpoints: `GET /health` reports status, model name, whether a key is configured, and the image size limit. `POST /assess` validates the upload, then returns either mock output or a live model response.

## Verification status (checked 2026-10-20)

Demonstrated and verified locally:

- FastAPI health endpoint returned status ok, model `qwen/qwen3.8-27b`, key configured: false, and a 5 MB limit.
- Mock assessment over HTTP returned `source: mock` with correct image details for a sample PNG (640 by 480, 7657 bytes). No image was sent to a model in this test.
- Streamlit interface loaded in a real browser and showed the upload flow, demo and live mode choices, model name, and disclaimer.
- Automated tests: 13 passed. The suite uses mocked responses and a fake Groq client, and covers validation, mock labelling, missing key handling, request shape, JSON parsing fallbacks, and both API endpoints.

Not verified:

- Actual live vision inference did not succeed in this check, because no Groq API key was configured on this machine (no `.env` file and no `GROQ_API_KEY` in the environment). Live mode correctly returned HTTP 503 with a message explaining that the key is not set. No live result is claimed anywhere in this case study.
- Disease identification accuracy is unverified. No labelled test set was used, no accuracy figure exists for this project, and none should be quoted. Mock output and any future live output are demonstrations of the software flow, not evidence that the model identifies plant disease correctly.

To verify live mode, the owner needs to add a personal Groq key to `.env`, restart the API, and run one live assessment. That step was not done here, and no key was requested, stored, or printed during this work.

## Screenshots

Genuine screenshots of the running application are stored in `outputs/screenshots/`:

- `app-home.png`: the Streamlit interface as served locally, showing demo mode selected, the upload control, the model name, and the disclaimer.
- `api-docs.png`: the FastAPI documentation page showing the `/health` and `/assess` endpoints.

Earlier generated fallback preview images have been removed and are not used in this case study. No screenshot shows a live model result, because live inference was not verified. Any future demo result screenshot must be labelled as mock output.

## Limitations

- The model can hallucinate disease names and can miss real problems.
- A single photo is weak evidence. Light, blur, and background affect results.
- Similar symptoms can come from disease, pests, watering, light, or nutrients.
- Severity is a rough visual guess, not a measurement.
- Synthetic sample images are drawings for upload testing, not real disease examples.
- Live mode sends images to a third party API, which has privacy and cost implications.
- Hosted model names change over time and must be rechecked before any public demo.

## Privacy considerations

- In live mode, the uploaded image and any context text are sent to Groq for processing by a third party. Users should not upload images they do not want processed outside their own computer.
- Demo mode sends nothing to any model or external service.
- Uploads are validated in memory and are not saved to disk by the API.
- The API key stays in environment variables or a local `.env` file, is excluded from the source ZIP, and is never shown in responses or screenshots.
- No account system, database, or image archive exists in this project, so there is no stored collection of user images to protect or delete.
- A public deployment would need a clear privacy notice, rate limits, and cost controls before accepting uploads from other people. That deployment has not been done.

## What I learned

- Vision-language models are easy to call but hard to present responsibly in a health-related context.
- Prompt constraints and response parsing matter as much as the model choice.
- Clear mock versus live labelling protects both users and portfolio readers from overstated claims.
- Checking provider deprecation pages is essential, because example code in older repositories may name retired models.

## Future work (not started)

- Owner-verified live demo with a small set of real, permission-cleared leaf photos.
- Side by side photo guidance and a retake checklist for poor images.
- Human review comparison on a small labelled set, reported honestly with error rates.
- Deployment only after a privacy note, rate limits, and key management are in place.

## Claim check

- Trained or fine-tuned a model: No.
- Pretrained model used through an API: Yes, Groq `qwen/qwen3.8-27b`.
- Live vision inference verified: No. No key was configured, and live mode returned HTTP 503 as designed.
- Verified diagnostic accuracy: No, and no accuracy figure should be quoted for this project.
- Demonstrated functionality: image validation, mock assessment flow, API endpoints, Streamlit interface, and 13 passing automated tests.
- Public live demo hosted: No. The code can be run locally with the visitor's own Groq key.
