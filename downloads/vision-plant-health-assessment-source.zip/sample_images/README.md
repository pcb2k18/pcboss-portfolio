# Sample images

All images in this folder are synthetic drawings created for this project with the script `scripts/generate_samples.py`.

## Files

- `synthetic_healthy_leaf.png`: a simple green leaf drawing with no spots.
- `synthetic_leaf_with_spots.png`: a leaf drawing with added brown spots, for testing the upload flow.
- `synthetic_yellowing_leaf.png`: a leaf drawing with yellow tones, for testing the upload flow.

## Permissions

These images were created by the project author using Pillow. They are released under the same MIT licence as this project. You may use them for testing and education.

## Limits

They are not photos. They are not examples of real plant disease. A model reply about these drawings is a software test only, not evidence about real plants.
