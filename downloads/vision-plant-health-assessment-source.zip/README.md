# Vision-Based Plant Health Assessment

A simple portfolio application that lets a user upload a plant leaf image and receive a cautious, model-generated first look at visible symptoms, possible severity, and general care steps.

This project uses a pretrained vision-language model through the Groq API. No model was trained or fine-tuned for this project.

Portfolio case study: https://pcboss.me/projects/vision-plant-health-assessment/

## Important notice

This app does not diagnose plant disease. Every result is a model-generated assessment, not a scientifically verified diagnosis. Models can hallucinate, miss problems, or name the wrong problem. Confirm any concern with a qualified plant specialist, a local extension service, or a lab test before treating a plant.

## What it does

- Upload a JPG, PNG, or WEBP leaf image (default limit 5 MB, configurable up to 20 MB).
- Add optional context such as plant type, location, and recent care.
- Receive a structured result with:
  - potential issue, stated with uncertainty
  - visible symptom descriptions
  - possible severity and the reason for that rating
  - general plant care recommendations
  - suggested next steps
- Demo mode shows fixed mock output with no API key and no image sent to any model.
- Live mode sends the image to Groq through a FastAPI backend.

## Model and API

- Provider: Groq API (OpenAI-compatible chat completions endpoint)
- Default model: `qwen/qwen3.8-27b`
- Why this model: Groq vision documentation listed it as a supported vision model on 2026-10-20. It accepts text and image inputs.
- Note on the reference project: its example model, `meta-llama/llama-4-scout-17b-16e-instruct`, was retired by Groq on 2026-07-17, so it is not used here.
- The model name is set by the `GROQ_MODEL` environment variable, so it can be changed without editing code.

Sources checked on 2026-10-20:

- Groq vision docs: https://console.groq.com/docs/vision
- Groq deprecations: https://console.groq.com/docs/deprecations
- Reference repository: https://github.com/shukur-alom/leaf-diseases-detect

## Reference repository and licence

The reference repository (MIT License, copyright 2025 Leaf Disease Detection System) was inspected for its idea, stack, dependencies, and API approach. This project was written independently. No source code, images, or text were copied from it. Only the general concept (FastAPI plus Streamlit plus a Groq vision model) was reused, which is also the stack requested for this project.

See `LICENSE` for this project's MIT licence.

## Project structure

```text
api.py                  FastAPI backend: GET /health, POST /assess
app.py                  Streamlit interface
src/
  config.py             Environment settings and disclaimer text
  validation.py         Image type, size, and dimension checks
  prompts.py            Cautious prompt that asks for JSON only
  service.py            Groq client, mock mode, and response parsing
  schemas.py            Pydantic response models
tests/                  Automated tests with mocked model responses
sample_images/          Synthetic test images (see sample_images/README.md)
scripts/                Sample image helper script
outputs/
  portfolio-case-study.md
  screenshots/
```

## Run it locally

You need Python 3.11 or later. Live mode also needs your own Groq API key. Demo mode needs no key.

1. Unzip the source code, then open a terminal in the project folder.
2. Create and activate a virtual environment:

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

macOS or Linux:

```bash
source .venv/bin/activate
```

3. Install the dependencies:

```bash
pip install -r requirements.txt
```

4. For live mode only, copy the example settings file and add your own key. Skip this step if you only want demo mode.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS or Linux:

```bash
cp .env.example .env
```

Open `.env` and replace `your_groq_api_key_here` with your key from https://console.groq.com. Never commit `.env` and never share your key.

5. In the first terminal, start the API:

```bash
uvicorn api:app --reload --port 8000
```

6. In a second terminal, with the virtual environment active, start the interface:

```bash
streamlit run app.py
```

7. Open the local Streamlit address shown in the terminal, usually http://localhost:8501.

- Choose Demo mode to try the full flow with mock output. No key is needed and no image is sent to a model.
- Choose Live API mode only after the API is running and `GROQ_API_KEY` is set in `.env`. In live mode your image is sent to Groq for processing.

Health check: http://127.0.0.1:8000/health and API docs: http://127.0.0.1:8000/docs

## Test images

The `sample_images` folder contains three synthetic leaf drawings created with `scripts/generate_samples.py`. They are original to this project and released under the project MIT licence. They test the upload flow only. They are not photos and not evidence of real disease.

To regenerate them:

```bash
python scripts/generate_samples.py
```

## Tests

Tests use mocked model responses. They do not call Groq and do not need a key.

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

Coverage includes image validation, mock mode labelling, missing key handling, a fake Groq client that checks the request shape, JSON parsing fallbacks, and FastAPI tests for `/health` and `/assess`.

A live inference test is not part of the automated suite. To verify live mode manually, set a real key in `.env`, start both services, and upload a sample image in Live API mode. Record the date, model name, and result in the case study.

## Screenshots

Genuine screenshots of the running application are stored in `outputs/screenshots/`: `app-home.png` (Streamlit interface) and `api-docs.png` (FastAPI docs). Earlier generated fallback preview images have been removed. The app was also verified over HTTP (API health, mock assess, and Streamlit status 200). No screenshot shows a live model result, because live inference was not verified in the final check on 2026-10-20: no Groq key was configured, and live mode returned HTTP 503 as designed. Mock output is never presented as live inference.

## Downloadable ZIP

A ZIP of the source code (without `.env`, keys, or caches) is stored at `outputs/vision-plant-health-assessment-source.zip` when generated. You can rebuild it by zipping the project folder and excluding `.env`, `.venv`, `__pycache__`, and `.pytest_cache`.

## Limitations

- The model can hallucinate. It may invent a disease name, miss a real problem, or sound sure when it is not.
- One photo is weak evidence. Lighting, blur, background, and leaf angle change the result.
- Many plant problems look alike. Nutrient issues, pests, watering problems, and disease can share symptoms.
- The app cannot identify pathogens, check the roots or soil, or use lab methods.
- Severity is a rough visual guess. It is not a measurement.
- The synthetic sample images are drawings, so model replies about them prove nothing about real plants.
- Groq model availability changes. If the default model is retired, set `GROQ_MODEL` to a currently supported vision model from the Groq docs.
- Advice is general care only. It does not replace local advice, product labels, or legal rules on plant treatments in your area.
- Images are sent to Groq in live mode. Do not upload private images you do not want processed by a third party API.

## Security and privacy notes

- The API key is read only from environment variables or `.env`.
- `.env` is listed in `.gitignore`.
- Uploads are validated in memory and are not saved to disk by the API.
- Errors shown to users do not include the API key or full upstream error bodies.

## Portfolio use

This project is part of an academic portfolio at https://pcboss.me. The application itself is not hosted there. See `outputs/portfolio-case-study.md` for the full case study.
