from fastapi import FastAPI, File, Form, HTTPException, UploadFile

from src.config import get_settings
from src.schemas import AssessmentResponse
from src.service import MissingApiKeyError, UpstreamModelError, assess_image
from src.validation import ImageValidationError

app = FastAPI(title="Vision-Based Plant Health Assessment", version="1.0.0")


@app.get("/health")
def health() -> dict:
    settings = get_settings()
    return {
        "status": "ok",
        "model": settings.model,
        "groq_key_configured": bool(settings.groq_api_key),
        "max_image_mb": settings.max_image_mb,
        "note": "Model-generated assessments are not verified diagnoses.",
    }


@app.post("/assess", response_model=AssessmentResponse)
async def assess(
    file: UploadFile = File(...),
    context: str = Form(default=""),
    mock: bool = Form(default=False),
) -> AssessmentResponse:
    settings = get_settings()
    data = await file.read(settings.max_image_bytes + 1)
    try:
        return assess_image(data, context=context, mock=mock, settings=settings)
    except ImageValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except MissingApiKeyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except UpstreamModelError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
