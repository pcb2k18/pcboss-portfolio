import os

import requests
import streamlit as st

from src.config import DISCLAIMER, get_settings
from src.service import get_mock_assessment
from src.validation import ImageValidationError, validate_image_bytes

st.set_page_config(page_title="Vision-Based Plant Health Assessment", page_icon="leaf", layout="wide")

settings = get_settings()
API_URL = os.getenv("API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")


def _render(result: dict) -> None:
    a = result.get("assessment", {})
    st.metric("Source", result.get("source", "unknown"))
    st.write(f"**Plant guess:** {a.get('plant_guess', 'Uncertain')}")
    st.write(f"**Health status:** {a.get('health_status', 'Uncertain')}")
    st.write(f"**Potential issue:** {a.get('potential_issue', 'Uncertain')}")
    c1, c2 = st.columns(2)
    c1.metric("Confidence", a.get("confidence", "low"))
    c2.metric("Possible severity", a.get("severity", "uncertain"))
    if a.get("visible_symptoms"):
        st.write("**Visible symptoms**")
        for item in a["visible_symptoms"]:
            st.write(f"- {item}")
    if a.get("severity_rationale"):
        st.write(f"**Why this severity:** {a['severity_rationale']}")
    if a.get("care_recommendations"):
        st.write("**General care recommendations**")
        for item in a["care_recommendations"]:
            st.write(f"- {item}")
    if a.get("next_steps"):
        st.write("**Suggested next steps**")
        for item in a["next_steps"]:
            st.write(f"- {item}")
    if a.get("raw_summary"):
        st.caption(a["raw_summary"])
    st.caption(result.get("disclaimer", DISCLAIMER))

st.title("Vision-Based Plant Health Assessment")
st.caption("Upload a leaf photo for a cautious, model-generated first look. Built for education and portfolio demonstration.")
st.warning(DISCLAIMER)

with st.sidebar:
    st.header("Settings")
    mode = st.radio(
        "Assessment mode",
        ["Demo (mock, no API key needed)", "Live API (needs Groq key)"],
        help="Demo mode returns fixed mock text and never sends your image to a model.",
    )
    api_url = st.text_input("FastAPI base URL", value=API_URL)
    st.write(f"Model: `{settings.model}`")
    st.write(f"Max image size: {settings.max_image_mb} MB")
    st.divider()
    st.subheader("How to use")
    st.write("1. Add a clear leaf photo.")
    st.write("2. Add plant type or recent care notes, if known.")
    st.write("3. Run the assessment and read the uncertainty notes.")
    st.divider()
    st.subheader("Good photos")
    st.write("Use daylight, one leaf in focus, both sides if possible, and no heavy filters.")

demo = mode.startswith("Demo")
left, right = st.columns([1, 1], gap="large")

with left:
    uploaded = st.file_uploader("Upload a plant leaf image", type=["jpg", "jpeg", "png", "webp"])
    context = st.text_area("Optional context", placeholder="Example: tomato plant, kept outdoors, watered daily, spots appeared this week.", height=110)
    run = st.button("Run assessment", type="primary", disabled=uploaded is None, use_container_width=True)
    if uploaded is not None:
        st.image(uploaded.getvalue(), caption="Uploaded image", use_container_width=True)

with right:
    st.subheader("Assessment")
    if uploaded is None:
        st.info("Upload an image to begin. Try the sample images in the sample_images folder.")
        st.markdown(
            "**What you will get**\n\n"
            "- Potential issue, stated with uncertainty\n"
            "- Visible symptoms in plain language\n"
            "- Possible severity and why\n"
            "- General care steps and next steps"
        )
    if run and uploaded is not None:
        data = uploaded.getvalue()
        try:
            image_info = validate_image_bytes(data, settings.max_image_bytes)
        except ImageValidationError as exc:
            st.error(str(exc))
            st.stop()
        if demo:
            result = get_mock_assessment(image_info, model=settings.model).model_dump()
            st.info("Demo mode: this is mocked output. No image was sent to Groq and no live inference ran.")
            _render(result)
        else:
            with st.spinner("Contacting the FastAPI service and Groq model..."):
                try:
                    response = requests.post(
                        f"{api_url.rstrip('/')}/assess",
                        files={"file": (uploaded.name, data, uploaded.type or "image/jpeg")},
                        data={"context": context, "mock": "false"},
                        timeout=90,
                    )
                except requests.RequestException:
                    st.error("Could not reach the FastAPI service. Start it with: uvicorn api:app --reload --port 8000")
                    st.stop()
            if response.status_code != 200:
                try:
                    detail = response.json().get("detail", "Assessment failed.")
                except ValueError:
                    detail = "Assessment failed."
                st.error(detail)
            else:
                st.success("Live model response received. Treat it as unverified guidance only.")
                _render(response.json())
