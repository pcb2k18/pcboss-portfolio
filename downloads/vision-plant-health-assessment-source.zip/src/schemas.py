from pydantic import BaseModel, Field


class Assessment(BaseModel):
    plant_guess: str = "Uncertain"
    health_status: str = "Uncertain"
    potential_issue: str = "Uncertain"
    confidence: str = "low"
    visible_symptoms: list[str] = Field(default_factory=list)
    severity: str = "uncertain"
    severity_rationale: str = ""
    care_recommendations: list[str] = Field(default_factory=list)
    next_steps: list[str] = Field(default_factory=list)
    raw_summary: str = ""


class AssessmentResponse(BaseModel):
    source: str
    model: str
    image: dict
    assessment: Assessment
    disclaimer: str
