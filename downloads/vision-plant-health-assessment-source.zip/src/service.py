import base64
import json
import re

from src.config import DISCLAIMER, Settings, get_settings
from src.prompts import SYSTEM_PROMPT, build_user_prompt
from src.schemas import Assessment, AssessmentResponse
from src.validation import validate_image_bytes

MOCK_ASSESSMENT = Assessment(
    plant_guess="Tomato-like leaf (mock example)",
    health_status="Possible stress or disease signs visible (mock example)",
    potential_issue="Possible leaf spot type problem. This mock text is not a real finding.",
    confidence="low",
    visible_symptoms=[
        "Mock symptom: dark spots on the leaf surface",
        "Mock symptom: yellowing near the leaf edges",
    ],
    severity="moderate",
    severity_rationale="Mock rationale only. In demo mode no image was sent to a model.",
    care_recommendations=[
        "Isolate the plant until a real assessment is confirmed.",
        "Avoid wetting the leaves when watering.",
        "Remove badly affected leaves with clean tools and dispose of them away from other plants.",
        "Improve air flow and spacing around the plant.",
    ],
    next_steps=[
        "Compare with a trusted plant disease guide for your plant type.",
        "Take clear photos of both sides of several leaves.",
        "Contact a local extension service or plant specialist for confirmation.",
    ],
    raw_summary="Model-generated assessment, not a verified diagnosis. This is mocked demo output.",
)


class MissingApiKeyError(RuntimeError):
    pass


class UpstreamModelError(RuntimeError):
    pass


def get_mock_assessment(image_info: dict, model: str = "mock") -> AssessmentResponse:
    return AssessmentResponse(
        source="mock",
        model=model,
        image=image_info,
        assessment=MOCK_ASSESSMENT,
        disclaimer=DISCLAIMER,
    )


def parse_model_text(text: str) -> Assessment:
    if not text or not text.strip():
        raise UpstreamModelError("The model returned an empty response.")
    candidate = text.strip()
    match = re.search(r"\{.*\}", candidate, flags=re.DOTALL)
    if match:
        candidate = match.group(0)
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError:
        return Assessment(
            potential_issue="Uncertain. The model reply could not be structured.",
            confidence="low",
            severity="uncertain",
            severity_rationale="The model reply was not valid JSON, so it is shown as a plain summary.",
            raw_summary=text.strip()[:2000],
        )
    if not isinstance(data, dict):
        raise UpstreamModelError("The model returned an unexpected response shape.")
    for key in ("visible_symptoms", "care_recommendations", "next_steps"):
        value = data.get(key)
        if isinstance(value, str):
            data[key] = [value]
        elif not isinstance(value, list):
            data[key] = []
    if str(data.get("confidence", "low")).lower() not in {"low", "medium", "high"}:
        data["confidence"] = "low"
    if str(data.get("severity", "uncertain")).lower() not in {"none", "low", "moderate", "high", "uncertain"}:
        data["severity"] = "uncertain"
    return Assessment(**{k: v for k, v in data.items() if k in Assessment.model_fields})


def _default_groq_client(settings: Settings):
    try:
        from groq import Groq
    except ImportError as exc:
        raise UpstreamModelError("The groq package is not installed. Run pip install -r requirements.txt.") from exc
    return Groq(api_key=settings.groq_api_key, timeout=settings.timeout_seconds)


def assess_image(
    data: bytes,
    context: str | None = None,
    mock: bool = False,
    settings: Settings | None = None,
    client=None,
) -> AssessmentResponse:
    settings = settings or get_settings()
    image_info = validate_image_bytes(data, settings.max_image_bytes)
    if mock:
        return get_mock_assessment(image_info, model=settings.model)
    if not settings.groq_api_key:
        raise MissingApiKeyError("GROQ_API_KEY is not set. Copy .env.example to .env and add your key, or use demo mode.")
    client = client or _default_groq_client(settings)
    encoded = base64.b64encode(data).decode("utf-8")
    data_url = f"data:{image_info['mime_type']};base64,{encoded}"
    try:
        completion = client.chat.completions.create(
            model=settings.model,
            temperature=0.2,
            max_completion_tokens=1024,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": build_user_prompt(context)},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                },
            ],
        )
        text = completion.choices[0].message.content or ""
    except UpstreamModelError:
        raise
    except Exception as exc:
        raise UpstreamModelError(f"Groq request failed: {type(exc).__name__}. Check the key, model name, quota, and network.") from exc
    return AssessmentResponse(
        source="live",
        model=settings.model,
        image=image_info,
        assessment=parse_model_text(text),
        disclaimer=DISCLAIMER,
    )
