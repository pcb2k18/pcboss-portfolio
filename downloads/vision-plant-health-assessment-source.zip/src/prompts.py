SYSTEM_PROMPT = (
    "You are a cautious plant health assistant. You describe only what is visible in one leaf image. "
    "You do not give a confirmed diagnosis. You state uncertainty clearly. "
    "You avoid prescribing restricted chemicals. You suggest general, low-risk care and professional confirmation."
)

USER_PROMPT = """Assess this plant leaf image for general education only.

Context from the user: {context}

Return valid JSON only, with exactly these keys:
plant_guess, health_status, potential_issue, confidence, visible_symptoms,
severity, severity_rationale, care_recommendations, next_steps, raw_summary

Rules:
- confidence must be one of: low, medium, high
- severity must be one of: none, low, moderate, high, uncertain
- visible_symptoms, care_recommendations, and next_steps must be lists of short strings
- If the image is not a leaf, or is unclear, say so and use confidence low and severity uncertain
- Name at most one main potential issue and mention alternatives inside raw_summary if needed
- Keep care advice general. Do not state a confirmed disease name as a fact
- raw_summary must start with: Model-generated assessment, not a verified diagnosis.
"""


def build_user_prompt(context: str | None) -> str:
    clean = (context or "").strip()[:500] or "No extra context provided."
    return USER_PROMPT.format(context=clean)
