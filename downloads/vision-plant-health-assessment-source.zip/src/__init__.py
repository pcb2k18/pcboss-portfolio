"""Vision-Based Plant Health Assessment package."""
