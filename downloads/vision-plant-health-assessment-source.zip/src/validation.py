import io

from PIL import Image, UnidentifiedImageError

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
MIME_BY_FORMAT = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}
MIN_DIMENSION = 32
MAX_DIMENSION = 8000


class ImageValidationError(ValueError):
    pass


def validate_image_bytes(data: bytes, max_bytes: int) -> dict:
    if not data:
        raise ImageValidationError("No image data was received.")
    if len(data) > max_bytes:
        limit_mb = round(max_bytes / (1024 * 1024), 1)
        raise ImageValidationError(f"Image is too large. Maximum size is {limit_mb} MB.")
    try:
        with Image.open(io.BytesIO(data)) as image:
            image.verify()
        with Image.open(io.BytesIO(data)) as image:
            fmt = (image.format or "").upper()
            width, height = image.size
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ImageValidationError("File is not a readable image. Use JPG, PNG, or WEBP.") from exc
    if fmt not in ALLOWED_FORMATS:
        raise ImageValidationError(f"Unsupported image format: {fmt or 'unknown'}. Use JPG, PNG, or WEBP.")
    if width < MIN_DIMENSION or height < MIN_DIMENSION:
        raise ImageValidationError(f"Image is too small. Minimum size is {MIN_DIMENSION} by {MIN_DIMENSION} pixels.")
    if width > MAX_DIMENSION or height > MAX_DIMENSION:
        raise ImageValidationError(f"Image dimensions are too large. Maximum is {MAX_DIMENSION} pixels per side.")
    return {"format": fmt, "mime_type": MIME_BY_FORMAT[fmt], "width": width, "height": height, "size_bytes": len(data)}
