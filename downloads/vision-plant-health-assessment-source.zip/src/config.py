import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()

DEFAULT_MODEL = "qwen/qwen3.8-27b"
DISCLAIMER = (
    "This is a model-generated assessment, not a scientifically verified diagnosis. "
    "Confirm any concern with a qualified plant specialist, extension service, or lab test."
)


@dataclass(frozen=True)
class Settings:
    groq_api_key: str | None
    model: str
    max_image_mb: int
    timeout_seconds: float

    @property
    def max_image_bytes(self) -> int:
        return self.max_image_mb * 1024 * 1024


def get_settings() -> Settings:
    try:
        max_mb = int(os.getenv("MAX_IMAGE_MB", "5"))
    except ValueError:
        max_mb = 5
    max_mb = min(max(max_mb, 1), 20)
    try:
        timeout = float(os.getenv("GROQ_TIMEOUT_SECONDS", "60"))
    except ValueError:
        timeout = 60.0
    return Settings(
        groq_api_key=os.getenv("GROQ_API_KEY") or None,
        model=os.getenv("GROQ_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL,
        max_image_mb=max_mb,
        timeout_seconds=timeout,
    )
