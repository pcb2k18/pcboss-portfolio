"""Generate synthetic sample leaf images. These are original drawings made with Pillow.

They are not photos of real diseased plants and must not be used as diagnostic evidence.
Run: python scripts/generate_samples.py
"""
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parents[1] / "sample_images"
OUT.mkdir(parents=True, exist_ok=True)


def leaf_base(color=(58, 150, 70)):
    img = Image.new("RGB", (640, 480), (245, 245, 235))
    d = ImageDraw.Draw(img)
    d.ellipse([120, 70, 520, 410], fill=color, outline=(30, 90, 40), width=5)
    d.line([320, 80, 320, 430], fill=(30, 90, 40), width=5)
    for offset in range(-120, 121, 40):
        d.line([320, 240 + offset // 2, 320 + offset, 140 + abs(offset)], fill=(35, 105, 48), width=3)
        d.line([320, 240 + offset // 2, 320 - offset, 340 - abs(offset) // 2], fill=(35, 105, 48), width=3)
    d.line([320, 410, 320, 455], fill=(90, 70, 40), width=8)
    return img, d


def main():
    img, _ = leaf_base()
    img.save(OUT / "synthetic_healthy_leaf.png")

    img, d = leaf_base()
    for x, y, r in [(220, 160, 22), (360, 210, 30), (280, 300, 18), (410, 320, 14)]:
        d.ellipse([x - r, y - r, x + r, y + r], fill=(70, 45, 25), outline=(35, 25, 15), width=3)
        d.ellipse([x - r // 2, y - r // 2, x + r // 2, y + r // 2], fill=(110, 75, 35))
    img.save(OUT / "synthetic_leaf_with_spots.png")

    img, d = leaf_base(color=(150, 175, 60))
    d.ellipse([120, 70, 520, 410], outline=(120, 110, 30), width=14)
    for x, y in [(200, 140), (430, 180), (240, 350), (400, 330)]:
        d.ellipse([x - 18, y - 12, x + 18, y + 12], fill=(205, 190, 70))
    img.save(OUT / "synthetic_yellowing_leaf.png")
    print(f"Wrote 3 synthetic images to {OUT}")


if __name__ == "__main__":
    main()
