import pytest

from src.validation import ImageValidationError, validate_image_bytes
from tests.conftest import make_image_bytes


def test_valid_png(png_bytes):
    info = validate_image_bytes(png_bytes, max_bytes=1024 * 1024)
    assert info["format"] == "PNG"
    assert info["mime_type"] == "image/png"
    assert info["width"] == 64


def test_rejects_empty():
    with pytest.raises(ImageValidationError, match="No image"):
        validate_image_bytes(b"", max_bytes=1024)


def test_rejects_oversize(png_bytes):
    with pytest.raises(ImageValidationError, match="too large"):
        validate_image_bytes(png_bytes, max_bytes=10)


def test_rejects_non_image():
    with pytest.raises(ImageValidationError, match="not a readable image"):
        validate_image_bytes(b"not an image", max_bytes=1024 * 1024)


def test_rejects_tiny_image():
    tiny = make_image_bytes(size=(8, 8))
    with pytest.raises(ImageValidationError, match="too small"):
        validate_image_bytes(tiny, max_bytes=1024 * 1024)
