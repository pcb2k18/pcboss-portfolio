from fastapi.testclient import TestClient

from api import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert "model" in body


def test_assess_mock(png_bytes):
    response = client.post(
        "/assess",
        files={"file": ("leaf.png", png_bytes, "image/png")},
        data={"mock": "true", "context": "test plant"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["source"] == "mock"
    assert body["assessment"]["visible_symptoms"]


def test_assess_rejects_text_file():
    response = client.post(
        "/assess",
        files={"file": ("note.txt", b"hello", "text/plain")},
        data={"mock": "true"},
    )
    assert response.status_code == 400
