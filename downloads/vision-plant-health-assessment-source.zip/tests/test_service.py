import json

import pytest

from src.config import Settings
from src.service import MissingApiKeyError, assess_image, parse_model_text


def settings(with_key=True):
    return Settings(
        groq_api_key="test-key" if with_key else None,
        model="qwen/qwen3.8-27b",
        max_image_mb=5,
        timeout_seconds=10,
    )


def test_mock_mode_is_labelled(png_bytes):
    result = assess_image(png_bytes, mock=True, settings=settings(with_key=False))
    assert result.source == "mock"
    assert "mock" in result.assessment.potential_issue.lower()
    assert "not a scientifically verified diagnosis" in result.disclaimer


def test_missing_key_raises(png_bytes):
    with pytest.raises(MissingApiKeyError):
        assess_image(png_bytes, mock=False, settings=settings(with_key=False))


class FakeMessage:
    def __init__(self, content):
        self.content = content


class FakeChoice:
    def __init__(self, content):
        self.message = FakeMessage(content)


class FakeCompletion:
    def __init__(self, content):
        self.choices = [FakeChoice(content)]


class FakeCompletions:
    def __init__(self, content):
        self.content = content
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return FakeCompletion(self.content)


class FakeChat:
    def __init__(self, content):
        self.completions = FakeCompletions(content)


class FakeClient:
    def __init__(self, content):
        self.chat = FakeChat(content)


def test_live_path_with_fake_client(png_bytes):
    payload = {
        "plant_guess": "Tomato",
        "health_status": "Possible leaf stress",
        "potential_issue": "Possible leaf spot type problem",
        "confidence": "medium",
        "visible_symptoms": ["Dark spots"],
        "severity": "moderate",
        "severity_rationale": "Several spots are visible.",
        "care_recommendations": ["Improve air flow"],
        "next_steps": ["Ask a specialist to confirm"],
        "raw_summary": "Model-generated assessment, not a verified diagnosis. Possible leaf spot.",
    }
    client = FakeClient(json.dumps(payload))
    result = assess_image(png_bytes, context="tomato", settings=settings(), client=client)
    assert result.source == "live"
    assert result.assessment.potential_issue.startswith("Possible leaf spot")
    call = client.chat.completions.calls[0]
    assert call["model"] == "qwen/qwen3.8-27b"
    content = call["messages"][1]["content"]
    assert content[1]["image_url"]["url"].startswith("data:image/png;base64,")


def test_parse_plain_text_fallback():
    parsed = parse_model_text("The leaf looks yellow at the edges.")
    assert parsed.confidence == "low"
    assert parsed.severity == "uncertain"
    assert "yellow" in parsed.raw_summary


def test_parse_invalid_confidence_and_severity():
    parsed = parse_model_text('{"potential_issue": "Possible issue", "confidence": "sure", "severity": "extreme"}')
    assert parsed.confidence == "low"
    assert parsed.severity == "uncertain"
