"""Run the full analysis and write outputs/results.json and figures."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from src.case_study import write_case_study
from src.pipeline import run_analysis


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/raw")
    parser.add_argument("--output-dir", default="outputs")
    parser.add_argument("--max-per-class", type=int, default=15000)
    args = parser.parse_args()
    results = run_analysis(Path(args.data_dir), Path(args.output_dir), max_per_class=args.max_per_class)
    write_case_study(results, Path(args.output_dir) / "portfolio-case-study.md")
    print(json.dumps({"best_model": results["best_model_by_macro_f1"], "full_rows": results["dataset"]["total_records_in_full_csv_files"], "sample_rows": results["modelling_sample"]["rows_after_cleaning_and_dedup"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
