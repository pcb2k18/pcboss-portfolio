# Notices

## Dataset

CICIDS2017 was created by the Canadian Institute for Cybersecurity, University of New Brunswick. Official source: https://www.unb.ca/cic/datasets/ids-2017.html

Publisher statement, as reproduced on the download mirror used here: the CICIDS2017 dataset, including labelled flows and CSV files for machine and deep learning purposes, is publicly available for researchers. Users should cite:

Sharafaldin, I., Lashkari, A. H., and Ghorbani, A. A. (2018). Toward Generating a New Intrusion Detection Dataset and Intrusion Traffic Characterization. 4th International Conference on Information Systems Security and Privacy (ICISSP), Portugal, January 2018.

Raw dataset files are not included in this project distribution.

## Reference repository

Reference consulted for task framing only: https://github.com/Hatem-Elashmawy/network-intrusion-detection-ml

That repository carries the MIT License, Copyright (c) 2026 Hatem Elashmawy, which permits use, copying, modification, and distribution subject to including the copyright and permission notice. This project did not copy code from that repository. It is an independent implementation. No performance figures from that repository are reported here.

## This project

Code in this repository was written for this portfolio project. Third party libraries are used under their own licences: pandas, NumPy, scikit-learn, and Matplotlib.
