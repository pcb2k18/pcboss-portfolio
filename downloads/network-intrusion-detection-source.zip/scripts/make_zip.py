"""Build and verify the downloadable source code ZIP.

Excluded: raw data, CSV and PCAP files, caches, virtual environments,
and the ZIP itself. Included: source, tests, docs, requirements, and the
generated results, case study, and figures.
"""
from __future__ import annotations

import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist" / "network-intrusion-detection-source.zip"
INCLUDE_DIRS = ["src", "tests", "scripts", "outputs"]
INCLUDE_FILES = ["README.md", "NOTICE.md", "requirements.txt", ".gitignore", "run_analysis.py"]
SKIP_PARTS = {"__pycache__", ".pytest_cache", "data"}
SKIP_SUFFIXES = {".pyc", ".csv", ".pcap", ".zip"}


def iter_files() -> list[Path]:
    files: list[Path] = []
    for name in INCLUDE_FILES:
        p = ROOT / name
        if p.exists():
            files.append(p)
    for d in INCLUDE_DIRS:
        base = ROOT / d
        if not base.exists():
            continue
        for p in sorted(base.rglob("*")):
            if p.is_dir():
                continue
            if any(part in SKIP_PARTS for part in p.parts):
                continue
            if p.suffix.lower() in SKIP_SUFFIXES:
                continue
            files.append(p)
    return files


def main() -> int:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    files = iter_files()
    with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            zf.write(p, p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(OUT) as zf:
        bad = zf.testzip()
        names = zf.namelist()
        if bad is not None:
            raise RuntimeError(f"corrupt member in ZIP: {bad}")
        forbidden = [n for n in names if n.startswith("data/") or n.endswith((".csv", ".pcap"))]
        if forbidden:
            raise RuntimeError(f"forbidden files in ZIP: {forbidden}")
    print(f"created {OUT} with {len(files)} files, size {OUT.stat().st_size} bytes")
    for n in names:
        print(f"  {n}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
