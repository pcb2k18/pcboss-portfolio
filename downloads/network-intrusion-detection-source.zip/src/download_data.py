"""Download the CICIDS2017 labelled flow CSV files.

Official source: Canadian Institute for Cybersecurity, University of New
Brunswick, https://www.unb.ca/cic/datasets/ids-2017.html

The official download page requires following the publisher instructions.
The files used here are the same eight MachineLearningCSV files, obtained
from a public mirror that reproduces the publisher licence notice:
https://huggingface.co/datasets/c01dsnap/CIC-IDS2017

Only the labelled flow CSV files are downloaded. PCAP files are not used.
Raw data is stored under data/raw and is excluded from public deliverables.

Citation required by the publisher:
Sharafaldin, I., Lashkari, A. H., and Ghorbani, A. A. (2018). Toward
Generating a New Intrusion Detection Dataset and Intrusion Traffic
Characterization. ICISSP 2018.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import sys
import urllib.request
from pathlib import Path

OFFICIAL_PAGE = "https://www.unb.ca/cic/datasets/ids-2017.html"
MIRROR_BASE = "https://huggingface.co/datasets/c01dsnap/CIC-IDS2017/resolve/main/"

FILES = [
    "Monday-WorkingHours.pcap_ISCX.csv",
    "Tuesday-WorkingHours.pcap_ISCX.csv",
    "Wednesday-workingHours.pcap_ISCX.csv",
    "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",
    "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",
    "Friday-WorkingHours-Morning.pcap_ISCX.csv",
    "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
    "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",
]

# Sizes reported by the mirror at download time. Used only to detect
# truncated downloads, not as a substitute for record level checks.
EXPECTED_BYTES = {
    "Monday-WorkingHours.pcap_ISCX.csv": 176927918,
    "Tuesday-WorkingHours.pcap_ISCX.csv": 135078995,
    "Wednesday-workingHours.pcap_ISCX.csv": 225166395,
    "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv": 52023263,
    "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv": 83102436,
    "Friday-WorkingHours-Morning.pcap_ISCX.csv": 58316725,
    "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv": 76906168,
    "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv": 77123859,
}


def md5_of(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_one(name: str, dest_dir: Path) -> Path:
    dest = dest_dir / name
    expected = EXPECTED_BYTES.get(name)
    if dest.exists() and expected and dest.stat().st_size == expected:
        print(f"skip existing complete file: {name}")
        return dest
    url = MIRROR_BASE + name
    print(f"downloading {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "nids-portfolio/1.0"})
    tmp = dest.with_suffix(dest.suffix + ".part")
    with urllib.request.urlopen(req, timeout=120) as resp, tmp.open("wb") as out:
        shutil.copyfileobj(resp, out, length=1024 * 1024)
    if expected and tmp.stat().st_size != expected:
        raise RuntimeError(
            f"size mismatch for {name}: got {tmp.stat().st_size}, expected {expected}"
        )
    tmp.replace(dest)
    print(f"saved {dest} md5={md5_of(dest)}")
    return dest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="data/raw")
    parser.add_argument("--min-free-gb", type=float, default=3.0)
    args = parser.parse_args()
    dest_dir = Path(args.output_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    free_gb = shutil.disk_usage(dest_dir).free / 1e9
    total_gb = sum(EXPECTED_BYTES.values()) / 1e9
    print(f"free disk GB: {free_gb:.2f}; expected download GB: {total_gb:.2f}")
    print(f"official source: {OFFICIAL_PAGE}")
    if free_gb < total_gb + args.min_free_gb:
        print("Not enough free disk space. Aborting before download.", file=sys.stderr)
        return 2
    for name in FILES:
        download_one(name, dest_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
