"""Network intrusion detection portfolio project."""
