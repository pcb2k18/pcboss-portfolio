"""Independent CICIDS2017 network intrusion detection pipeline.

This code was written for this portfolio project. It does not copy code
from the reference repository. Shared ideas are limited to the general
task, the public dataset, and standard scikit-learn practice.

Design choices:
- Exact duplicate flows are removed before any split.
- Imputation and scaling are fitted inside scikit-learn Pipelines, so
  test data never influences preprocessing statistics.
- A stratified split is the primary evaluation.
- A day based split (train Monday to Thursday, test Friday) is reported
  separately. Attack classes that appear only in the Friday test data
  are reported as unseen in training, not as ordinary errors.
- The modelling sample is capped per class for local hardware. Full
  record counts are still computed from every downloaded file.
"""
from __future__ import annotations

import json
import platform
import re
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

RANDOM_STATE = 42
LABEL_COL = "Label"
DAY_COL = "source_day"
TRUE_IDENTIFIERS = ["Flow ID", "Source IP", "Destination IP", "Timestamp"]

FILE_DAYS = {
    "Monday-WorkingHours.pcap_ISCX.csv": "Monday",
    "Tuesday-WorkingHours.pcap_ISCX.csv": "Tuesday",
    "Wednesday-workingHours.pcap_ISCX.csv": "Wednesday",
    "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv": "Thursday",
    "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv": "Thursday",
    "Friday-WorkingHours-Morning.pcap_ISCX.csv": "Friday",
    "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv": "Friday",
    "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv": "Friday",
}


def normalize_label(value: object) -> str:
    text = str(value).strip()
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\ufffd", "-")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def drop_duplicate_named_columns(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Pandas renames repeated headers with a .1 suffix. Drop those copies."""
    dupes = [c for c in df.columns if re.search(r"\.\d+$", str(c))]
    if dupes:
        df = df.drop(columns=dupes)
    return df, dupes


def summarize_frame(df: pd.DataFrame, feature_cols: list[str]) -> dict:
    numeric = df[feature_cols].apply(pd.to_numeric, errors="coerce")
    return {
        "rows": int(len(df)),
        "missing_values": int(numeric.isna().sum().sum()),
        "infinite_values": int(np.isinf(numeric.to_numpy(dtype=float, na_value=np.nan)).sum()),
    }


def load_file_sample(path: Path, max_per_class: int, stats: dict) -> pd.DataFrame:
    df = pd.read_csv(path, low_memory=False)
    df = clean_columns(df)
    if LABEL_COL not in df.columns:
        raise ValueError(f"Label column missing in {path.name}: {list(df.columns)[:5]}")
    df[LABEL_COL] = df[LABEL_COL].map(normalize_label)
    df, dup_cols = drop_duplicate_named_columns(df)
    feature_cols = [c for c in df.columns if c != LABEL_COL]
    numeric = df[feature_cols].apply(pd.to_numeric, errors="coerce")
    infinite_count = int(np.isinf(numeric.to_numpy(dtype=float, na_value=np.nan)).sum())
    missing_count = int(numeric.isna().sum().sum())
    dup_rows = int(df.duplicated(subset=feature_cols + [LABEL_COL]).sum())
    label_counts = df[LABEL_COL].value_counts()
    stats["files"].append(
        {
            "file": path.name,
            "size_bytes": int(path.stat().st_size),
            "day": FILE_DAYS.get(path.name, "unknown"),
            "rows": int(len(df)),
            "columns_including_label": int(df.shape[1]),
            "duplicate_named_columns_dropped": dup_cols,
            "missing_values_before_cleaning": missing_count,
            "infinite_values_before_cleaning": infinite_count,
            "exact_duplicate_rows_features_and_label": dup_rows,
            "label_counts": {str(k): int(v) for k, v in label_counts.items()},
        }
    )
    for k, v in label_counts.items():
        stats["full_label_counts"][str(k)] = stats["full_label_counts"].get(str(k), 0) + int(v)
    stats["full_rows"] += int(len(df))
    df[DAY_COL] = FILE_DAYS.get(path.name, "unknown")
    df["source_file"] = path.name
    # Stratified cap per class within this file, then a global cap is
    # applied again after concatenation.
    parts = []
    for _, group in df.groupby(LABEL_COL, sort=False):
        if len(group) > max_per_class:
            parts.append(group.sample(n=max_per_class, random_state=RANDOM_STATE))
        else:
            parts.append(group)
    return pd.concat(parts, ignore_index=True) if parts else df.iloc[0:0]


def cap_per_class(df: pd.DataFrame, max_per_class: int) -> pd.DataFrame:
    parts = []
    for _, group in df.groupby(LABEL_COL, sort=False):
        if len(group) > max_per_class:
            parts.append(group.sample(n=max_per_class, random_state=RANDOM_STATE))
        else:
            parts.append(group)
    out = pd.concat(parts, ignore_index=True) if parts else df
    return out.sample(frac=1.0, random_state=RANDOM_STATE).reset_index(drop=True)


def prepare_model_frame(sample: pd.DataFrame) -> tuple[pd.DataFrame, list[str], dict]:
    info: dict = {}
    df = sample.copy()
    dropped_ids = [c for c in TRUE_IDENTIFIERS if c in df.columns]
    if dropped_ids:
        df = df.drop(columns=dropped_ids)
    info["identifier_columns_dropped"] = dropped_ids
    info["identifier_columns_present"] = dropped_ids
    feature_cols = [c for c in df.columns if c not in (LABEL_COL, DAY_COL, "source_file")]
    for c in feature_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df[feature_cols] = df[feature_cols].replace([np.inf, -np.inf], np.nan)
    info["rows_before_dedup"] = int(len(df))
    df = df.dropna(subset=[LABEL_COL]).drop_duplicates(subset=feature_cols, keep="first")
    info["rows_after_feature_dedup"] = int(len(df))
    info["duplicates_removed_in_sample"] = int(info["rows_before_dedup"] - len(df))
    constant = [c for c in feature_cols if df[c].nunique(dropna=True) <= 1]
    all_nan = [c for c in feature_cols if df[c].isna().all()]
    drop_cols = sorted(set(constant + all_nan))
    if drop_cols:
        df = df.drop(columns=drop_cols)
        feature_cols = [c for c in feature_cols if c not in drop_cols]
    info["constant_or_all_missing_columns_dropped"] = drop_cols
    info["feature_count"] = len(feature_cols)
    info["features"] = feature_cols
    info["missing_values_in_sample_after_inf_replacement"] = int(df[feature_cols].isna().sum().sum())
    return df, feature_cols, info


def high_correlation_pairs(df: pd.DataFrame, feature_cols: list[str], limit: int = 10) -> list[dict]:
    corr = df[feature_cols].corr(numeric_only=True).abs()
    pairs = []
    cols = list(corr.columns)
    for i, a in enumerate(cols):
        for b in cols[i + 1 :]:
            v = corr.loc[a, b]
            if pd.notna(v) and v >= 0.95:
                pairs.append({"feature_a": a, "feature_b": b, "abs_correlation": round(float(v), 4)})
    pairs.sort(key=lambda x: x["abs_correlation"], reverse=True)
    return pairs[:limit]


def make_models() -> dict[str, Pipeline]:
    return {
        "RandomForest": Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                (
                    "model",
                    RandomForestClassifier(
                        n_estimators=200,
                        n_jobs=-1,
                        class_weight="balanced_subsample",
                        random_state=RANDOM_STATE,
                    ),
                ),
            ]
        ),
        "DecisionTree": Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                (
                    "model",
                    DecisionTreeClassifier(
                        max_depth=20,
                        min_samples_leaf=2,
                        class_weight="balanced",
                        random_state=RANDOM_STATE,
                    ),
                ),
            ]
        ),
        "LogisticRegression": Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
                (
                    "model",
                    LogisticRegression(
                        max_iter=1000,
                        class_weight="balanced",
                        n_jobs=-1,
                    ),
                ),
            ]
        ),
        "KNeighbors": Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
                ("model", KNeighborsClassifier(n_neighbors=5, n_jobs=-1)),
            ]
        ),
    }


def evaluate_model(name: str, model, X_test, y_test, labels: list[str]) -> dict:
    pred = model.predict(X_test)
    report = classification_report(y_test, pred, labels=labels, output_dict=True, zero_division=0)
    return {
        "model": name,
        "accuracy": float(accuracy_score(y_test, pred)),
        "precision_weighted": float(precision_score(y_test, pred, average="weighted", zero_division=0)),
        "recall_weighted": float(recall_score(y_test, pred, average="weighted", zero_division=0)),
        "f1_weighted": float(f1_score(y_test, pred, average="weighted", zero_division=0)),
        "f1_macro": float(f1_score(y_test, pred, average="macro", zero_division=0)),
        "per_class": {
            str(k): {
                "precision": float(v["precision"]),
                "recall": float(v["recall"]),
                "f1": float(v["f1-score"]),
                "support": int(v["support"]),
            }
            for k, v in report.items()
            if k in labels
        },
        "_predictions": pred,
    }


def save_plot(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches="tight")
    plt.close()


def build_figures(out_dir: Path, full_label_counts: dict, results_models: list[dict], best_name: str, y_test, pred_best, labels: list[str], rf_importance: list[dict], df: pd.DataFrame, feature_cols: list[str]) -> list[str]:
    figures: list[str] = []
    benign = full_label_counts.get("BENIGN", 0)
    malicious = sum(v for k, v in full_label_counts.items() if k != "BENIGN")

    plt.figure(figsize=(7, 4))
    plt.bar(["BENIGN", "Malicious"], [benign, malicious], color=["#2e7d32", "#c62828"])
    plt.ylabel("Flows (full files)")
    plt.title("Benign versus malicious traffic, full CICIDS2017 CSV files")
    for i, v in enumerate([benign, malicious]):
        plt.text(i, v, f"{v:,}", ha="center", va="bottom", fontsize=8)
    p = out_dir / "benign_vs_malicious.png"
    save_plot(p); figures.append(p.name)

    attacks = {k: v for k, v in full_label_counts.items() if k != "BENIGN"}
    attacks = dict(sorted(attacks.items(), key=lambda x: x[1]))
    plt.figure(figsize=(9, 5))
    plt.barh(list(attacks.keys()), list(attacks.values()), color="#455a64")
    plt.xscale("log")
    plt.xlabel("Flows, log scale")
    plt.title("Attack category distribution, full files")
    p = out_dir / "attack_category_distribution.png"
    save_plot(p); figures.append(p.name)

    # Feature patterns: standardized mean difference, benign minus malicious.
    work = df.copy()
    work["is_benign"] = (work[LABEL_COL] == "BENIGN").astype(int)
    diffs = []
    for c in feature_cols:
        b = work.loc[work["is_benign"] == 1, c]
        m = work.loc[work["is_benign"] == 0, c]
        pooled = work[c].std()
        if pooled and not pd.isna(pooled) and pooled > 0:
            diffs.append((c, float((b.mean() - m.mean()) / pooled)))
    diffs = sorted(diffs, key=lambda x: abs(x[1]), reverse=True)[:10]
    plt.figure(figsize=(9, 5))
    plt.barh([d[0] for d in diffs], [d[1] for d in diffs], color="#6a1b9a")
    plt.xlabel("Standardized mean difference, benign minus malicious")
    plt.title("Network flow feature patterns in the modelling sample")
    p = out_dir / "feature_patterns.png"
    save_plot(p); figures.append(p.name)

    names = [r["model"] for r in results_models]
    plt.figure(figsize=(9, 5))
    x = np.arange(len(names)); w = 0.25
    plt.bar(x - w, [r["accuracy"] for r in results_models], width=w, label="Accuracy")
    plt.bar(x, [r["f1_weighted"] for r in results_models], width=w, label="Weighted F1")
    plt.bar(x + w, [r["f1_macro"] for r in results_models], width=w, label="Macro F1")
    plt.xticks(x, names, rotation=15, ha="right")
    plt.ylim(0, 1.05); plt.ylabel("Score"); plt.legend()
    plt.title("Model performance comparison, stratified test set")
    p = out_dir / "model_comparison.png"
    save_plot(p); figures.append(p.name)

    cm = confusion_matrix(y_test, pred_best, labels=labels, normalize="true")
    plt.figure(figsize=(10, 8))
    plt.imshow(cm, cmap="Blues", vmin=0, vmax=1)
    plt.colorbar(label="Row normalized share")
    plt.xticks(range(len(labels)), labels, rotation=45, ha="right", fontsize=7)
    plt.yticks(range(len(labels)), labels, fontsize=7)
    plt.xlabel("Predicted"); plt.ylabel("True")
    plt.title(f"Confusion matrix, row normalized, {best_name}")
    p = out_dir / "confusion_matrix_best.png"
    save_plot(p); figures.append(p.name)

    top = rf_importance[:15][::-1]
    plt.figure(figsize=(9, 5))
    plt.barh([t["feature"] for t in top], [t["importance"] for t in top], color="#00695c")
    plt.xlabel("Random Forest impurity importance")
    plt.title("Most important predictive features, Random Forest")
    p = out_dir / "feature_importance.png"
    save_plot(p); figures.append(p.name)

    best = next(r for r in results_models if r["model"] == best_name)
    cls = [c for c in labels if c in best["per_class"]]
    plt.figure(figsize=(10, 6))
    y = np.arange(len(cls)); h = 0.35
    plt.barh(y - h / 2, [best["per_class"][c]["precision"] for c in cls], height=h, label="Precision")
    plt.barh(y + h / 2, [best["per_class"][c]["recall"] for c in cls], height=h, label="Recall")
    plt.yticks(y, cls, fontsize=7); plt.xlim(0, 1.05); plt.legend()
    plt.title(f"Per class detection performance, {best_name}")
    p = out_dir / "per_class_performance.png"
    save_plot(p); figures.append(p.name)
    return figures


def run_analysis(data_dir: Path, output_dir: Path, max_per_class: int = 15000) -> dict:
    stats: dict = {"files": [], "full_label_counts": {}, "full_rows": 0}
    csv_files = sorted(data_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found in {data_dir}. Run src/download_data.py first.")
    samples = []
    for path in csv_files:
        print(f"loading {path.name}")
        samples.append(load_file_sample(path, max_per_class=max_per_class, stats=stats))
    sample = pd.concat(samples, ignore_index=True)
    sample = cap_per_class(sample, max_per_class=max_per_class)
    df, feature_cols, prep_info = prepare_model_frame(sample)

    corr_pairs = high_correlation_pairs(df, feature_cols)
    labels = sorted(df[LABEL_COL].unique().tolist())
    X = df[feature_cols]
    y = df[LABEL_COL]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
    )
    # Duplicate check across the split on exact feature rows.
    train_keys = pd.util.hash_pandas_object(X_train, index=False)
    test_keys = pd.util.hash_pandas_object(X_test, index=False)
    overlap = int(len(set(train_keys) & set(test_keys)))

    models = make_models()
    model_results = []
    fitted = {}
    for name, model in models.items():
        print(f"training {name}")
        model.fit(X_train, y_train)
        fitted[name] = model
        res = evaluate_model(name, model, X_test, y_test, labels)
        model_results.append(res)
    best_public = [{k: v for k, v in r.items() if not k.startswith("_")} for r in model_results]
    best_name = max(model_results, key=lambda r: r["f1_macro"])["model"]
    pred_best = next(r["_predictions"] for r in model_results if r["model"] == best_name)
    cm_counts = confusion_matrix(y_test, pred_best, labels=labels).tolist()

    rf = fitted["RandomForest"].named_steps["model"]
    rf_importance = sorted(
        [{"feature": f, "importance": float(v)} for f, v in zip(feature_cols, rf.feature_importances_)],
        key=lambda x: x["importance"],
        reverse=True,
    )

    # Day based split: train Monday to Thursday, test Friday.
    train_mask = df[DAY_COL].isin(["Monday", "Tuesday", "Wednesday", "Thursday"])
    test_mask = df[DAY_COL] == "Friday"
    day_train_classes = sorted(df.loc[train_mask, LABEL_COL].unique().tolist())
    day_test_classes = sorted(df.loc[test_mask, LABEL_COL].unique().tolist())
    unseen_in_training = sorted(set(day_test_classes) - set(day_train_classes))
    absent_from_test = sorted(set(day_train_classes) - set(day_test_classes))
    day_model = clone(fitted["RandomForest"])
    day_model.fit(df.loc[train_mask, feature_cols], df.loc[train_mask, LABEL_COL])
    day_pred = day_model.predict(df.loc[test_mask, feature_cols])
    day_y = df.loc[test_mask, LABEL_COL]
    seen_mask = day_y.isin(day_train_classes)
    day_result = {
        "train_days": ["Monday", "Tuesday", "Wednesday", "Thursday"],
        "test_days": ["Friday"],
        "train_rows": int(train_mask.sum()),
        "test_rows": int(test_mask.sum()),
        "train_classes": day_train_classes,
        "test_classes": day_test_classes,
        "classes_in_test_but_unseen_in_training": unseen_in_training,
        "classes_in_training_but_absent_from_test": absent_from_test,
        "note": "Classes unseen in training cannot be predicted by a closed set classifier. They are listed here and are not treated as ordinary classification failures.",
        "accuracy_all_test_rows": float(accuracy_score(day_y, day_pred)),
        "f1_macro_all_test_rows": float(f1_score(day_y, day_pred, average="macro", zero_division=0)),
        "test_rows_with_classes_seen_in_training": int(seen_mask.sum()),
        "test_rows_with_classes_unseen_in_training": int((~seen_mask).sum()),
        "accuracy_rows_with_classes_seen_in_training": float(accuracy_score(day_y[seen_mask], day_pred[seen_mask])) if seen_mask.any() else None,
        "f1_macro_rows_with_classes_seen_in_training": float(f1_score(day_y[seen_mask], day_pred[seen_mask], labels=sorted(set(day_y[seen_mask])), average="macro", zero_division=0)) if seen_mask.any() else None,
        "f1_macro_note": "Macro F1 on seen class rows is computed only over classes present in those rows. On Friday that is BENIGN only, so the accuracy figure is the more informative seen class result.",
        "per_class_seen_only": {
            str(k): {"precision": float(v["precision"]), "recall": float(v["recall"]), "f1": float(v["f1-score"]), "support": int(v["support"])}
            for k, v in classification_report(day_y[seen_mask], day_pred[seen_mask], output_dict=True, zero_division=0).items()
            if k in day_train_classes
        },
    }

    figures_dir = output_dir / "figures"
    figures = build_figures(figures_dir, stats["full_label_counts"], best_public, best_name, y_test, pred_best, labels, rf_importance, df, feature_cols)

    benign_full = int(stats["full_label_counts"].get("BENIGN", 0))
    results = {
        "project": "Network Intrusion Detection and Traffic Analysis",
        "environment": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "pandas": pd.__version__,
            "numpy": np.__version__,
        },
        "dataset": {
            "name": "CICIDS2017",
            "publisher": "Canadian Institute for Cybersecurity, University of New Brunswick",
            "official_source": "https://www.unb.ca/cic/datasets/ids-2017.html",
            "download_mirror_used": "https://huggingface.co/datasets/c01dsnap/CIC-IDS2017",
            "mirror_note": "Mirror reproduces the publisher licence notice and the eight MachineLearningCSV files. Official source remains authoritative.",
            "citation": "Sharafaldin, I., Lashkari, A. H., and Ghorbani, A. A. (2018). Toward Generating a New Intrusion Detection Dataset and Intrusion Traffic Characterization. ICISSP 2018.",
            "files_used": stats["files"],
            "total_records_in_full_csv_files": int(stats["full_rows"]),
            "full_label_counts": dict(sorted(stats["full_label_counts"].items(), key=lambda x: -x[1])),
            "benign_records_full": benign_full,
            "malicious_records_full": int(stats["full_rows"] - benign_full),
        },
        "modelling_sample": {
            "max_per_class_cap": max_per_class,
            "cap_note": "Per class cap applied for local hardware. All downloaded files were counted in full before sampling. Rare classes were kept in full within the sample.",
            "rows_after_cleaning_and_dedup": int(len(df)),
            "label_counts": {str(k): int(v) for k, v in df[LABEL_COL].value_counts().items()},
            "feature_count": len(feature_cols),
            "features": feature_cols,
        },
        "cleaning_and_leakage": {
            **prep_info,
            "missing_values_by_file_before_cleaning": {f["file"]: f["missing_values_before_cleaning"] for f in stats["files"]},
            "infinite_values_by_file_before_cleaning": {f["file"]: f["infinite_values_before_cleaning"] for f in stats["files"]},
            "exact_duplicate_rows_by_file": {f["file"]: f["exact_duplicate_rows_features_and_label"] for f in stats["files"]},
            "train_test_exact_feature_overlap_after_dedup": overlap,
            "preprocessing_leakage_control": "SimpleImputer and StandardScaler are inside each scikit-learn Pipeline and are fitted on training data only.",
            "identifier_check": "The MachineLearningCSV files contain no Flow ID, source IP, destination IP, or timestamp columns. The drop list was checked and no such columns were present to drop.",
            "label_column_used_as_feature": False,
            "high_correlation_feature_pairs_abs_r_at_least_0_95_in_sample": corr_pairs,
            "correlation_artifact_note": "Highly correlated flow statistics are common in CICFlowMeter output. They are reported, not silently removed, because removing them is a modelling choice that should be tested separately.",
        },
        "splits": {
            "stratified": {
                "method": "train_test_split, test_size 0.20, stratify by label, random_state 42",
                "train_rows": int(len(X_train)),
                "test_rows": int(len(X_test)),
                "classes": labels,
            },
            "day_based": day_result,
        },
        "models": best_public,
        "best_model_by_macro_f1": best_name,
        "confusion_matrix_best_model": {"labels": labels, "counts": cm_counts},
        "random_forest_feature_importance_top20": rf_importance[:20],
        "rare_class_note": "Classes with very small full counts, such as Heartbleed, Infiltration, and SQL Injection variants, have very small test support. Their per class scores are reported in the model tables and should not be read as stable estimates.",
        "figures": figures,
        "limitations": [
            "CICIDS2017 is a historical, simulated testbed dataset from 2017. Results do not demonstrate real world intrusion detection capability.",
            "The modelling sample is capped per class, so test metrics describe the capped sample, not the full 2.8 million flow distribution.",
            "Closed set classifiers cannot detect attack classes that were absent from training. The day based split makes this visible.",
            "Flow features are aggregated statistics. Payload, host context, and operational alert triage are outside this analysis.",
            "Destination Port was the strongest Random Forest feature in this run. Port numbers can reflect the fixed testbed setup as much as general attack behaviour, so feature importance should not be read as a causal explanation.",
            "Class imbalance remains severe for rare attacks even after capping common classes.",
        ],
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    return results
