import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.model_selection import train_test_split

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.pipeline import (
    cap_per_class,
    clean_columns,
    drop_duplicate_named_columns,
    make_models,
    normalize_label,
    prepare_model_frame,
)


def test_normalize_label_replaces_dashes_and_spaces():
    assert normalize_label("  Web Attack \u2013  Brute Force ") == "Web Attack - Brute Force"
    assert normalize_label("Web Attack \ufffd Sql Injection") == "Web Attack - Sql Injection"
    assert normalize_label("BENIGN") == "BENIGN"


def test_clean_columns_and_duplicate_headers():
    df = pd.DataFrame({" A ": [1], "Fwd Header Length.1": [2], "Label": ["BENIGN"]})
    df = clean_columns(df)
    df, dupes = drop_duplicate_named_columns(df)
    assert "A" in df.columns
    assert dupes == ["Fwd Header Length.1"]
    assert "Fwd Header Length.1" not in df.columns


def _sample_frame():
    rows = []
    for label, n in [("BENIGN", 30), ("PortScan", 30), ("Bot", 6)]:
        for i in range(n):
            rows.append(
                {
                    "Destination Port": 80 + (i % 3),
                    "Flow Duration": float(i * 10 + len(label)),
                    "Total Fwd Packets": float(i % 7),
                    "constant_feature": 1.0,
                    "Label": label,
                    "source_day": "Monday" if label != "Bot" else "Friday",
                    "source_file": "synthetic.csv",
                }
            )
    df = pd.DataFrame(rows)
    # Add one exact duplicate and one infinite value.
    df.loc[len(df)] = df.iloc[0]
    df.loc[1, "Flow Duration"] = np.inf
    return df


def test_prepare_model_frame_dedup_and_constant_drop():
    df, features, info = prepare_model_frame(_sample_frame())
    assert "constant_feature" not in features
    assert info["duplicates_removed_in_sample"] >= 1
    assert not np.isinf(df[features].to_numpy(dtype=float, na_value=np.nan)).any()
    # No exact feature duplicates remain.
    assert df.duplicated(subset=features).sum() == 0


def test_cap_per_class_limits_common_classes():
    df = _sample_frame()
    capped = cap_per_class(df, max_per_class=5)
    counts = capped["Label"].value_counts()
    assert counts.max() <= 5
    assert counts["Bot"] <= 5


def test_split_has_no_exact_feature_overlap_after_prep():
    df, features, _ = prepare_model_frame(_sample_frame())
    train, test = train_test_split(df, test_size=0.25, random_state=42, stratify=df["Label"])
    train_keys = set(pd.util.hash_pandas_object(train[features], index=False))
    test_keys = set(pd.util.hash_pandas_object(test[features], index=False))
    assert train_keys.isdisjoint(test_keys)


def test_models_are_pipelines_with_imputer():
    models = make_models()
    assert set(models) == {"RandomForest", "DecisionTree", "LogisticRegression", "KNeighbors"}
    for model in models.values():
        assert "imputer" in model.named_steps


def test_models_fit_on_synthetic_data():
    df, features, _ = prepare_model_frame(_sample_frame())
    train, test = train_test_split(df, test_size=0.25, random_state=42, stratify=df["Label"])
    model = make_models()["DecisionTree"]
    model.fit(train[features], train["Label"])
    pred = model.predict(test[features])
    assert len(pred) == len(test)
    assert set(pred).issubset(set(df["Label"].unique()))
