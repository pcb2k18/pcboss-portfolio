"""Offline Streamlit dashboard. Run: streamlit run app.py"""
import json
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent


def load_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


st.set_page_config(page_title="Multi-Agent AI Safety Evaluation", layout="wide")
st.title("Multi-Agent AI Safety and Risk Evaluation")
st.caption("Independent portfolio project. Deterministic local agents, synthetic data, simulated tools. No LLM is implied.")

results = load_json(ROOT / "outputs" / "results.json", {})
scenario_data = load_json(ROOT / "data" / "scenarios.json", {"scenarios": []})
scenarios = scenario_data["scenarios"]

st.header("Three-agent architecture")
st.markdown(
    "- **Planner Agent**: interprets the trusted user task and delegates research and execution.\n"
    "- **Researcher Agent**: reads approved synthetic documents and reports findings with a citation.\n"
    "- **Executor Agent**: writes permitted output inside an isolated temporary workspace.\n"
    "- **Policy gate**: in protected mode every message and tool call receives ALLOW, DENY, or REDACT, with a structured audit log.\n"
    "- **Trust boundary**: user and planner messages are trusted. Document content is untrusted."
)
fig7 = ROOT / "outputs" / "figures" / "fig7_workflow.png"
if fig7.exists():
    st.image(str(fig7), caption="Agent interaction workflow")

if not results:
    st.warning("No results found. Run: python run_evaluation.py")
    st.stop()

metrics = results["metrics"]
cols = st.columns(2)
for col, label in zip(cols, ("baseline", "protected")):
    m = metrics[label]
    with col:
        st.subheader(label.capitalize() + " results")
        st.metric("Scenarios evaluated", m["scenarios_evaluated"])
        st.metric("Unsafe attempts", m["unsafe_action_attempts"])
        st.metric("Unsafe actions permitted", m["unsafe_actions_permitted"])
        st.metric("Safety interventions", m["successful_safety_interventions"])
        st.metric("Disclosure violations", m["disclosure_violations"])
        st.metric("Legitimate completed", f"{m['legitimate_completed']} / {m['legitimate_scenarios']}")
        st.metric("False positives", f"{m['false_positives']} ({m['false_positive_rate']:.1%})")

st.header("Safety metrics by category")
st.dataframe([{"category": k, **{f"{cfg}_{key}": metrics[cfg]["per_category"][k][key]
                                  for cfg in ("baseline", "protected")
                                  for key in ("unsafe_attempts", "unsafe_permitted", "disclosure_violations")}}
              for k in metrics["baseline"]["per_category"]], width="stretch")

st.header("Available evaluation scenarios")
st.dataframe(scenarios, width="stretch")

st.header("Charts")
for name in results.get("figures", []):
    path = ROOT / "outputs" / "figures" / name
    if path.exists():
        st.image(str(path), caption=name)

st.header("Trace inspection and defense decisions")
config = st.selectbox("Configuration", ("baseline", "protected"))
records = results["records"][config]
choice = st.selectbox("Scenario", [r["scenario_id"] for r in records])
record = next(r for r in records if r["scenario_id"] == choice)
st.json({"unsafe_attempted": record["unsafe_attempted"], "unsafe_permitted": record["unsafe_permitted"],
         "disclosure_violation": record["disclosure_violation"], "interventions": record["interventions"],
         "legitimate_completed": record["legitimate_completed"], "final_output": record["final_output"]})
st.subheader("Execution trace")
st.dataframe(record["trace"], width="stretch")
st.subheader("Audit log (defense decisions)")
st.dataframe(record["audit"], width="stretch")

st.header("Real model evaluation")
st.json(results.get("live_llm_evaluation", {}))
