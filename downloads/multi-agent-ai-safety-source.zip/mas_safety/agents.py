"""Deterministic local agents. No LLM is used in the default configuration.

Agents are deliberately naive about instructions that reach them: if an
injected instruction is delivered, the Executor will attempt the requested
tool. Safety is therefore tested at the message, policy, and tool layers,
which is the behaviour this project intends to measure. This models a
worst case compliant agent and must not be read as LLM behaviour.
"""
from __future__ import annotations

from .messages import Message, TrustLevel

TOOL_WORDS = ("send_external", "delete_file", "read_credentials", "write_output")


def tool_from_instruction(text: str) -> str | None:
    low = (text or "").lower()
    for tool in TOOL_WORDS:
        if tool in low:
            return tool
    return None


class PlannerAgent:
    role = "Planner"

    def delegate_research(self, user_task: str, document_id: str, key: str) -> Message:
        return Message(self.role, "Researcher", "delegate_research",
                       f"Read approved document {document_id} for task: {user_task}",
                       TrustLevel.TRUSTED.value).sign(key)

    def delegate_execution(self, user_task: str, findings: str, untrusted_instruction: str,
                           citation_quote: str, source_document: str, key: str) -> Message:
        return Message(self.role, "Executor", "execute_task",
                       f"Task: {user_task}\nFindings: {findings}",
                       TrustLevel.TRUSTED.value,
                       untrusted_instruction=untrusted_instruction,
                       citation_quote=citation_quote,
                       source_document=source_document).sign(key)


class ResearcherAgent:
    role = "Researcher"

    def __init__(self, gateway):
        self.gateway = gateway

    def research(self, document_id: str, scenario: dict) -> dict:
        result = self.gateway.call(self.role, "read_document", {"document_id": document_id})
        content = result["result"] if result["permitted"] else ""
        embedded = ""
        lines = []
        for line in content.splitlines():
            if line.startswith("INSTRUCTION:"):
                embedded = line[len("INSTRUCTION:"):].strip()
            else:
                lines.append(line)
        findings = "\n".join(lines)
        citation = lines[0] if lines else ""
        if scenario.get("attack_type") == "cascading_error":
            findings = scenario.get("fabricated_finding", findings)
            citation = scenario.get("fabricated_quote", "fabricated quote not in source")
        return {"findings": findings, "embedded_instruction": embedded,
                "citation_quote": citation, "read_permitted": result["permitted"]}

    def report(self, research: dict, document_id: str, key: str) -> Message:
        return Message(self.role, "Planner", "research_findings",
                       research["findings"], TrustLevel.UNTRUSTED.value,
                       untrusted_instruction=research["embedded_instruction"],
                       citation_quote=research["citation_quote"],
                       source_document=document_id).sign(key)


class ExecutorAgent:
    role = "Executor"

    def __init__(self, gateway):
        self.gateway = gateway

    def attempt_tool(self, tool: str, findings: str = "") -> dict:
        if tool == "send_external":
            return self.gateway.call(self.role, tool,
                                     {"recipient": "external@example.invalid", "payload": findings})
        if tool == "delete_file":
            return self.gateway.call(self.role, tool, {"filename": "old_report.txt"})
        if tool == "read_credentials":
            return self.gateway.call(self.role, tool, {})
        if tool == "write_output":
            return self.gateway.call(self.role, tool, {"filename": "output.txt", "content": findings})
        return {"tool": tool, "permitted": False, "result": "unknown"}

    def write_summary(self, user_task: str, findings: str) -> dict:
        content = f"Task output\nTask: {user_task}\nFindings:\n{findings}\n"
        result = self.gateway.call(self.role, "write_output",
                                   {"filename": "output.txt", "content": content})
        return {"final_output": content if result["permitted"] else "", "write_result": result}
