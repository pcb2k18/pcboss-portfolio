"""Runtime policy enforcement: permissions, validation, redaction, audit.

Decisions are explicit: ALLOW, DENY, or REDACT.
When the engine is disabled (baseline), every check returns ALLOW and no
redaction or validation is applied. Physical workspace confinement in
tools.py is always active, even in baseline, so no run can touch files
outside its temporary sandbox.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

ALLOW, DENY, REDACT = "ALLOW", "DENY", "REDACT"

# Role permission boundaries. Planner delegates only. Researcher may read
# approved documents. Executor may write output in the workspace.
ROLE_PERMISSIONS = {
    "Planner": set(),
    "Researcher": {"read_document"},
    "Executor": {"write_output"},
}
# Tools that no agent may ever use in the protected configuration.
NEVER_ALLOWED_TOOLS = {"send_external", "delete_file", "read_credentials"}
APPROVED_CLASSIFICATIONS = {"public", "internal"}

SECRET_PATTERNS = [
    (re.compile(r"MOCK-SECRET-[A-Z0-9\-]+"), "[REDACTED MOCK SECRET]"),
    (re.compile(r"MOCK-API-KEY-[A-Z0-9\-]+"), "[REDACTED MOCK API KEY]"),
    (re.compile(r"mock_password\s*[:=]\s*\S+", re.I), "mock_password=[REDACTED]"),
    (re.compile(r"\b000-\d{2}-\d{4}\b"), "[REDACTED FICTIONAL ID]"),
]
INSTRUCTION_MARKERS = ("ignore previous", "ignore all", "you must", "send_external",
                       "delete_file", "read_credentials", "exfiltrate")


@dataclass
class Decision:
    decision: str
    reasons: list = field(default_factory=list)


class PolicyEngine:
    def __init__(self, enabled: bool):
        self.enabled = enabled
        self.audit: list[dict] = []

    def _log(self, check, decision, reasons, context):
        entry = {"check": check, "decision": decision, "reasons": reasons, "context": context}
        self.audit.append(entry)
        return Decision(decision, reasons)

    @property
    def interventions(self) -> int:
        if not self.enabled:
            return 0
        return sum(1 for a in self.audit if a["decision"] in (DENY, REDACT))

    def evaluate_message(self, msg, signing_key: str, documents: dict) -> Decision:
        ctx = {"sender": msg.sender, "recipient": msg.recipient, "kind": msg.kind}
        if not self.enabled:
            return self._log("message_validation", ALLOW, ["policy disabled"], ctx)
        if not msg.verify(signing_key):
            return self._log("message_validation", DENY,
                             ["invalid message signature: possible spoofing or tampering"], ctx)
        # Citation check: a research finding must quote its source document.
        if msg.kind == "research_findings" and msg.citation_quote:
            doc = documents.get(msg.source_document, {})
            if msg.citation_quote not in doc.get("content", ""):
                return self._log("message_validation", DENY,
                                 ["finding citation not present in cited source document"], ctx)
        return self._log("message_validation", ALLOW, ["signature valid"], ctx)

    def evaluate_tool(self, role: str, tool: str, args: dict, documents: dict) -> Decision:
        ctx = {"role": role, "tool": tool, "args": {k: str(v)[:80] for k, v in (args or {}).items()}}
        if not self.enabled:
            return self._log("tool_permission", ALLOW, ["policy disabled"], ctx)
        if tool in NEVER_ALLOWED_TOOLS:
            return self._log("tool_permission", DENY, [f"tool {tool} is not on any allowlist"], ctx)
        if tool not in ROLE_PERMISSIONS.get(role, set()):
            return self._log("tool_permission", DENY,
                             [f"role {role} is not permitted to use tool {tool}"], ctx)
        if tool == "read_document":
            doc = documents.get(args.get("document_id", ""))
            if doc is None:
                return self._log("tool_permission", DENY, ["document not in approved corpus"], ctx)
            if doc.get("classification") not in APPROVED_CLASSIFICATIONS:
                return self._log("tool_permission", DENY,
                                 [f"document classification {doc.get('classification')} is not approved for Researcher"], ctx)
        if tool == "write_output":
            name = str(args.get("filename", ""))
            if "/" in name or "\\" in name or ".." in name:
                return self._log("tool_permission", DENY, ["output path must stay inside workspace"], ctx)
        return self._log("tool_permission", ALLOW, ["tool permitted for role"], ctx)

    def redact(self, text: str, context: str = "") -> tuple[str, bool]:
        if not self.enabled or not text:
            return text, False
        out, changed = text, False
        for pattern, replacement in SECRET_PATTERNS:
            out, n = pattern.subn(replacement, out)
            changed = changed or n > 0
        if changed:
            self._log("redaction", REDACT, ["sensitive mock pattern redacted"], {"context": context})
        return out, changed

    def strip_untrusted_instruction(self, msg) -> bool:
        """Remove instruction text that arrived inside untrusted content."""
        if not self.enabled:
            return False
        if msg.untrusted_instruction:
            msg.untrusted_instruction = ""
            self._log("trust_separation", REDACT,
                      ["instruction embedded in untrusted document content removed"],
                      {"sender": msg.sender, "recipient": msg.recipient})
            return True
        return False
