"""Independent multi-agent AI safety evaluation package.

This code was written for this project. It does not copy source code
from any reference project.
"""
__version__ = "1.0.0"
