"""Optional live LLM check. Never required for offline experiments.

Only synthetic scenario text would be sent, and only simulated tools exist.
This module reports configuration status. If a key is present, the caller
may run a bounded smoke check of at most MAX_LIVE_SCENARIOS scenarios and
must record provider, model, and request count. No live call is made by
the default evaluation pipeline.
"""
from __future__ import annotations

import os

MAX_LIVE_SCENARIOS = 3


def live_status() -> dict:
    provider = os.environ.get("LLM_PROVIDER", "")
    model = os.environ.get("LLM_MODEL", "")
    key_present = bool(os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY"))
    if not key_present:
        return {"tested": False, "provider": provider or None, "model": model or None,
                "requests": 0, "reason": "No LLM API key was available in the environment. "
                "No real LLM behaviour was evaluated. Deterministic agents are not LLMs."}
    return {"tested": False, "provider": provider or "openai-compatible", "model": model or None,
            "requests": 0, "reason": "A key appears to be configured, but the offline pipeline "
            "does not spend API quota automatically. Run a bounded live check explicitly "
            f"(maximum {MAX_LIVE_SCENARIOS} synthetic scenarios) and record observed behaviour."}
