"""Charts generated only from actual experiment results in results data."""
from __future__ import annotations

from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

COLORS = {"baseline": "#c0392b", "protected": "#2471a3"}


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path


def make_figures(results: dict, scenarios: list[dict], example_record: dict, out_dir: Path) -> list[str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    made = []
    b, p = results["metrics"]["baseline"], results["metrics"]["protected"]

    # 1. Scenario distribution
    counts = Counter(s["category"] for s in scenarios)
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.bar(list(counts), list(counts.values()), color="#2471a3")
    ax.set_title("1. Safety scenario distribution"); ax.set_ylabel("Scenarios")
    plt.setp(ax.get_xticklabels(), rotation=25, ha="right")
    made.append(str(_save(fig, out_dir / "fig1_scenario_distribution.png")))

    # 2. Baseline versus protected outcomes
    labels = ["Unsafe permitted", "Disclosure violations", "Interventions", "Legitimate completed"]
    bv = [b["unsafe_actions_permitted"], b["disclosure_violations"], b["successful_safety_interventions"], b["legitimate_completed"]]
    pv = [p["unsafe_actions_permitted"], p["disclosure_violations"], p["successful_safety_interventions"], p["legitimate_completed"]]
    fig, ax = plt.subplots(figsize=(8, 4)); x = range(len(labels)); w = 0.38
    ax.bar([i - w/2 for i in x], bv, w, label="Baseline", color=COLORS["baseline"])
    ax.bar([i + w/2 for i in x], pv, w, label="Protected", color=COLORS["protected"])
    ax.set_xticks(list(x)); ax.set_xticklabels(labels, rotation=15, ha="right")
    ax.set_title("2. Baseline versus protected outcomes"); ax.legend()
    made.append(str(_save(fig, out_dir / "fig2_baseline_vs_protected.png")))

    # 3. Unsafe permitted by category
    cats = [c for c in b["per_category"] if c != "legitimate"]
    fig, ax = plt.subplots(figsize=(8, 4)); x = range(len(cats))
    ax.bar([i - w/2 for i in x], [b["per_category"][c]["unsafe_permitted"] for c in cats], w, label="Baseline", color=COLORS["baseline"])
    ax.bar([i + w/2 for i in x], [p["per_category"][c]["unsafe_permitted"] for c in cats], w, label="Protected", color=COLORS["protected"])
    ax.set_xticks(list(x)); ax.set_xticklabels(cats, rotation=25, ha="right")
    ax.set_title("3. Unsafe actions permitted by category"); ax.legend()
    made.append(str(_save(fig, out_dir / "fig3_unsafe_by_category.png")))

    # 4. Disclosure outcomes
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(["Baseline", "Protected"], [b["disclosure_violations"], p["disclosure_violations"]],
           color=[COLORS["baseline"], COLORS["protected"]])
    ax.set_title(f"4. Information disclosure violations\n(of {b['disclosure_relevant_scenarios']} disclosure scenarios per configuration)")
    ax.set_ylabel("Scenarios with disclosure")
    made.append(str(_save(fig, out_dir / "fig4_disclosure.png")))

    # 5. Legitimate completion
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(["Baseline", "Protected"],
           [b["legitimate_completed"], p["legitimate_completed"]], color=[COLORS["baseline"], COLORS["protected"]])
    ax.set_ylim(0, max(b["legitimate_scenarios"], 1))
    ax.set_title(f"5. Legitimate task completion (of {b['legitimate_scenarios']} per configuration)")
    made.append(str(_save(fig, out_dir / "fig5_legitimate_completion.png")))

    # 6. False positive rates
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(["Baseline", "Protected"], [b["false_positive_rate"] * 100, p["false_positive_rate"] * 100],
           color=[COLORS["baseline"], COLORS["protected"]])
    ax.set_ylabel("False positive rate (%)")
    ax.set_title(f"6. False positive rates\n(false positives / {b['legitimate_scenarios']} legitimate scenarios)")
    made.append(str(_save(fig, out_dir / "fig6_false_positive_rate.png")))

    # 7. Agent interaction workflow (diagram, not measured data)
    fig, ax = plt.subplots(figsize=(9, 3.5)); ax.axis("off")
    boxes = [("User\n(trusted task)", 0.02), ("Planner\n(delegate)", 0.22), ("Researcher\n(read approved docs)", 0.44),
             ("Executor\n(write output)", 0.68), ("Simulated tools\n(workspace only)", 0.86)]
    for text, x in boxes:
        ax.add_patch(FancyBboxPatch((x, 0.4), 0.13, 0.3, boxstyle="round,pad=0.01", fc="#d6eaf8", ec="#2471a3"))
        ax.text(x + 0.065, 0.55, text, ha="center", va="center", fontsize=7)
    for x in (0.15, 0.35, 0.57, 0.81):
        ax.annotate("", xy=(x + 0.06, 0.55), xytext=(x, 0.55), arrowprops=dict(arrowstyle="->"))
    ax.text(0.5, 0.2, "Policy gate on every message and tool call in protected mode: ALLOW / DENY / REDACT, with audit log",
            ha="center", fontsize=8)
    ax.set_title("7. Agent interaction workflow")
    made.append(str(_save(fig, out_dir / "fig7_workflow.png")))

    # 8. Example trace with intervention (actual recorded trace)
    trace = example_record.get("trace", [])[:10]
    fig, ax = plt.subplots(figsize=(9, 4.5)); ax.axis("off")
    lines = [f"Scenario {example_record['scenario_id']} ({example_record['configuration']})"]
    for i, t in enumerate(trace, 1):
        if t["event"] in ("message", "policy_decision"):
            lines.append(f"{i}. {t['sender']} -> {t['recipient']} [{t['kind']}] {t['decision']}: {'; '.join(t['reasons'])}")
        else:
            lines.append(f"{i}. TOOL {t.get('agent','?')} uses {t.get('tool','?')}: {t['decision']} permitted={t.get('permitted')}")
    ax.text(0.01, 0.95, "\n".join(lines), va="top", ha="left", fontsize=7, family="monospace", wrap=True)
    ax.set_title("8. Example message trace with safety intervention")
    made.append(str(_save(fig, out_dir / "fig8_example_trace.png")))
    return made
