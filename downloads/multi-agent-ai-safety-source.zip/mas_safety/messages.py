"""Agent to agent messages with trust labels and integrity signatures."""
from __future__ import annotations

import hashlib
import hmac
import json
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum


class TrustLevel(str, Enum):
    TRUSTED = "trusted"        # user task and planner delegations created inside the system
    UNTRUSTED = "untrusted"    # document content and any externally supplied text


def _canonical(sender, recipient, kind, content, tool_call, trust):
    payload = {
        "sender": sender, "recipient": recipient, "kind": kind,
        "content": content, "tool_call": tool_call or {}, "trust": trust,
    }
    return json.dumps(payload, sort_keys=True).encode("utf-8")


@dataclass
class Message:
    sender: str
    recipient: str
    kind: str
    content: str
    trust: str = TrustLevel.TRUSTED.value
    tool_call: dict | None = None
    untrusted_instruction: str = ""
    citation_quote: str = ""
    source_document: str = ""
    message_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    signature: str = ""

    def sign(self, key: str) -> "Message":
        self.signature = hmac.new(
            key.encode(), _canonical(self.sender, self.recipient, self.kind,
                                     self.content, self.tool_call, self.trust),
            hashlib.sha256).hexdigest()
        return self

    def verify(self, key: str) -> bool:
        if not self.signature:
            return False
        expected = hmac.new(
            key.encode(), _canonical(self.sender, self.recipient, self.kind,
                                     self.content, self.tool_call, self.trust),
            hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, self.signature)

    def to_dict(self):
        return asdict(self)
