# Portfolio Case Study: Multi-Agent AI Safety and Risk Evaluation

Portfolio: https://pcboss.me
Project type: independent academic research prototype
Status: offline experiments completed. No real LLM evaluated.

## Summary

I built a small three-agent system (Planner, Researcher, Executor) and evaluated it on 24 synthetic scenarios covering prompt injection, sensitive disclosure, unauthorized tools, role spoofing, message tampering, instruction conflicts, cascading errors, and legitimate work. The same scenarios ran in a baseline configuration with safety controls disabled, and a protected configuration with runtime policy enforcement. Protected mode permitted 0 of 17 simulated unsafe actions, against 17 of 17 in baseline, and reduced disclosure violations from 3 to 0. Legitimate completion fell from 7 of 7 to 6 of 7, giving a false positive rate of 1 of 7 (14.3 percent). That blocked legitimate task is reported as a cost of strict allowlisting, not hidden.

## Why this project

Multi-agent systems add risks that single model testing misses: instructions can enter through documents, one agent can impersonate or contradict another, and errors can cascade between agents. I wanted a reproducible way to test those handoffs directly, with traces that show exactly where an attack was stopped or allowed through.

## Method in brief

- Deterministic local agents with real message passing, role permissions, and execution traces. No paid API is required.
- A signed message bus separates trusted planner messages from untrusted document content.
- Simulated tools only. External sending is recorded in memory, deletion affects one dummy file, and every run is confined to a fresh temporary workspace.
- Protected mode applies permission boundaries, tool allowlists, message signature and citation validation, untrusted instruction stripping, mock secret redaction, and structured audit logging with ALLOW, DENY, and REDACT decisions.
- Metrics use explicit denominators. Attempts are distinguished from permitted actions throughout.

## Key findings (this simulation only)

1. Enforcement at the message and tool layers stopped every attack in this suite, including forged and tampered messages that a content filter alone would not address.
2. Redaction and restricted document rules removed all fictional marker disclosures (3 baseline violations to 0).
3. Strict allowlisting has a measurable usability cost: 1 of 7 legitimate tasks, an external sharing request, was blocked, a false positive rate of 14.3 percent in this small sample.
4. Citation validation stopped fabricated findings from cascading into final output, which suggests provenance checks are a useful complement to content checks.

## What this does not show

The agents are rule-based and deliberately compliant, so results describe policy enforcement behaviour, not the robustness of real LLM agents. Attacks were template based and designed alongside the controls, so the zero permitted rate must not be generalised or read as production security certification. No real LLM inference was tested, because no API key was available and the pipeline never spends quota automatically.

## Reproducibility

Commands: `pip install -r requirements.txt`, then `python run_evaluation.py`, `python -m pytest tests -q` (16 tests), and `streamlit run app.py` for the offline dashboard. Full metrics, audit logs, and traces are in `outputs/results.json`. Eight charts are in `outputs/figures/`.

## Skills demonstrated

Multi-agent system design, threat modelling, trust boundary analysis, runtime policy enforcement, security evaluation design, metric definition, experimental reproducibility, and honest reporting of false positives and limitations.

## Reference note

Informed at a conceptual level by the public TrinityGuard repository (AI45Lab, MIT License). This implementation, its scenarios, and its results are original to this project. No reference code or findings were copied.
