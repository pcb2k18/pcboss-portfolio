"""Run baseline and protected experiments, write results and figures.

Usage: python run_evaluation.py
Works fully offline. No API key is required.
"""
from __future__ import annotations

import json
from pathlib import Path

from mas_safety.evaluation import load_scenarios, run_all
from mas_safety.llm_provider import live_status
from mas_safety.visualize import make_figures

ROOT = Path(__file__).resolve().parent


def main():
    scenarios = load_scenarios()
    results = run_all(scenarios)
    out = ROOT / "outputs"
    out.mkdir(exist_ok=True)
    example = next(r for r in results["records"]["protected"] if r["scenario_id"] == "PI-01")
    figures = make_figures(results, scenarios, example, out / "figures")
    payload = {
        "project": "Multi-Agent AI Safety and Risk Evaluation",
        "note": "Independent project. Deterministic local agents, not LLMs. All data synthetic.",
        "live_llm_evaluation": live_status(),
        "metric_definitions": {
            "unsafe_action_attempts": "Malicious scenarios presenting one primary attack to the system.",
            "unsafe_actions_permitted": "Malicious scenarios where a malicious tool executed, a sensitive marker reached output or a simulated send, or a fabricated finding reached final output.",
            "successful_safety_interventions": "Protected audit events with decision DENY or REDACT.",
            "disclosure_violations": "Scenarios where a fictional sensitive marker reached final output, a written file, or a simulated external payload.",
            "legitimate_completion": "Legitimate scenarios completed, divided by all legitimate scenarios.",
            "false_positives": "Legitimate scenarios not completed under a configuration, divided by all legitimate scenarios.",
        },
        "metrics": results["metrics"],
        "effectiveness": results["effectiveness"],
        "figures": [Path(f).name for f in figures],
        "records": results["records"],
    }
    (out / "results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"metrics": results["metrics"], "effectiveness": results["effectiveness"],
                      "live_llm_evaluation": payload["live_llm_evaluation"],
                      "figures": payload["figures"]}, indent=2))
    print(f"Wrote {out / 'results.json'}")


if __name__ == "__main__":
    main()
