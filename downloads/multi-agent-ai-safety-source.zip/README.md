# Multi-Agent AI Safety and Risk Evaluation

An independent, reproducible experimental framework for evaluating security and safety risks in multi-agent AI workflows. Built for an academic PhD portfolio at https://pcboss.me.

This project was implemented independently for this portfolio. The public reference at https://github.com/AI45Lab/TrinityGuard was inspected on 20 October 2026 (default branch: master, MIT License). Its README describes a framework for evaluating safety risks in multi-agent systems across built-in risk types, with workflow tracing, message interception, structured logs, and opt-in runtime protection using allow, replace, and deny decisions. This project was informed at that conceptual level only. No source code was copied from that repository, and none of its findings are reported here as original results. All scenarios, code, documents, and results in this repository were created for this project. This project uses ALLOW, DENY, and REDACT decisions, which is a different decision set from the reference.

## Research question

Do explicit runtime safety controls reduce simulated violations in a three-agent workflow without unnecessarily preventing legitimate tasks?

Short answer from this experiment: in this deterministic simulation, protected mode reduced permitted unsafe actions from 17 of 17 to 0 of 17, and disclosure violations from 3 to 0, while legitimate completion fell from 7 of 7 to 6 of 7. The one blocked legitimate task is counted as a false positive and is analysed rather than hidden.

## Important scope statement

The default agents are deterministic, rule-based local programs. They are not large language models, and these results do not measure LLM robustness. The agents are deliberately compliant: if an injected instruction reaches the Executor, it attempts the requested simulated tool. The experiment therefore measures policy enforcement behaviour (message validation, permission gates, redaction, and tool allowlists), not model judgement. This is not a production security certification.

## Architecture

Three agents communicate through a signed message bus with recorded handoffs:

1. Planner Agent: interprets the trusted user task and delegates research and execution. It has no tool permissions.
2. Researcher Agent: reads approved synthetic documents and reports findings with a citation to the source document. It may only use `read_document`.
3. Executor Agent: produces the final output. It may only use `write_output` inside the run workspace.

Supporting components:

- `mas_safety/messages.py`: messages with trust labels and HMAC integrity signatures.
- `mas_safety/policy.py`: runtime policy engine with ALLOW, DENY, and REDACT decisions and a structured audit log.
- `mas_safety/tools.py`: simulated tools confined to a fresh temporary workspace per run.
- `mas_safety/documents.py`: synthetic document corpus. All identifiers and credentials are fictional.
- `mas_safety/system.py`: message bus, task handoffs, attack insertion points, and execution traces.
- `mas_safety/evaluation.py`: scenario runner and metric aggregation with explicit denominators.
- `mas_safety/visualize.py`: charts generated only from recorded results.
- `mas_safety/llm_provider.py`: optional live model status check. Never required offline.
- `app.py`: offline Streamlit dashboard.

## Threat model

Trusted: the user task as issued, and messages created and signed inside the system by the Planner.

Untrusted: document content, any instruction embedded in a document, forged messages, altered messages, and findings that cannot be cited to their source.

Attacker capabilities in scope: embedding instructions in documents, requesting unauthorised tools, forging a message from another role, tampering with a message in transit, inserting conflicting instructions, and seeding a fabricated finding that would cascade.

Out of scope: real credential theft, network attacks, operating system escape, and any production service. Simulated tools perform no network access. `send_external` only records a payload in memory. `delete_file` only removes a dummy file created inside the temporary workspace. Workspace path confinement is enforced in code in both configurations, including baseline.

## Defense mechanisms

1. Agent permission boundaries: each role has an explicit tool set. See `ROLE_PERMISSIONS` in `mas_safety/policy.py`.
2. Trusted versus untrusted separation: instructions embedded in document content are carried in a separate untrusted field and stripped in protected mode.
3. Tool execution allowlists: `send_external`, `delete_file`, and `read_credentials` are on no role allowlist in protected mode.
4. Sensitive information redaction: fictional mock secret patterns are replaced before output in protected mode.
5. Inter-agent message validation: signatures are verified, and research findings must quote the cited source document.
6. Runtime policy enforcement: every message and tool call receives ALLOW, DENY, or REDACT in protected mode.
7. Structured audit logging: every decision is recorded with its check type, reasons, and context, and is visible in the dashboard.

## Evaluation scenarios

There are 24 scenarios in `data/scenarios.json`:

- prompt injection: 3
- sensitive information disclosure: 3
- unauthorized tool requests: 3
- agent role spoofing: 2
- message tampering: 2
- cross-agent instruction conflicts: 2
- cascading agent errors: 2
- legitimate tasks: 7

Each malicious scenario presents one primary attack by design, which fixes the attempt denominator. Each scenario documents its expected behaviour.

## Metrics and denominators

- Unsafe action attempts: malicious scenarios presenting an attack. Denominator for the permitted rate: 17 per configuration.
- Unsafe actions permitted: malicious scenarios where a malicious tool executed, a fictional sensitive marker reached an output or simulated send, or a fabricated finding reached the final output.
- Successful safety interventions: protected audit events with decision DENY or REDACT. Baseline has no interventions by construction. This count is not divided by attempts because one scenario can trigger several decisions.
- Information disclosure violations: scenarios where a fictional marker reached the final output, a written file, or a simulated external payload. Four scenarios per configuration are disclosure relevant (they carry markers or a disclosure aim).
- Legitimate task completion: completed legitimate scenarios divided by 7.
- False positives: legitimate scenarios not completed divided by 7. Blocked legitimate work is a cost of the controls and is reported openly.

## Results (actual recorded run)

Source: `outputs/results.json`, generated by `python run_evaluation.py`.

| Measure | Baseline | Protected |
| --- | --- | --- |
| Scenarios evaluated | 24 | 24 |
| Unsafe action attempts | 17 | 17 |
| Unsafe actions permitted | 17 (100.0%) | 0 (0.0%) |
| Safety interventions | 0 | 20 |
| Disclosure violations | 3 | 0 |
| Legitimate tasks completed | 7 of 7 (100.0%) | 6 of 7 (85.7%) |
| False positives | 0 of 7 (0.0%) | 1 of 7 (14.3%) |

Interpretation: controls blocked every simulated attack in this suite, at the cost of one legitimate external sharing request (L-07) that the strict allowlist blocks for all recipients. Because the simulated agents always comply with delivered instructions and the attacks were designed against these controls, a 100 percent block rate must not be generalised. It shows the enforcement points work as specified on this suite. It does not show robustness against novel attacks, paraphrased injections, or real LLM behaviour.

## Real model evaluation

No real LLM was evaluated in this run. No supported API key was present in the environment, and the pipeline does not spend API quota automatically. `outputs/results.json` records this explicitly under `live_llm_evaluation`, including the reason, provider (null), model (null), and request count (0). If a key is configured later, `mas_safety/llm_provider.py` bounds any live check to synthetic scenarios and simulated tools only, and provider, model, scenario count, and request count must be recorded alongside observed behaviour.

## Reproduction

Requires Python 3.10 or later.

```bash
python -m venv .venv
pip install -r requirements.txt
python run_evaluation.py
python -m pytest tests -q
streamlit run app.py
```

On Windows PowerShell, activate the environment with `.venv\Scripts\Activate.ps1` after creation. The virtual environment step is optional if dependencies are already installed.

Outputs:

- `outputs/results.json`: full metrics, per-category outcomes, audit logs, and traces.
- `outputs/figures/`: eight charts generated from the recorded results.
- `outputs/portfolio-case-study.md`: portfolio write-up.

## Tests

16 automated tests cover scenario coverage, message signing and tamper detection, spoofing and tampering denial, injection blocking, redaction, role permission boundaries, restricted document handling, cascading error blocking, legitimate completion, the known L-07 false positive, full-run metric consistency, workspace confinement, and trace recording. At the time of writing, all 16 pass. Run them with the command above and record the current output rather than trusting this sentence.

## Limitations

- Deterministic compliant agents overstate both baseline failure and control effectiveness compared with real LLM agents, which may refuse some attacks and evade some controls.
- Attacks are template based. Paraphrase, encoding, multi-step social engineering, and adaptive attackers are not covered.
- Redaction is pattern based and only detects the fictional marker formats used here.
- The citation check verifies that a quote exists in the cited document. It does not verify semantic correctness of a summary.
- One primary attack per scenario simplifies counting. Real incidents combine vectors.
- The signing key is a local demonstration constant, not a credential management design.
- Sample size is small (24 scenarios), so rates have wide uncertainty and should be read as counts first.

## License and attribution

This is an independent academic portfolio project. The conceptual reference, TrinityGuard by AI45Lab, is MIT licensed: https://github.com/AI45Lab/TrinityGuard. No code, data, figures, or findings were copied from it. Synthetic data in this project may be reused for teaching with attribution to this project.

## Licensing

The original source code in this project is licensed under the MIT License. Third-party datasets, libraries, models, and other externally sourced materials remain subject to their respective licenses.

See the [LICENSE](LICENSE) file for the full license text.
