# Clinical Survival and Risk Factor Analysis

Independent, reproducible portfolio project for PhD academic portfolio presentation at https://pcboss.me.

This project investigates patient survival patterns and clinical risk factors in a public historical dataset using standard biostatistical methods: Kaplan-Meier estimation, the log-rank test, and Cox proportional hazards regression.

It is not a clinical decision tool and does not claim clinical validation.

## Dataset

- Name: NCCTG Lung Cancer Survival Dataset.
- Access: `lifelines.datasets.load_lung` from the lifelines Python package.
- Records verified in this implementation: 228 patient records.
- Time variable: `time`, recorded in days in the lifelines version.
- Event variable: `status` in the loaded data, copied to `event` in code. Coding verified before analysis: the loaded column contains only 0 and 1. Value 1 is treated as death (event, 165 records) and 0 as censored (63 records, 27.63 percent).
- Important coding note: some documentation of the original NCCTG data describes status as 1 for censored and 2 for dead. That coding is not present in the lifelines loaded version used here, which was checked programmatically. Code raises an error if unexpected status values appear, rather than silently recoding or substituting another dataset.
- Variables: institution code (`inst`), age in years, sex (1 Male, 2 Female in source, labelled in code), ECOG performance score (`ph.ecog`, physician rated, higher is worse), Karnofsky performance scores (`ph.karno` physician rated, `pat.karno` patient rated), calories consumed at meals (`meal.cal`), and weight loss in the previous six months (`wt.loss`).
- No patient level data file is included in the source ZIP. Data are loaded at runtime from lifelines.

Original study reference as distributed with survival datasets: Loprinzi CL, Laurie JA, Wieand HS, et al. Prospective evaluation of prognostic variables from patient-completed questionnaires. North Central Cancer Treatment Group. Journal of Clinical Oncology. 1994;12(3):601-607.

## Methods

- Exploratory summaries of demographics, follow-up time, events, and censoring.
- Missing value counts and percentages for every source column.
- Overall Kaplan-Meier survival estimation with median survival and survival probabilities at 365 and 730 days.
- Kaplan-Meier curves by sex and a two sample log-rank test (Male vs Female).
- Cox proportional hazards regression. Covariates: age (per year), sex (Female vs Male), `ph.ecog`, `ph.karno`, `pat.karno`, `meal.cal`, and `wt.loss`.
- Missing data handling: complete case analysis for the Cox model. Records with missing time, event, or any covariate are excluded, and the retained and excluded counts are reported in `outputs/results.json`, the dashboard, and the case study. No imputation is used.
- Proportional hazards assessment: lifelines proportional hazard test with rank time transform, plus scaled Schoenfeld residual plots.
- Hazard ratios are reported with 95 percent confidence intervals and p-values. They are adjusted associations, not causal effects.

## Key outputs

Run the analysis to generate current numeric results. Do not rely on copied numbers in secondary summaries.

- `outputs/results.json`: full machine readable results.
- `outputs/portfolio-case-study.md`: generated case study with the same results.
- `outputs/figures/`: PNG figures listed below.

Figures:

- `01_patient_characteristics.png`
- `02_missing_values.png`
- `03_survival_censoring_distribution.png`
- `04_km_overall.png`
- `05_km_by_sex.png`
- `06_cox_hazard_ratios.png`
- `07_schoenfeld_residuals.png`
- `08_ph_assumption_test.png`

## Reproduction

```bash
python -m venv .venv
pip install -r requirements.txt
python run_analysis.py
python -m pytest -q
streamlit run app.py
```

On Windows PowerShell, activate the environment with `.venv\Scripts\Activate.ps1` after creation if you use a virtual environment.

The dashboard presents dataset summary, survival curves, subgroup comparison, Cox results, proportional hazards checks, and plain language interpretation.

## Limitations

- Small dataset: 228 records, with fewer records in the complete case Cox model.
- Historical trial population. Results do not represent current lung cancer treatment or outcomes.
- Missing data, especially `meal.cal`, reduce the analysis sample and may bias complete case estimates if missingness is related to prognosis.
- Performance scores are coarse and partly subjective.
- No competing risks, treatment effect estimation, interaction modelling, or external validation was performed.
- Proportional hazards test results must be checked in `outputs/results.json`. Covariates with small p-values indicate possible assumption violations and limit direct interpretation.
- Observational associations do not establish causality.

## Project structure

```text
app.py                  Streamlit dashboard
run_analysis.py         Generates results, figures, and case study
src/analysis.py         Data loading, verification, and statistical analysis
tests/test_analysis.py  Automated tests
requirements.txt
outputs/                Generated results (results.json, case study, figures)
```

## Sources and attribution

- Dataset: NCCTG lung cancer data via lifelines `load_lung`. See dataset note above.
- Statistical library: lifelines. Davidson-Pilon C. lifelines: survival analysis in Python. Journal of Open Source Software. 2019;4(40):1317.
- Reference repository inspected for scope and methods before implementation: AmiRaGaL/clinical-survival-analysis-dashboard, MIT License, https://github.com/AmiRaGaL/clinical-survival-analysis-dashboard . This repository is a separate implementation. No code was copied from the reference. The reference was used to confirm the intended dataset, method family, and dashboard concept.
- Portfolio site: https://pcboss.me

## License

MIT License for the original code in this project. See `LICENSE`. The dataset remains subject to its source terms as distributed with lifelines and the original publication.
