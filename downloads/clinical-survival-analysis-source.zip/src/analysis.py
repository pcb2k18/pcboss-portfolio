"""Core analysis for Clinical Survival and Risk Factor Analysis.

Dataset: NCCTG Lung Cancer dataset loaded with lifelines.datasets.load_lung.
In the lifelines version, status is coded 1 for death and 0 for censoring.
This coding was verified against the loaded data: values are only 0 and 1,
with 165 events and 63 censored observations in 228 records. The original
NCCTG coding (1 censored, 2 dead) is not present in this loaded version,
so no recoding to a different event definition is applied.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter, KaplanMeierFitter
from lifelines.statistics import logrank_test, proportional_hazard_test

COX_COVARIATES = ["age", "sex_female", "ph.ecog", "ph.karno", "pat.karno", "meal.cal", "wt.loss"]
EXPECTED_COLUMNS = ["inst", "time", "status", "age", "sex", "ph.ecog", "ph.karno", "pat.karno", "meal.cal", "wt.loss"]


def load_data() -> pd.DataFrame:
    try:
        from lifelines.datasets import load_lung
        df = load_lung()
    except Exception as exc:
        raise RuntimeError(f"Could not load NCCTG lung dataset with lifelines.datasets.load_lung: {exc}") from exc
    missing_cols = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing_cols:
        raise RuntimeError(f"Loaded dataset is missing expected columns: {missing_cols}")
    df = df.copy()
    values = set(df["status"].dropna().unique().tolist())
    if not values.issubset({0, 1}):
        raise RuntimeError(f"Unexpected status coding in lifelines load_lung output: {sorted(values)}. Expected only 0 and 1.")
    df["event"] = df["status"].astype(int)
    df["sex_label"] = df["sex"].map({1: "Male", 2: "Female"})
    if df["sex_label"].isna().any():
        raise RuntimeError("Unexpected sex coding. Expected 1 for Male and 2 for Female.")
    df["sex_female"] = (df["sex"] == 2).astype(int)
    return df


def missing_summary(df: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame({
        "column": df.columns,
        "missing": [int(df[c].isna().sum()) for c in df.columns],
    })
    out["missing_pct"] = (100 * out["missing"] / len(df)).round(2)
    return out.sort_values("missing", ascending=False).reset_index(drop=True)


def km_fit(df: pd.DataFrame, label: str = "Overall"):
    kmf = KaplanMeierFitter()
    kmf.fit(df["time"], df["event"], label=label)
    return kmf


def survival_at(kmf, times=(365, 730)):
    return {str(int(t)): float(kmf.predict(t)) for t in times}


def run_all(df: pd.DataFrame | None = None) -> dict:
    if df is None:
        df = load_data()
    n = int(len(df))
    events = int(df["event"].sum())
    censored = int(n - events)

    kmf = km_fit(df)
    median_overall = float(kmf.median_survival_time_)
    ci = kmf.confidence_interval_
    # median CI from lifelines if available
    try:
        from lifelines.utils import median_survival_times
        med_ci = median_survival_times(ci)
        vals = []
        for v in med_ci.values.flatten()[:2]:
            fv = float(v)
            vals.append(fv if np.isfinite(fv) else None)
        # median_survival_times returns bounds in CI column order; keep as reported
        median_ci = vals if len(vals) == 2 else [None, None]
    except Exception:
        median_ci = [None, None]

    male = df[df["sex_label"] == "Male"]
    female = df[df["sex_label"] == "Female"]
    kmf_m = km_fit(male, "Male")
    kmf_f = km_fit(female, "Female")
    lr = logrank_test(male["time"], female["time"], male["event"], female["event"])

    # Cox model: complete case analysis, reported transparently.
    cox_cols = ["time", "event"] + COX_COVARIATES
    cox_df = df[cox_cols].dropna().copy()
    cph = CoxPHFitter()
    cph.fit(cox_df, duration_col="time", event_col="event")
    hr_rows = []
    for var in COX_COVARIATES:
        row = cph.summary.loc[var]
        hr_rows.append({
            "variable": var,
            "coef": float(row["coef"]),
            "hazard_ratio": float(row["exp(coef)"]),
            "se": float(row["se(coef)"]),
            "z": float(row["z"]),
            "p": float(row["p"]),
            "ci_lower": float(row["exp(coef) lower 95%"]),
            "ci_upper": float(row["exp(coef) upper 95%"]),
        })
    try:
        ph = proportional_hazard_test(cph, cox_df, time_transform="rank")
        ph_rows = []
        ts = ph.summary  # DataFrame with test_statistic, p, -log2(p) in current lifelines
        for var, row in ts.iterrows():
            p_val = float(row["p"]) if "p" in row else None
            stat_val = float(row["test_statistic"]) if "test_statistic" in row else None
            ph_rows.append({"variable": str(var), "test_statistic": stat_val, "p": p_val,
                            "p_below_0_05": bool(p_val < 0.05) if p_val is not None else None})
        ph_summary = {"time_transform": "rank", "results": ph_rows}
    except Exception as exc:
        ph_summary = {"time_transform": "rank", "results": [], "error": str(exc)}

    sex_counts = df["sex_label"].value_counts().to_dict()
    results = {
        "dataset": {
            "name": "NCCTG Lung Cancer Survival Dataset",
            "source": "lifelines.datasets.load_lung (lifelines Python package)",
            "source_url": "https://lifelines.readthedocs.io/en/latest/lifelines.datasets.html",
            "original_study": "North Central Cancer Treatment Group (NCCTG) lung cancer dataset, as distributed with lifelines and originally from Loprinzi et al. (1994)",
            "n_records": n,
            "columns": list(df.columns),
            "time_variable": "time (days in the lifelines version)",
            "event_variable": "status in loaded data, copied to event: 1 = death (event), 0 = censored",
            "event_coding_verified": "Loaded status values are only 0 and 1. Counts match the known NCCTG totals distributed with lifelines: 165 deaths and 63 censored.",
            "events": events,
            "censored": censored,
            "censoring_pct": round(100 * censored / n, 2),
            "event_pct": round(100 * events / n, 2),
            "median_time_days": float(df["time"].median()),
            "mean_time_days": float(df["time"].mean()),
            "min_time_days": int(df["time"].min()),
            "max_time_days": int(df["time"].max()),
            "sex_counts": {str(k): int(v) for k, v in sex_counts.items()},
            "age": {"mean": float(df["age"].mean()), "sd": float(df["age"].std()), "median": float(df["age"].median()), "min": int(df["age"].min()), "max": int(df["age"].max())},
        },
        "missing_values": missing_summary(df[EXPECTED_COLUMNS]).to_dict(orient="records"),
        "missing_total_cells_in_analysis_columns": int(df[EXPECTED_COLUMNS].isna().sum().sum()),
        "kaplan_meier_overall": {
            "median_survival_days": median_overall,
            "median_survival_ci_days": median_ci,
            "survival_at_days": survival_at(kmf),
        },
        "kaplan_meier_by_sex": {
            "Male": {"n": int(len(male)), "events": int(male["event"].sum()), "median_survival_days": float(kmf_m.median_survival_time_), "survival_at_days": survival_at(kmf_m)},
            "Female": {"n": int(len(female)), "events": int(female["event"].sum()), "median_survival_days": float(kmf_f.median_survival_time_), "survival_at_days": survival_at(kmf_f)},
        },
        "logrank_sex": {"comparison": "Male vs Female", "test_statistic": float(lr.test_statistic), "p_value": float(lr.p_value)},
        "cox_model": {
            "method": "Cox proportional hazards, complete case analysis. No imputation. Rows with any missing value in time, event, or covariates were excluded and the retained sample is reported.",
            "covariates": COX_COVARIATES,
            "covariate_notes": "age in years (per 1 year), sex_female 1 = Female and 0 = Male, ph.ecog ECOG performance score (higher is worse), ph.karno Karnofsky score rated by physician, pat.karno Karnofsky score rated by patient, meal.cal calories consumed at meals, wt.loss weight loss in last six months (pounds in source documentation).",
            "n_total": n,
            "n_used": int(len(cox_df)),
            "n_excluded_missing": int(n - len(cox_df)),
            "events_used": int(cox_df["event"].sum()),
            "concordance": float(cph.concordance_index_),
            "log_likelihood": float(cph.log_likelihood_),
            "hazard_ratios": hr_rows,
        },
        "proportional_hazards": ph_summary,
        "software": {"python_packages": ["pandas", "numpy", "lifelines", "matplotlib", "streamlit"]},
    }
    return results


def get_fitted(df: pd.DataFrame):
    """Return fitted objects for plotting. Used by run_analysis and app."""
    kmf = km_fit(df)
    male = df[df["sex_label"] == "Male"]
    female = df[df["sex_label"] == "Female"]
    kmf_m = km_fit(male, "Male")
    kmf_f = km_fit(female, "Female")
    cox_cols = ["time", "event"] + COX_COVARIATES
    cox_df = df[cox_cols].dropna().copy()
    cph = CoxPHFitter()
    cph.fit(cox_df, duration_col="time", event_col="event")
    return kmf, kmf_m, kmf_f, cph, cox_df
