import json
from pathlib import Path

import numpy as np
import pytest

from src.analysis import load_data, run_all

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def data():
    return load_data()


@pytest.fixture(scope="module")
def results(data):
    return run_all(data)


def test_dataset_shape_and_columns(data):
    assert len(data) == 228
    for c in ["time", "status", "age", "sex", "ph.ecog", "ph.karno", "pat.karno", "meal.cal", "wt.loss"]:
        assert c in data.columns


def test_event_coding(data, results):
    assert set(data["status"].unique()) == {0, 1}
    assert int(data["event"].sum()) == 165
    assert int((data["event"] == 0).sum()) == 63
    assert results["dataset"]["events"] + results["dataset"]["censored"] == 228


def test_missing_counts(data):
    miss = data.isna().sum()
    assert int(miss["meal.cal"]) == 47
    assert int(miss["wt.loss"]) == 14
    assert int(miss["pat.karno"]) == 3
    assert int(miss["time"]) == 0
    assert int(miss["status"]) == 0


def test_sex_counts(data):
    vc = data["sex_label"].value_counts().to_dict()
    assert vc["Male"] + vc["Female"] == 228
    assert vc["Male"] == 138
    assert vc["Female"] == 90


def test_km_and_logrank(results):
    assert 200 < results["kaplan_meier_overall"]["median_survival_days"] < 350
    assert results["kaplan_meier_by_sex"]["Female"]["median_survival_days"] > results["kaplan_meier_by_sex"]["Male"]["median_survival_days"]
    p = results["logrank_sex"]["p_value"]
    assert 0 < p < 0.01
    for v in results["kaplan_meier_overall"]["survival_at_days"].values():
        assert 0 <= v <= 1


def test_cox_outputs(results):
    cox = results["cox_model"]
    assert cox["n_used"] + cox["n_excluded_missing"] == cox["n_total"] == 228
    assert cox["n_used"] > 100
    assert 0.5 < cox["concordance"] < 1.0
    for r in cox["hazard_ratios"]:
        assert np.isfinite(r["hazard_ratio"]) and r["hazard_ratio"] > 0
        assert r["ci_lower"] < r["hazard_ratio"] < r["ci_upper"]
        assert 0 <= r["p"] <= 1
    by_var = {r["variable"]: r for r in cox["hazard_ratios"]}
    assert by_var["sex_female"]["hazard_ratio"] < 1


def test_ph_output(results):
    ph = results["proportional_hazards"]
    assert "results" in ph
    # Either rows are present with p values in range, or an explicit structure exists.
    for r in ph["results"]:
        if r["p"] is not None:
            assert 0 <= r["p"] <= 1


def test_outputs_exist_if_generated():
    p = ROOT / "outputs" / "results.json"
    if p.exists():
        loaded = json.loads(p.read_text(encoding="utf-8"))
        assert loaded["dataset"]["n_records"] == 228
