"""Run the full analysis and write outputs/results.json, figures, and case study."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.analysis import COX_COVARIATES, get_fitted, load_data, missing_summary, run_all

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "outputs" / "figures"
OUT = ROOT / "outputs"

plt.rcParams.update({"figure.dpi": 150, "savefig.dpi": 150, "axes.spines.top": False, "axes.spines.right": False, "font.size": 10})


def save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    p = FIG / name
    fig.tight_layout()
    fig.savefig(p, bbox_inches="tight")
    plt.close(fig)
    return p.name


def main():
    df = load_data()
    results = run_all(df)
    kmf, kmf_m, kmf_f, cph, cox_df = get_fitted(df)
    files = []

    # 1 Patient characteristics
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6))
    axes[0].hist(df[df.sex_label == "Male"]["age"], bins=12, alpha=0.7, label="Male")
    axes[0].hist(df[df.sex_label == "Female"]["age"], bins=12, alpha=0.7, label="Female")
    axes[0].set_xlabel("Age (years)"); axes[0].set_ylabel("Patients"); axes[0].set_title("Age by sex"); axes[0].legend()
    counts = df["sex_label"].value_counts()
    axes[1].bar(counts.index, counts.values, color=["#4C72B0", "#DD8452"]); axes[1].set_title("Patients by sex"); axes[1].set_ylabel("Patients")
    for i, v in enumerate(counts.values): axes[1].text(i, v + 2, str(v), ha="center")
    eco = df["ph.ecog"].value_counts().sort_index()
    axes[2].bar([str(int(x)) if float(x).is_integer() else str(x) for x in eco.index], eco.values, color="#55A868")
    axes[2].set_title("ECOG performance (ph.ecog)"); axes[2].set_xlabel("Score (higher is worse)"); axes[2].set_ylabel("Patients")
    fig.suptitle("Patient characteristics", fontsize=12)
    files.append(save(fig, "01_patient_characteristics.png"))

    # 2 Missing values
    miss = missing_summary(df[["inst","time","status","age","sex","ph.ecog","ph.karno","pat.karno","meal.cal","wt.loss"]])
    miss_nz = miss[miss.missing > 0].sort_values("missing")
    fig, ax = plt.subplots(figsize=(8, 3.8))
    if len(miss_nz):
        ax.barh(miss_nz.column, miss_nz.missing, color="#C44E52")
        for i, (m, p) in enumerate(zip(miss_nz.missing, miss_nz.missing_pct)): ax.text(m + 0.5, i, f"{m} ({p}%)", va="center")
    ax.set_xlabel("Missing records"); ax.set_title("Missing values by variable (variables with no missing values omitted in bars)")
    ax.set_xlim(0, max(55, (miss_nz.missing.max() * 1.25 if len(miss_nz) else 55)))
    files.append(save(fig, "02_missing_values.png"))

    # 3 Survival and censoring distribution
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    axes[0].hist(df[df.event == 1]["time"], bins=20, alpha=0.75, label="Death (event)")
    axes[0].hist(df[df.event == 0]["time"], bins=20, alpha=0.75, label="Censored")
    axes[0].set_xlabel("Time (days)"); axes[0].set_ylabel("Patients"); axes[0].set_title("Observed time by outcome"); axes[0].legend()
    vals = [results["dataset"]["events"], results["dataset"]["censored"]]
    axes[1].bar(["Death", "Censored"], vals, color=["#4C72B0", "#999999"])
    for i, v in enumerate(vals): axes[1].text(i, v + 3, str(v), ha="center")
    axes[1].set_title("Event and censoring counts"); axes[1].set_ylabel("Patients")
    files.append(save(fig, "03_survival_censoring_distribution.png"))

    # 4 KM overall
    fig, ax = plt.subplots(figsize=(8, 5))
    kmf.plot_survival_function(ax=ax, ci_show=True)
    ax.set_xlabel("Time (days)"); ax.set_ylabel("Survival probability"); ax.set_title("Kaplan-Meier survival, overall")
    ax.set_ylim(0, 1.02); ax.grid(alpha=0.3)
    files.append(save(fig, "04_km_overall.png"))

    # 5 KM by sex
    fig, ax = plt.subplots(figsize=(8, 5))
    kmf_m.plot_survival_function(ax=ax, ci_show=True)
    kmf_f.plot_survival_function(ax=ax, ci_show=True)
    p = results["logrank_sex"]["p_value"]; stat = results["logrank_sex"]["test_statistic"]
    ax.set_xlabel("Time (days)"); ax.set_ylabel("Survival probability")
    ax.set_title(f"Kaplan-Meier survival by sex (log-rank p = {p:.4g}, statistic = {stat:.2f})")
    ax.set_ylim(0, 1.02); ax.grid(alpha=0.3)
    files.append(save(fig, "05_km_by_sex.png"))

    # 6 Cox forest
    hr = pd.DataFrame(results["cox_model"]["hazard_ratios"])
    fig, ax = plt.subplots(figsize=(9, 4.6))
    y = np.arange(len(hr))
    ax.errorbar(hr.hazard_ratio, y, xerr=[hr.hazard_ratio - hr.ci_lower, hr.ci_upper - hr.hazard_ratio], fmt="o", capsize=4)
    ax.axvline(1, color="black", linewidth=1, linestyle="--")
    ax.set_yticks(y); ax.set_yticklabels(hr.variable); ax.set_xlabel("Hazard ratio (95% CI), log scale"); ax.set_xscale("log"); ax.set_xlim(0.25, 6)
    ax.set_title("Cox proportional hazards: hazard ratios with 95% CI")
    for i, r in hr.iterrows():
        idx = list(hr.index).index(i)
        ax.text(r.ci_upper * 1.08, idx, f"{r.hazard_ratio:.3f} ({r.ci_lower:.3f} to {r.ci_upper:.3f})", va="center", fontsize=8)
    ax.grid(alpha=0.3, axis="x")
    files.append(save(fig, "06_cox_hazard_ratios.png"))

    # 7 PH diagnostics: Schoenfeld residuals if available, plus PH test p values
    try:
        resid = cph.compute_residuals(cox_df, kind="scaled_schoenfeld")
        # resid index is time, columns covariates
        fig, axes = plt.subplots(3, 3, figsize=(11, 8))
        axes = axes.flatten()
        for ax, var in zip(axes, COX_COVARIATES):
            ax.scatter(resid.index, resid[var], s=12, alpha=0.6)
            ax.axhline(0, color="black", linewidth=0.8)
            ax.set_title(var, fontsize=9); ax.set_xlabel("Time (days)"); ax.set_ylabel("Scaled Schoenfeld")
        for ax in axes[len(COX_COVARIATES):]: ax.axis("off")
        fig.suptitle("Model diagnostics: scaled Schoenfeld residuals vs time")
        files.append(save(fig, "07_schoenfeld_residuals.png"))
    except Exception as exc:
        fig, ax = plt.subplots(figsize=(8, 4)); ax.text(0.5, 0.5, f"Schoenfeld residuals unavailable: {exc}", ha="center", wrap=True); ax.axis("off")
        files.append(save(fig, "07_schoenfeld_residuals.png"))

    # 8 PH test summary
    ph_rows = results["proportional_hazards"].get("results", [])
    fig, ax = plt.subplots(figsize=(8, 4))
    if ph_rows:
        pdf_ = pd.DataFrame(ph_rows)
        # global row may be present; keep all
        colors = ["#C44E52" if (p is not None and p < 0.05) else "#4C72B0" for p in pdf_.p]
        ax.barh(pdf_.variable, pdf_.p, color=colors)
        ax.axvline(0.05, color="black", linestyle="--", label="p = 0.05")
        ax.set_xlabel("Proportional hazards test p-value (rank transform)"); ax.set_title("Proportional hazards assumption test"); ax.legend()
    else:
        ax.text(0.5, 0.5, "PH test unavailable", ha="center"); ax.axis("off")
    files.append(save(fig, "08_ph_assumption_test.png"))

    results["figures"] = files
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    d = results["dataset"]; km = results["kaplan_meier_overall"]; ks = results["kaplan_meier_by_sex"]; lr_ = results["logrank_sex"]; cox = results["cox_model"]
    ph_lines = "\n".join([f"- {r['variable']}: statistic {r['test_statistic']}, p = {r['p']}" if r["test_statistic"] is not None else f"- {r['variable']}: p = {r['p']}" for r in results["proportional_hazards"].get("results", [])]) or "- Not available."
    hr_lines = "\n".join([f"| {r['variable']} | {r['hazard_ratio']:.3f} | {r['ci_lower']:.3f} to {r['ci_upper']:.3f} | {r['p']:.4g} |" for r in cox["hazard_ratios"]])
    miss_lines = "\n".join([f"- {r['column']}: {r['missing']} missing ({r['missing_pct']}%)" for r in results["missing_values"] if r["missing"] > 0]) or "- None."
    case = f"""# Clinical Survival and Risk Factor Analysis: Portfolio Case Study

For portfolio presentation at https://pcboss.me. This is an independent implementation. It was informed by inspection of the reference repository listed in Sources, but code and text here were written separately for this project.

## Question

What are the survival patterns and adjusted clinical associations in the NCCTG lung cancer dataset distributed with lifelines?

## Data

- Source: `lifelines.datasets.load_lung`, NCCTG Lung Cancer Survival Dataset.
- Records: {d['n_records']}. Events (deaths): {d['events']}. Censored: {d['censored']} ({d['censoring_pct']}%).
- Time: `time` in days. Median observed time {d['median_time_days']} days, range {d['min_time_days']} to {d['max_time_days']} days.
- Event coding verified: the loaded `status` column contains only 0 and 1, with 1 treated as death and 0 as censoring. This matches the lifelines distribution. The original study coding is documented in the README.
- Sex: Male {d['sex_counts'].get('Male', 0)}, Female {d['sex_counts'].get('Female', 0)}. Age mean {d['age']['mean']:.1f} years (SD {d['age']['sd']:.1f}).

Missing values in the source columns:

{miss_lines}

Cox modelling used complete cases only: {cox['n_used']} of {cox['n_total']} records retained, {cox['n_excluded_missing']} excluded due to missing covariates. No imputation was used.

## Methods

Kaplan-Meier estimation overall and by sex, log-rank test for Male vs Female, and Cox proportional hazards regression with covariates: {', '.join(cox['covariates'])}. Proportional hazards were assessed with the lifelines proportional hazard test using a rank time transform, supported by scaled Schoenfeld residual plots. Hazard ratios are associations, not causal effects.

## Results

- Median Kaplan-Meier survival overall: {km['median_survival_days']} days. Survival at 365 days: {km['survival_at_days']['365']:.3f}. At 730 days: {km['survival_at_days']['730']:.3f}.
- Median survival, Male: {ks['Male']['median_survival_days']} days (n = {ks['Male']['n']}, events = {ks['Male']['events']}). Female: {ks['Female']['median_survival_days']} days (n = {ks['Female']['n']}, events = {ks['Female']['events']}).
- Log-rank test, Male vs Female: statistic = {lr_['test_statistic']:.3f}, p = {lr_['p_value']:.4g}.
- Cox concordance (complete case sample): {cox['concordance']:.3f}. This is a descriptive discrimination summary for this sample, not a validated prediction claim.

| Variable | Hazard ratio | 95% CI | p |
|---|---:|---:|---:|
{hr_lines}

Proportional hazards test (rank transform):

{ph_lines}

See `outputs/results.json` for full numeric output and `outputs/figures/` for charts. Interpretation must consider any covariates with small PH test p-values as possible assumption concerns.

## Limitations

The dataset is small (228 records), historical, and from a specific trial population. It does not represent current lung cancer care. Complete case analysis reduces the Cox sample and may introduce selection bias if missingness is not random. Observational associations do not establish causality. No external validation was performed and the model is not clinically validated. Performance variables are coarse summary scores.

## Reproduction

```bash
pip install -r requirements.txt
python run_analysis.py
python -m pytest -q
streamlit run app.py
```

## Sources and attribution

- Dataset: NCCTG lung cancer data via `lifelines.datasets.load_lung`. Original study: Loprinzi CL et al., Journal of Clinical Oncology, 1994 (see README for full citation as distributed with survival datasets).
- Methods library: lifelines (Davidson-Pilon, 2019), Kaplan-Meier, log-rank, and Cox proportional hazards implementations.
- Reference for project structure inspection only: AmiRaGaL/clinical-survival-analysis-dashboard, MIT License, https://github.com/AmiRaGaL/clinical-survival-analysis-dashboard . This project is a separate implementation and does not copy its code.
- Portfolio: https://pcboss.me

## Figures

{chr(10).join(['- outputs/figures/' + f for f in files])}
"""
    with open(OUT / "portfolio-case-study.md", "w", encoding="utf-8") as f:
        f.write(case)
    print(json.dumps({"n": d["n_records"], "events": d["events"], "censored": d["censored"], "figures": files, "cox_n_used": cox["n_used"], "logrank_p": lr_["p_value"]}, indent=2))


if __name__ == "__main__":
    main()
