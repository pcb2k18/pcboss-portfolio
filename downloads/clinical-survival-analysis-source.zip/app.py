"""Streamlit dashboard: Clinical Survival and Risk Factor Analysis."""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

from src.analysis import get_fitted, load_data, missing_summary, run_all

st.set_page_config(page_title="Clinical Survival and Risk Factor Analysis", layout="wide")


@st.cache_data
def load_results():
    df = load_data()
    return df, run_all(df)


df, results = load_results()
kmf, kmf_m, kmf_f, cph, cox_df = get_fitted(df)

st.title("Clinical Survival and Risk Factor Analysis")
st.caption("NCCTG Lung Cancer Survival Dataset via lifelines.datasets.load_lung. Independent portfolio project for https://pcboss.me. Not a clinical decision tool.")

d = results["dataset"]
c1, c2, c3, c4 = st.columns(4)
c1.metric("Patients", d["n_records"])
c2.metric("Deaths (events)", d["events"])
c3.metric("Censored", f"{d['censored']} ({d['censoring_pct']}%)")
c4.metric("Median survival (days)", f"{results['kaplan_meier_overall']['median_survival_days']:.0f}")

st.header("Dataset summary")
st.write(f"Time is recorded in days (median observed time {d['median_time_days']:.0f} days, range {d['min_time_days']} to {d['max_time_days']}). Event coding was verified in the loaded lifelines data: status 1 = death, 0 = censored. Sex counts: {d['sex_counts']}. Age mean {d['age']['mean']:.1f} years.")
st.subheader("Missing values")
st.dataframe(pd.DataFrame(results["missing_values"]), use_container_width=True, hide_index=True)
st.write(f"Cox model uses complete cases only: {results['cox_model']['n_used']} of {results['cox_model']['n_total']} records. No imputation was performed.")

left, right = st.columns(2)
with left:
    st.header("Overall Kaplan-Meier curve")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    kmf.plot_survival_function(ax=ax, ci_show=True)
    ax.set_xlabel("Time (days)"); ax.set_ylabel("Survival probability"); ax.set_ylim(0, 1.02); ax.grid(alpha=0.3)
    st.pyplot(fig); plt.close(fig)

with right:
    st.header("Survival by sex")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    kmf_m.plot_survival_function(ax=ax, ci_show=True)
    kmf_f.plot_survival_function(ax=ax, ci_show=True)
    ax.set_xlabel("Time (days)"); ax.set_ylabel("Survival probability"); ax.set_ylim(0, 1.02); ax.grid(alpha=0.3)
    st.pyplot(fig); plt.close(fig)

lr = results["logrank_sex"]
ks = results["kaplan_meier_by_sex"]
st.write(f"Median survival: Male {ks['Male']['median_survival_days']:.0f} days (n = {ks['Male']['n']}), Female {ks['Female']['median_survival_days']:.0f} days (n = {ks['Female']['n']}). Log-rank test (Male vs Female): statistic = {lr['test_statistic']:.3f}, p = {lr['p_value']:.4g}. A small p-value indicates a detectable difference between the two curves in this dataset. It does not establish a causal effect of sex.")

st.header("Cox proportional hazards results")
hr = pd.DataFrame(results["cox_model"]["hazard_ratios"])
st.dataframe(hr, use_container_width=True, hide_index=True)
fig, ax = plt.subplots(figsize=(8, 4))
import numpy as np
y = np.arange(len(hr))
ax.errorbar(hr.hazard_ratio, y, xerr=[hr.hazard_ratio - hr.ci_lower, hr.ci_upper - hr.hazard_ratio], fmt="o", capsize=4)
ax.axvline(1, color="black", linestyle="--", linewidth=1)
ax.set_yticks(y); ax.set_yticklabels(hr.variable); ax.set_xscale("log"); ax.set_xlabel("Hazard ratio (95% CI), log scale"); ax.grid(alpha=0.3, axis="x")
st.pyplot(fig); plt.close(fig)
st.write(f"Concordance in the complete case sample: {results['cox_model']['concordance']:.3f}. This describes discrimination in this sample only and is not external validation.")

st.header("Proportional hazards check")
ph = results["proportional_hazards"]
if ph.get("results"):
    st.dataframe(pd.DataFrame(ph["results"]), use_container_width=True, hide_index=True)
    st.write("Small p-values (below 0.05) flag covariates where the proportional hazards assumption may not hold. Such results should be treated cautiously and would need model refinement in a formal analysis.")
else:
    st.write("Proportional hazards test results were not available in this run. See outputs/results.json.")

st.header("Interpretation and limitations")
st.write("Hazard ratios above 1 indicate a higher estimated hazard of death associated with a one unit increase in the covariate, after adjustment for the other included variables. Ratios below 1 indicate a lower estimated hazard. Confidence intervals that include 1 are compatible with no association at the 95% level.")
st.write("Limitations: 228 historical records from a specific trial population, coarse performance scores, complete case exclusion of records with missing covariates, and no external validation. Associations are not causal effects. This dashboard is for education and portfolio demonstration, not clinical use.")

st.header("Reproducibility")
st.code("pip install -r requirements.txt\npython run_analysis.py\npython -m pytest -q\nstreamlit run app.py", language="bash")
st.caption("Source code and full results: outputs/results.json and outputs/portfolio-case-study.md in this project.")
