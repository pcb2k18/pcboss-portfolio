# Clinical Survival and Risk Factor Analysis: Portfolio Case Study

For portfolio presentation at https://pcboss.me. This is an independent implementation. It was informed by inspection of the reference repository listed in Sources, but code and text here were written separately for this project.

## Question

What are the survival patterns and adjusted clinical associations in the NCCTG lung cancer dataset distributed with lifelines?

## Data

- Source: `lifelines.datasets.load_lung`, NCCTG Lung Cancer Survival Dataset.
- Records: 228. Events (deaths): 165. Censored: 63 (27.63%).
- Time: `time` in days. Median observed time 255.5 days, range 5 to 1022 days.
- Event coding verified: the loaded `status` column contains only 0 and 1, with 1 treated as death and 0 as censoring. This matches the lifelines distribution. The original study coding is documented in the README.
- Sex: Male 138, Female 90. Age mean 62.4 years (SD 9.1).

Missing values in the source columns:

- meal.cal: 47 missing (20.61%)
- wt.loss: 14 missing (6.14%)
- pat.karno: 3 missing (1.32%)
- inst: 1 missing (0.44%)
- ph.karno: 1 missing (0.44%)
- ph.ecog: 1 missing (0.44%)

Cox modelling used complete cases only: 168 of 228 records retained, 60 excluded due to missing covariates. No imputation was used.

## Methods

Kaplan-Meier estimation overall and by sex, log-rank test for Male vs Female, and Cox proportional hazards regression with covariates: age, sex_female, ph.ecog, ph.karno, pat.karno, meal.cal, wt.loss. Proportional hazards were assessed with the lifelines proportional hazard test using a rank time transform, supported by scaled Schoenfeld residual plots. Hazard ratios are associations, not causal effects.

## Results

- Median Kaplan-Meier survival overall: 310.0 days. Survival at 365 days: 0.409. At 730 days: 0.116.
- Median survival, Male: 270.0 days (n = 138, events = 112). Female: 426.0 days (n = 90, events = 53).
- Log-rank test, Male vs Female: statistic = 10.327, p = 0.001311.
- Cox concordance (complete case sample): 0.651. This is a descriptive discrimination summary for this sample, not a validated prediction claim.

| Variable | Hazard ratio | 95% CI | p |
|---|---:|---:|---:|
| age | 1.011 | 0.988 to 1.034 | 0.3591 |
| sex_female | 0.576 | 0.389 to 0.855 | 0.006092 |
| ph.ecog | 2.084 | 1.345 to 3.228 | 0.001008 |
| ph.karno | 1.023 | 1.000 to 1.045 | 0.04574 |
| pat.karno | 0.988 | 0.972 to 1.003 | 0.1232 |
| meal.cal | 1.000 | 1.000 to 1.001 | 0.8979 |
| wt.loss | 0.986 | 0.971 to 1.001 | 0.06518 |

Proportional hazards test (rank transform):

- age: statistic 0.7397254940932613, p = 0.38974882632939456
- meal.cal: statistic 4.2227213049336605, p = 0.039886142416115766
- pat.karno: statistic 0.12474773802768885, p = 0.7239411630092147
- ph.ecog: statistic 0.10213818896405344, p = 0.7492786567603804
- ph.karno: statistic 2.94702902228513, p = 0.08603559045196968
- sex_female: statistic 2.065510941129241, p = 0.15066442427292506
- wt.loss: statistic 0.7094467647455007, p = 0.3996275337814893

See `outputs/results.json` for full numeric output and `outputs/figures/` for charts. Interpretation must consider any covariates with small PH test p-values as possible assumption concerns.

## Limitations

The dataset is small (228 records), historical, and from a specific trial population. It does not represent current lung cancer care. Complete case analysis reduces the Cox sample and may introduce selection bias if missingness is not random. Observational associations do not establish causality. No external validation was performed and the model is not clinically validated. Performance variables are coarse summary scores.

## Reproduction

```bash
pip install -r requirements.txt
python run_analysis.py
python -m pytest -q
streamlit run app.py
```

## Sources and attribution

- Dataset: NCCTG lung cancer data via `lifelines.datasets.load_lung`. Original study: Loprinzi CL et al., Journal of Clinical Oncology, 1994 (see README for full citation as distributed with survival datasets).
- Methods library: lifelines (Davidson-Pilon, 2019), Kaplan-Meier, log-rank, and Cox proportional hazards implementations.
- Reference for project structure inspection only: AmiRaGaL/clinical-survival-analysis-dashboard, MIT License, https://github.com/AmiRaGaL/clinical-survival-analysis-dashboard . This project is a separate implementation and does not copy its code.
- Portfolio: https://pcboss.me

## Figures

- outputs/figures/01_patient_characteristics.png
- outputs/figures/02_missing_values.png
- outputs/figures/03_survival_censoring_distribution.png
- outputs/figures/04_km_overall.png
- outputs/figures/05_km_by_sex.png
- outputs/figures/06_cox_hazard_ratios.png
- outputs/figures/07_schoenfeld_residuals.png
- outputs/figures/08_ph_assumption_test.png
