# Hospital Operations and Patient Care Analytics

Independent admissions analysis for the academic portfolio at <https://pcboss.me>. The workflow cleans a documented synthetic dataset, writes SQL summaries, saves charts, evaluates a prolonged-stay classifier, and opens the aggregates in a Streamlit dashboard.

The reference project [saqlain914/Hospital_Analytics](https://github.com/saqlain914/Hospital_Analytics) was inspected and not copied. GitHub reports no license for that repository. Its README cites `kanakbaghel/hospital-management-dataset`, while `src/extract.py` downloads `prasad22/healthcare-dataset`. This project uses the second source because it is the file that script retrieves, it includes admission date, discharge date, demographics, billed amount, and insurer, and the Kaggle page lists it as CC0 synthetic data. The kanakbaghel files are a small CC BY-SA 4.0 appointment schema and are not used here. RAG, Ollama, and Power BI components are omitted.

Measured findings are written to `outputs/portfolio-case-study.md` by the pipeline. They are not restated here, so the README cannot drift away from the latest run.

## Dataset

| Item | Value |
| --- | --- |
| Source | <https://www.kaggle.com/datasets/prasad22/healthcare-dataset> |
| Version used | 2 |
| License | CC0: Public Domain, as shown on the Kaggle page |
| Synthetic | Yes. The author states the file was generated with Python's Faker library and contains no real patient information |
| Citation | Patil, P. Healthcare Dataset (Version 2) [Data set]. Kaggle. |

The Kaggle file card still says 10,000 records. Version 2 is larger. The case study reports the measured row count and the SHA-256 of the file that was analyzed.

`kagglehub` downloads the public archive. A Kaggle API token was not required for this public dataset. The CSV is copied to `data/raw/healthcare_dataset.csv`, which is gitignored, along with any local SQLite file under `data/processed/`.

## Project layout

```
app.py                          Streamlit dashboard over aggregate outputs
hospital_ops/                   acquire, clean, SQL, charts, model, case study
sql/schema.sql                  de-identified admissions table
sql/summaries.sql               named aggregate queries
tests/                          cleaning, SQL, and model checks
outputs/                        case study, results.json, figures, SQL tables
data/raw/                       gitignored source CSV
```

Public outputs do not include patient, doctor, or hospital names. The model does not use length of stay, discharge date, billed amount, medication, or test result as features. Those fields either define the label or are not known to be available at admission in this file.

## Reproduce

From this directory, on Python 3.11 or newer:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m hospital_ops.pipeline
python -m pytest
python -m streamlit run app.py
```

The pipeline is deterministic given the same source file: the train/test split and the ROC-AUC bootstrap use seed 42. Prolonged stay is pre-specified as length of stay greater than 7 days, with a second pre-specified cut at greater than 14 days. The cuts are not selected by scanning test AUC.

## Tests

`tests/test_clean.py` checks duplicate removal, negative billed amounts, impossible dates, identifier removal, and length of stay.

`tests/test_sql.py` checks that the named queries reproduce counts and the median stay.

`tests/test_model.py` checks that admission-time features exclude the label and other blocked columns, and that held-out metrics stay inside valid bounds.

## Dashboard

`app.py` reads `outputs/results.json`, `outputs/tables/`, and `outputs/figures/`. It does not open the raw CSV. If those outputs are missing, the page shows the pipeline command.

## Limitations

The source is synthetic. Category mixes and stay lengths in this file are descriptive of the generator, not of a hospital. Model metrics in the case study are held-out measurements for this file only. See that note for the run-specific limits, including the bootstrap procedure and the fields kept out of the classifier.
