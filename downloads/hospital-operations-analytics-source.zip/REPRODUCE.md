﻿# Reproduction

This archive is the implementation only. It does not include the raw CSV, a generated database, or patient-level records, including synthetic names.

The published page is https://pcboss.me/projects/hospital-operations-analytics/

## Requirements

Python 3.11 or newer, then:

```powershell
python -m pip install -r requirements.txt
```

## Tests

```powershell
python -m pytest
```

The tests check cleaning, SQL summaries, and the model feature rules. They do not need the raw CSV.

## Pipeline

Download version 2 of prasad22/healthcare-dataset from Kaggle yourself and place healthcare_dataset.csv in data/raw/, then:

```powershell
python -m hospital_ops.pipeline
python -m streamlit run app.py
```

app.py reads outputs/results.json, outputs/tables/, and outputs/figures/. It does not open the raw CSV. If those outputs are missing, it shows the pipeline command.

The dataset is synthetic. The Kaggle author states it was generated with Python Faker and contains no real patient information. The published model results are held-out measurements on that file: ROC-AUC 0.496 for stays longer than 7 days and 0.499 for stays longer than 14 days. That is chance discrimination, not a validated clinical predictor.

Prolonged stay is pre-specified as length of stay greater than 7 days, with a second pre-specified cut at greater than 14 days. The split seed is 42.
