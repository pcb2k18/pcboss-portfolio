"""SQLite summaries and descriptive checks on the cleaned cohort."""

from __future__ import annotations

import re
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from hospital_ops.paths import SQL_DIR

QUERY_SPLIT = re.compile(r"(?m)^-- name:\s*(\S+)\s*$")


def parse_named_sql(text: str) -> list[tuple[str, str]]:
    parts = QUERY_SPLIT.split(text)
    queries: list[tuple[str, str]] = []
    iterator = iter(parts[1:])
    for name, body in zip(iterator, iterator):
        statement = body.strip()
        if statement.endswith(";"):
            statement = statement[:-1].strip()
        if statement:
            queries.append((name, statement))
    if not queries:
        raise ValueError("No named SQL queries were found.")
    return queries


def load_sql_text(filename: str) -> str:
    return (SQL_DIR / filename).read_text(encoding="utf-8")


def run_sql(admissions: pd.DataFrame, table_dir: Path | None = None) -> dict[str, pd.DataFrame]:
    """Create the documented schema, load rows, and run the named summaries."""
    connection = sqlite3.connect(":memory:")
    try:
        connection.executescript(load_sql_text("schema.sql"))
        admissions.to_sql("admissions", connection, if_exists="append", index=False)
        tables: dict[str, pd.DataFrame] = {}
        for name, statement in parse_named_sql(load_sql_text("summaries.sql")):
            tables[name] = pd.read_sql_query(statement, connection)
        if table_dir is not None:
            table_dir.mkdir(parents=True, exist_ok=True)
            for name, table in tables.items():
                table.to_csv(table_dir / f"{name}.csv", index=False)
        return tables
    finally:
        connection.close()


def category_balance(series: pd.Series) -> dict:
    """Compare a categorical field with an equal-share distribution."""
    counts = series.astype(str).value_counts()
    shares = counts / counts.sum()
    equal_share = 1.0 / len(counts)
    chi2, p_value = stats.chisquare(counts.to_numpy())
    return {
        "levels": int(len(counts)),
        "min_share": float(shares.min()),
        "max_share": float(shares.max()),
        "max_abs_deviation_pp": float((shares - equal_share).abs().max() * 100),
        "chi2": float(chi2),
        "p_value": float(p_value),
    }


def discrete_uniform_balance(series: pd.Series, low: int, high: int) -> dict:
    observed = series.astype(int).value_counts()
    index = pd.RangeIndex(low, high + 1)
    counts = observed.reindex(index, fill_value=0).to_numpy(dtype=float)
    chi2, p_value = stats.chisquare(counts)
    shares = counts / counts.sum()
    equal_share = 1.0 / len(index)
    order = np.argsort(counts, kind="mergesort")
    highest_idx = int(np.argmax(counts))
    return {
        "support_min": int(low),
        "support_max": int(high),
        "levels": int(len(index)),
        "max_abs_deviation_pp": float(np.max(np.abs(shares - equal_share)) * 100),
        "chi2": float(chi2),
        "chi2_df": int(len(index) - 1),
        "p_value": float(p_value),
        "equal_count": float(counts.mean()),
        "lowest_bins": [
            {"value": int(index[idx]), "count": int(counts[idx])}
            for idx in order[:3]
        ],
        "highest_bin": {"value": int(index[highest_idx]), "count": int(counts[highest_idx])},
    }


def uniformity_report(admissions: pd.DataFrame) -> dict:
    stay = admissions["length_of_stay"]
    age = admissions["age"]
    billing = admissions["billing_amount"]
    billing_min = float(billing.min())
    billing_max = float(billing.max())
    ks_stat, ks_p = stats.kstest(
        billing.to_numpy(),
        "uniform",
        args=(billing_min, billing_max - billing_min),
    )
    return {
        "gender": category_balance(admissions["gender"]),
        "blood_type": category_balance(admissions["blood_type"]),
        "medical_condition": category_balance(admissions["medical_condition"]),
        "admission_type": category_balance(admissions["admission_type"]),
        "insurance_provider": category_balance(admissions["insurance_provider"]),
        "medication": category_balance(admissions["medication"]),
        "test_result": category_balance(admissions["test_result"]),
        "admission_dow": category_balance(admissions["admission_dow"]),
        "length_of_stay": discrete_uniform_balance(stay, int(stay.min()), int(stay.max())),
        "age": discrete_uniform_balance(age, int(age.min()), int(age.max())),
        "billing_uniform_ks": {
            "statistic": float(ks_stat),
            "p_value": float(ks_p),
            "observed_min": billing_min,
            "observed_max": billing_max,
            "observed_mean": float(billing.mean()),
            "observed_midpoint": float((billing_min + billing_max) / 2),
        },
    }


def association_report(admissions: pd.DataFrame) -> dict:
    """Describe associations on the full cleaned cohort. Not used to pick a model."""
    stay = admissions["length_of_stay"]
    features = [
        "gender",
        "blood_type",
        "medical_condition",
        "admission_type",
        "insurance_provider",
        "admission_month_number",
        "admission_dow",
        "age_group",
        "medication",
        "test_result",
    ]
    target_7 = (stay > 7).astype(int)
    target_14 = (stay > 14).astype(int)
    return {
        "pearson_billing_length_of_stay": float(admissions["billing_amount"].corr(stay)),
        "spearman_billing_length_of_stay": float(
            admissions["billing_amount"].corr(stay, method="spearman")
        ),
        "pearson_age_length_of_stay": float(admissions["age"].corr(stay)),
        "spearman_age_length_of_stay": float(admissions["age"].corr(stay, method="spearman")),
        "cramers_v_gt7": {feature: _cramers_v(admissions[feature], target_7) for feature in features},
        "cramers_v_gt14": {
            feature: _cramers_v(admissions[feature], target_14) for feature in features
        },
    }


def _cramers_v(left: pd.Series, right: pd.Series) -> float:
    table = pd.crosstab(left, right)
    if table.shape[0] < 2 or table.shape[1] < 2:
        return 0.0
    chi2 = stats.chi2_contingency(table, correction=False)[0]
    n_obs = float(table.to_numpy().sum())
    denominator = n_obs * min(table.shape[0] - 1, table.shape[1] - 1)
    if denominator <= 0:
        return 0.0
    return float(np.sqrt(chi2 / denominator))


def admissions_trend(monthly: pd.DataFrame) -> dict:
    counts = monthly["admissions"].to_numpy(dtype=float)
    months = monthly["admission_month"].astype(str).tolist()
    if len(counts) < 3:
        slope = 0.0
        interior = monthly
    else:
        slope = float(np.polyfit(np.arange(len(counts)), counts, 1)[0])
        interior = monthly.iloc[1:-1]
    interior_counts = interior["admissions"].to_numpy(dtype=float)
    low_row = interior.loc[interior["admissions"].idxmin()]
    high_row = interior.loc[interior["admissions"].idxmax()]
    mean_count = float(counts.mean())
    interior_mean = float(interior_counts.mean())
    return {
        "months": int(len(counts)),
        "first_month": months[0],
        "last_month": months[-1],
        "first_month_admissions": int(counts[0]),
        "last_month_admissions": int(counts[-1]),
        "mean_admissions": mean_count,
        "min_admissions": int(counts.min()),
        "max_admissions": int(counts.max()),
        "interior_min_admissions": int(interior_counts.min()),
        "interior_max_admissions": int(interior_counts.max()),
        "interior_min_month": str(low_row["admission_month"]),
        "interior_max_month": str(high_row["admission_month"]),
        "interior_mean_admissions": interior_mean,
        "slope_admissions_per_month": slope,
        "interior_range_share_of_mean": float((interior_counts.max() - interior_counts.min()) / interior_mean),
    }
