-- De-identified admissions table. Patient, doctor, and hospital names are
-- not loaded. Prolonged-stay flags are calculated in the queries.

DROP TABLE IF EXISTS admissions;
CREATE TABLE admissions (
    admission_id INTEGER PRIMARY KEY,
    age INTEGER NOT NULL CHECK (age >= 0 AND age <= 120),
    age_group TEXT NOT NULL,
    gender TEXT NOT NULL,
    blood_type TEXT NOT NULL,
    medical_condition TEXT NOT NULL,
    admission_date TEXT NOT NULL,
    discharge_date TEXT NOT NULL,
    length_of_stay INTEGER NOT NULL CHECK (length_of_stay >= 0),
    admission_type TEXT NOT NULL,
    admission_year INTEGER NOT NULL,
    admission_month TEXT NOT NULL,
    admission_month_number INTEGER NOT NULL,
    admission_dow TEXT NOT NULL,
    insurance_provider TEXT NOT NULL,
    billing_amount REAL NOT NULL CHECK (billing_amount >= 0),
    medication TEXT NOT NULL,
    test_result TEXT NOT NULL
);
