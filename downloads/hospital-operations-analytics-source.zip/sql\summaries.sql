-- Named summaries for the cleaned admissions table.
-- Thresholds are literal: length_of_stay > 7 and length_of_stay > 14.

-- name: kpi_overview
SELECT
    COUNT(*) AS admissions,
    ROUND(AVG(length_of_stay), 2) AS mean_length_of_stay,
    (
        SELECT ROUND(AVG(length_of_stay), 2)
        FROM (
            SELECT length_of_stay
            FROM admissions
            ORDER BY length_of_stay
            LIMIT 2 - (SELECT COUNT(*) FROM admissions) % 2
            OFFSET (SELECT (COUNT(*) - 1) / 2 FROM admissions)
        ) AS middle_stays
    ) AS median_length_of_stay,
    ROUND(AVG(billing_amount), 2) AS mean_billing_amount,
    ROUND(MIN(billing_amount), 2) AS min_billing_amount,
    ROUND(MAX(billing_amount), 2) AS max_billing_amount,
    ROUND(100.0 * AVG(CASE WHEN length_of_stay > 7 THEN 1.0 ELSE 0.0 END), 2)
        AS prolonged_gt7_percent,
    ROUND(100.0 * AVG(CASE WHEN length_of_stay > 14 THEN 1.0 ELSE 0.0 END), 2)
        AS prolonged_gt14_percent,
    MIN(admission_date) AS first_admission,
    MAX(admission_date) AS last_admission
FROM admissions;

-- name: monthly_admissions
SELECT
    admission_month,
    COUNT(*) AS admissions,
    ROUND(AVG(length_of_stay), 2) AS mean_length_of_stay,
    ROUND(AVG(billing_amount), 2) AS mean_billing_amount
FROM admissions
GROUP BY admission_month
ORDER BY admission_month;

-- name: admissions_by_gender
SELECT
    gender,
    COUNT(*) AS admissions,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percent_of_admissions,
    ROUND(AVG(age), 2) AS mean_age,
    ROUND(AVG(length_of_stay), 2) AS mean_length_of_stay
FROM admissions
GROUP BY gender
ORDER BY gender;

-- name: admissions_by_age_group
SELECT
    age_group,
    COUNT(*) AS admissions,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percent_of_admissions,
    ROUND(AVG(length_of_stay), 2) AS mean_length_of_stay,
    ROUND(100.0 * AVG(CASE WHEN length_of_stay > 7 THEN 1.0 ELSE 0.0 END), 2)
        AS prolonged_gt7_percent
FROM admissions
GROUP BY age_group
ORDER BY CASE age_group
    WHEN '0-17' THEN 1
    WHEN '18-39' THEN 2
    WHEN '40-64' THEN 3
    WHEN '65+' THEN 4
    ELSE 5
END;

-- name: admissions_by_age_gender
SELECT
    age_group,
    gender,
    COUNT(*) AS admissions
FROM admissions
GROUP BY age_group, gender
ORDER BY CASE age_group
    WHEN '0-17' THEN 1
    WHEN '18-39' THEN 2
    WHEN '40-64' THEN 3
    WHEN '65+' THEN 4
    ELSE 5
END, gender;

-- name: stay_by_condition
SELECT
    medical_condition,
    COUNT(*) AS admissions,
    ROUND(AVG(length_of_stay), 2) AS mean_length_of_stay,
    ROUND(100.0 * AVG(CASE WHEN length_of_stay > 7 THEN 1.0 ELSE 0.0 END), 2)
        AS prolonged_gt7_percent,
    ROUND(100.0 * AVG(CASE WHEN length_of_stay > 14 THEN 1.0 ELSE 0.0 END), 2)
        AS prolonged_gt14_percent,
    ROUND(AVG(billing_amount), 2) AS mean_billing_amount
FROM admissions
GROUP BY medical_condition
ORDER BY medical_condition;

-- name: stay_by_admission_type
SELECT
    admission_type,
    COUNT(*) AS admissions,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percent_of_admissions,
    ROUND(AVG(length_of_stay), 2) AS mean_length_of_stay,
    ROUND(100.0 * AVG(CASE WHEN length_of_stay > 7 THEN 1.0 ELSE 0.0 END), 2)
        AS prolonged_gt7_percent,
    ROUND(100.0 * AVG(CASE WHEN length_of_stay > 14 THEN 1.0 ELSE 0.0 END), 2)
        AS prolonged_gt14_percent
FROM admissions
GROUP BY admission_type
ORDER BY admission_type;

-- name: billing_by_insurance
SELECT
    insurance_provider,
    COUNT(*) AS admissions,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percent_of_admissions,
    ROUND(AVG(billing_amount), 2) AS mean_billing_amount,
    ROUND(MIN(billing_amount), 2) AS min_billing_amount,
    ROUND(MAX(billing_amount), 2) AS max_billing_amount,
    ROUND(AVG(length_of_stay), 2) AS mean_length_of_stay
FROM admissions
GROUP BY insurance_provider
ORDER BY insurance_provider;

-- name: admissions_by_weekday
SELECT
    admission_dow,
    COUNT(*) AS admissions,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percent_of_admissions
FROM admissions
GROUP BY admission_dow
ORDER BY CASE admission_dow
    WHEN 'Monday' THEN 1
    WHEN 'Tuesday' THEN 2
    WHEN 'Wednesday' THEN 3
    WHEN 'Thursday' THEN 4
    WHEN 'Friday' THEN 5
    WHEN 'Saturday' THEN 6
    WHEN 'Sunday' THEN 7
    ELSE 8
END;
