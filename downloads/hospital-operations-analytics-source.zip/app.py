"""Streamlit view of the aggregate outputs. It does not read patient-level files."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

from hospital_ops.paths import CASE_STUDY_FILENAME, FIGURES, OUTPUTS, RESULTS_FILENAME, TABLES

st.set_page_config(
    page_title="Hospital Operations Analytics",
    layout="wide",
)

RESULTS_PATH = OUTPUTS / RESULTS_FILENAME


def main() -> None:
    st.title("Hospital Operations and Patient Care Analytics")
    st.caption("Academic portfolio project for https://pcboss.me")

    if not RESULTS_PATH.exists():
        st.error("Aggregate outputs are not built yet. From the project root, run: python -m hospital_ops.pipeline")
        return

    results = json.loads(RESULTS_PATH.read_text(encoding="utf-8"))
    source = results["source"]
    validation = results["validation"]
    kpis = results["kpis"]
    models = results["models"]

    st.info(
        f"Synthetic data. {source['citation']} License: {source['license_name']}. "
        "Patient, doctor, and hospital names are not loaded into this dashboard."
    )

    left, middle, right, far = st.columns(4)
    left.metric("Admissions", f"{int(kpis['admissions']):,}")
    middle.metric("Mean length of stay", f"{kpis['mean_length_of_stay']:.2f} days")
    right.metric("Mean billed amount", f"{kpis['mean_billing_amount']:,.0f}")
    far.metric("LOS > 7 days", f"{kpis['prolonged_gt7_percent']:.2f}%")
    st.caption(
        f"Cleaned cohort {validation['first_admission']} to {validation['last_admission']}. "
        f"Removed {validation['exact_duplicate_rows_removed']:,} exact duplicate rows and "
        f"{validation['negative_or_missing_billing_removed']:,} negative billed amounts. "
        "The source file does not name a currency."
    )

    overview, stays, billing, model_tab = st.tabs(
        ["Admissions and demographics", "Length of stay", "Billing and insurance", "Prolonged-stay model"]
    )
    with overview:
        _figure("01_monthly_admissions.png")
        _figure("02_admissions_by_age_and_gender.png")
        _show_table("admissions_by_age_group")
        _show_table("admissions_by_gender")
    with stays:
        _figure("03_length_of_stay.png")
        _figure("05_prolonged_stay_rates.png")
        _show_table("stay_by_condition")
        _show_table("stay_by_admission_type")
    with billing:
        _figure("04_billing.png")
        _show_table("billing_by_insurance")
    with model_tab:
        st.subheader("Admission-time classification")
        st.markdown(
            "Labels are `length of stay > 7` and `length of stay > 14`. "
            "Features are age, gender, blood type, medical condition, admission type, "
            "insurance provider, admission month, and weekday. "
            "Length of stay, discharge date, billed amount, medication, test result, "
            "and identifier fields are excluded."
        )
        _figure("06_prolonged_stay_roc.png")
        _model_table(models)
        st.caption("Held-out metrics from the pipeline. The ROC-AUC interval resamples test predictions and does not refit the model.")

    case_path = OUTPUTS / CASE_STUDY_FILENAME
    if case_path.exists():
        with st.expander("Portfolio case study"):
            st.markdown(case_path.read_text(encoding="utf-8"))


def _figure(name: str) -> None:
    path = FIGURES / name
    if path.exists():
        st.image(str(path), width="stretch")
    else:
        st.warning(f"Missing figure: {name}")


def _show_table(name: str) -> None:
    path = TABLES / f"{name}.csv"
    if not path.exists():
        st.warning(f"Missing table: {name}")
        return
    st.dataframe(_load_table(str(path)), width="stretch", hide_index=True)


@st.cache_data
def _load_table(path: str) -> pd.DataFrame:
    return pd.read_csv(path)


def _model_table(models: dict) -> None:
    rows = []
    for key, label in (("gt7", "LOS > 7"), ("gt14", "LOS > 14")):
        block = models["thresholds"][key]
        logistic = block["logistic"]
        baseline = block["baseline_majority"]
        low, high = block["test_roc_auc_bootstrap_95ci"]
        rows.append(
            {
                "Label": label,
                "Test positive rate": round(block["test_positive_rate"], 3),
                "Majority accuracy": round(baseline["accuracy"], 3),
                "Logistic accuracy": round(logistic["accuracy"], 3),
                "Logistic ROC-AUC": round(logistic["roc_auc"], 3),
                "AUC 95% interval": f"{low:.3f} to {high:.3f}",
                "Logistic Brier": round(logistic["brier_score"], 4),
                "Constant Brier": round(logistic["brier_constant_train_prevalence"], 4),
            }
        )
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)


if __name__ == "__main__":
    main()
