"""Write the portfolio case study from measured pipeline results."""

from __future__ import annotations

from hospital_ops.acquire import CITATION


def build_case_study(results: dict) -> str:
    source = results["source"]
    validation = results["validation"]
    uniform = results["uniformity"]
    associations = results["associations"]
    trend = results["trend"]
    kpis = results["kpis"]
    models = results["models"]
    spans = results["spans"]
    versions = results["versions"]
    gt7 = models["thresholds"]["gt7"]
    gt14 = models["thresholds"]["gt14"]

    retained = validation["rows_retained"]
    raw_rows = validation["raw_rows"]
    billing = uniform["billing_uniform_ks"]
    stay_balance = uniform["length_of_stay"]
    v7 = associations["cramers_v_gt7"]
    strongest_7 = max(v7, key=v7.get)

    return f"""# Hospital Operations and Patient Care Analytics

Portfolio case study for <https://pcboss.me>. Every count, rate, and model metric below comes from one local run of `python -m hospital_ops.pipeline`. The admissions file is synthetic. Nothing in this note is a clinical or operational recommendation for a real hospital.

## Source decision

The reference repository [saqlain914/Hospital_Analytics](https://github.com/saqlain914/Hospital_Analytics) has no GitHub-detected license, so its code was not copied. Its README points to `kanakbaghel/hospital-management-dataset`. Its extract script instead downloads `prasad22/healthcare-dataset`.

This project uses the file the extract script names:

- Source: {source["url"]}
- Version downloaded: {source["version"]}
- License shown on the Kaggle page: {source["license_name"]} (`{source["license_id"]}`)
- Author's description: synthetic records generated with Python's Faker library, with no real patient information
- Local file: `{source["local_file"]}` ({source["bytes"]:,} bytes)
- SHA-256: `{source["sha256"]}`

Citation: {CITATION}

`kanakbaghel/hospital-management-dataset` was not used. That Kaggle page lists CC BY-SA 4.0, and the files are a small synthetic appointment schema with contact fields and policy numbers rather than inpatient length of stay.

The Kaggle file card still says the CSV contains 10,000 records. The downloaded version 2 file contains **{raw_rows:,}** rows and 15 columns. This analysis uses that measured file.

## Cohort

| Check | Result |
| --- | ---: |
| Raw rows | {raw_rows:,} |
| Missing values | {validation["missing_values"]:,} |
| Exact duplicate rows removed | {validation["exact_duplicate_rows_removed"]:,} |
| Invalid age removed | {validation["invalid_age_removed"]:,} |
| Invalid dates removed | {validation["invalid_dates_removed"]:,} |
| Negative or missing billed amounts removed | {validation["negative_or_missing_billing_removed"]:,} |
| Blank categories removed | {validation["blank_categories_removed"]:,} |
| Rows retained | {retained:,} |
| First admission | {validation["first_admission"]} |
| Last admission | {validation["last_admission"]} |

Patient names, doctor names, hospital names, and room numbers are dropped before the analysis table is written. The raw file stays in `data/raw/` and is gitignored. The public outputs are aggregates, charts, and model metrics.

The raw file has {validation["unique_names"]:,} distinct names, {validation["unique_doctors"]:,} distinct doctor labels, {validation["unique_hospitals"]:,} distinct hospital labels, and {validation["unique_rooms"]:,} distinct room numbers. Doctor and hospital labels are nearly row-unique, so they are not a stable provider panel and are not ranked.

## Admissions

The cleaned cohort has **{int(kpis["admissions"]):,}** admissions from {kpis["first_admission"]} through {kpis["last_admission"]}, across {trend["months"]} calendar months.

Monthly volume averages {trend["mean_admissions"]:.0f} admissions. Interior months range from {trend["interior_min_admissions"]:,} in {trend["interior_min_month"]} to {trend["interior_max_admissions"]:,} in {trend["interior_max_month"]}, a spread equal to {trend["interior_range_share_of_mean"] * 100:.1f}% of the interior mean ({trend["interior_mean_admissions"]:.0f}). The fitted slope across all months is {trend["slope_admissions_per_month"]:.2f} admissions per month. The first observed day is {validation["first_admission"]} and the last is {validation["last_admission"]}. {trend["first_month"]} has {trend["first_month_admissions"]:,} admissions and {trend["last_month"]} has {trend["last_month_admissions"]:,}.

Gender shares: {_share_sentence(uniform["gender"])}
Admission-type shares: {_share_sentence(uniform["admission_type"])}
Weekday shares: {_share_sentence(uniform["admission_dow"])}

## Demographics and condition labels

Mean age is **{results["cohort"]["mean_age"]:.2f}** years. Observed ages run from {uniform["age"]["support_min"]} to {uniform["age"]["support_max"]}. {_age_tail_sentence(uniform["age"])} Age groups: {_age_group_sentence(results["age_groups"])}. Mean length of stay by age group runs from {_series_span(results["age_groups"], "mean_length_of_stay", "min"):.2f} to {_series_span(results["age_groups"], "mean_length_of_stay", "max"):.2f} days. The LOS > 7 share by age group runs from {_series_span(results["age_groups"], "prolonged_gt7_percent", "min"):.2f}% to {_series_span(results["age_groups"], "prolonged_gt7_percent", "max"):.2f}%.

Condition labels: {_share_sentence(uniform["medical_condition"])}
Blood types: {_share_sentence(uniform["blood_type"])}

For the categorical fields above, the gaps from an equal mix are fractions of a percentage point. With tens of thousands of rows, a chi-square test can still reject an exact equal mix. The percentage-point gap is the useful description. Age is the exception: the tails are thin, so an equal-count model for every integer age does not fit.

## Length of stay

Mean length of stay is **{kpis["mean_length_of_stay"]:.2f}** days and the median is **{kpis["median_length_of_stay"]:.2f}** days. Observed stays run from {stay_balance["support_min"]} to {stay_balance["support_max"]} days.

Against an equal count for every integer day in that range, the largest gap is {stay_balance["max_abs_deviation_pp"]:.2f} percentage points ({_p_phrase(stay_balance["p_value"])}, chi-square {stay_balance["chi2"]:.1f} on {stay_balance["chi2_df"]} degrees of freedom). The histogram is the visual check.

**{kpis["prolonged_gt7_percent"]:.2f}%** of stays are longer than 7 days, and **{kpis["prolonged_gt14_percent"]:.2f}%** are longer than 14 days. A discrete uniform distribution on days 1 through 30 would put about 76.7% of stays above 7 days and 50% above 14 days. The measured shares are close to those reference values, in line with the day-by-day counts.

Mean stay by condition spans {spans["condition_mean_los"]["min"]:.2f} to {spans["condition_mean_los"]["max"]:.2f} days. The LOS > 7 rate by condition spans {spans["condition_gt7"]["min"]:.2f}% to {spans["condition_gt7"]["max"]:.2f}%. By admission type, mean stay spans {spans["type_mean_los"]["min"]:.2f} to {spans["type_mean_los"]["max"]:.2f} days.

Pearson correlation between age and length of stay is {associations["pearson_age_length_of_stay"]:.4f} (Spearman {associations["spearman_age_length_of_stay"]:.4f}).

## Billing and insurance

The source does not name a currency. After removing {validation["negative_or_missing_billing_removed"]:,} negative billed amounts, the retained amounts run from {kpis["min_billing_amount"]:,.2f} to {kpis["max_billing_amount"]:,.2f}. The mean is **{kpis["mean_billing_amount"]:,.2f}** and the midpoint of the observed minimum and maximum is {billing["observed_midpoint"]:,.2f}.

The Kolmogorov-Smirnov statistic against a uniform distribution on that observed range is D = {billing["statistic"]:.4f} ({_p_phrase(billing["p_value"])}). D is the largest gap between the two cumulative distributions, here {billing["statistic"] * 100:.1f} percentage points. Insurer mean billed amounts still span only {spans["insurance_mean_billing"]["max"] - spans["insurance_mean_billing"]["min"]:,.2f}, from {spans["insurance_mean_billing"]["min"]:,.2f} to {spans["insurance_mean_billing"]["max"]:,.2f}. Insurer mix: {_share_sentence(uniform["insurance_provider"])}

Pearson correlation between billed amount and length of stay is {associations["pearson_billing_length_of_stay"]:.4f} (Spearman {associations["spearman_billing_length_of_stay"]:.4f}). {_correlation_sentence(associations["pearson_billing_length_of_stay"])} Medication labels: {_share_sentence(uniform["medication"])} Test-result labels: {_share_sentence(uniform["test_result"])}

## Prolonged-stay classification

Two labels were fixed before fitting:

- Primary: length of stay greater than 7 days.
- Second cut: length of stay greater than 14 days.

The cuts were not chosen to maximize test AUC. Stay length in this file runs from 1 to 30 days in nearly equal counts, so the 7-day rule marks a large majority of rows and a majority-class rule is a strong accuracy baseline.

The classifier is an unweighted logistic regression (`lbfgs`) inside a scikit-learn pipeline. Age is scaled, and the categorical fields are one-hot encoded, with the encoder fit on the training split only. The split is stratified, 80/20, `random_state=42`. A class-weighted logistic regression is a pre-specified sensitivity check on the same split. It is not used to pick a winner after seeing the test set.

Admission-time features: {", ".join(models["features"])}.

Excluded so they cannot define or leak the label: length of stay, both dates, billed amount, medication, test result, and identifier fields (name, doctor, hospital, room). Age group is omitted because age is already in the model. The full-cohort Cramér's V values below are descriptive. They were not used to add or drop features.

The largest Cramér's V with the 7-day label is **{v7[strongest_7]:.4f}** for `{strongest_7}`. {_cramers_sentence(v7[strongest_7])}

### Held-out results, LOS > 7

{_model_block(gt7)}

### Held-out results, LOS > 14

{_model_block(gt14)}

### Reading the model

{_model_reading(gt7, gt14)}

Train five-fold ROC-AUC for the unweighted model is {gt7["train_cv_roc_auc_mean"]:.3f} (standard deviation {gt7["train_cv_roc_auc_std"]:.3f}) for the 7-day label and {gt14["train_cv_roc_auc_mean"]:.3f} (standard deviation {gt14["train_cv_roc_auc_std"]:.3f}) for the 14-day label. {_cv_sentence(gt7)}

## What these measurements support

The file can demonstrate a reproducible cleaning, SQL, charting, and evaluation workflow. The measured margins between categories are small, stay length and billed amount track simple wide distributions, and the admission-time model does not separate prolonged stays from shorter stays in a way that would be useful even as a synthetic benchmark of predictive skill.

These measurements do not estimate bed demand, payment integrity, or clinical risk. The labels called medical condition, insurer, medication, and test result behave like assigned categories. Doctor and hospital fields do not identify a usable panel.

## Reproducibility

| Item | Value |
| --- | --- |
| Python | {versions["python"]} |
| pandas | {versions["pandas"]} |
| scikit-learn | {versions["scikit-learn"]} |
| SHA-256 | `{source["sha256"]}` |
| Split seed | {models["random_state"]} |
| Bootstrap draws for the ROC-AUC interval | {gt7["bootstrap_draws"]} |

Commands are in the project `README.md`. SQL summaries live in `sql/summaries.sql` and are exported to `outputs/tables/`. Charts are in `outputs/figures/`.

## Limitations

- The publisher describes the file as synthetic Faker output. It is not an extract from a hospital information system.
- No currency unit, geography, or care setting is defined beyond the column names.
- Negative billed amounts were removed rather than interpreted.
- Exact duplicate rows were removed. Repeated names can remain among the dropped identifier field; names are not an analysis key.
- One stratified split and training-set cross-validation are not an external validation.
- The ROC-AUC interval resamples the held-out predictions. It does not refit the model on each draw.
- Medication and test result were kept out of the classifier because the file does not say they were known at admission. Their full-cohort association with stay length is reported above and is small.
- A different stay threshold would change the positive rate. The two reported cuts were pre-specified; other cuts were not searched.
"""


def _share_sentence(balance: dict) -> str:
    return (
        f"{balance['levels']} levels, from {balance['min_share'] * 100:.2f}% to "
        f"{balance['max_share'] * 100:.2f}% "
        f"(largest gap from an equal share: {balance['max_abs_deviation_pp']:.2f} percentage points)."
    )


def _weighted_mean_age(results: dict) -> str:
    return f"{results['cohort']['mean_age']:.2f} years"


def _p_phrase(value: float) -> str:
    if value == 0.0:
        return "the float64 p-value underflows to 0"
    return f"p = {value:.3g}"


def _age_tail_sentence(balance: dict) -> str:
    lowest = ", ".join(
        f"{item['value']} ({item['count']:,} admissions)" for item in balance["lowest_bins"]
    )
    highest = balance["highest_bin"]
    return (
        f"The three least common ages are {lowest}. "
        f"The most common age is {highest['value']} with {highest['count']:,} admissions. "
        f"An equal split of the cleaned cohort would place about {balance['equal_count']:.0f} admissions "
        f"on each age from {balance['support_min']} through {balance['support_max']}. "
        f"The chi-square statistic against that equal split is {balance['chi2']:,.0f} "
        f"on {balance['chi2_df']} degrees of freedom, and {_p_phrase(balance['p_value'])}."
    )


def _age_group_sentence(rows: list[dict]) -> str:
    return "; ".join(
        f"{row['age_group']} {int(row['admissions']):,} ({float(row['percent_of_admissions']):.2f}%)"
        for row in rows
    )


def _series_span(rows: list[dict], key: str, which: str = "both") -> float:
    values = [float(row[key]) for row in rows]
    if which == "min":
        return min(values)
    if which == "max":
        return max(values)
    return min(values)


def _correlation_sentence(value: float) -> str:
    magnitude = abs(value)
    if magnitude < 0.05:
        return "That is a negligible linear association."
    if magnitude < 0.2:
        return "That is a weak linear association."
    return "That linear association is large enough to inspect in the scatter of aggregates."


def _cramers_sentence(value: float) -> str:
    if value < 0.05:
        return "A Cramér's V under 0.05 is a negligible association on the usual rule of thumb."
    if value < 0.1:
        return "A Cramér's V under 0.10 is a weak association."
    return "This Cramér's V is large enough to inspect category by category."


def _fmt_pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def _model_block(block: dict) -> str:
    logistic = block["logistic"]
    baseline = block["baseline_majority"]
    weighted = block["logistic_balanced_sensitivity"]
    low, high = block["test_roc_auc_bootstrap_95ci"]
    matrix = logistic["confusion_matrix"]
    return f"""Training rows {block["train_rows"]:,}; test rows {block["test_rows"]:,}. Positive rate {block["train_positive_rate"] * 100:.2f}% in training and {block["test_positive_rate"] * 100:.2f}% in test.

| Metric | Majority class | Logistic regression | Class-weighted logistic |
| --- | ---: | ---: | ---: |
| Accuracy | {_fmt_pct(baseline["accuracy"])} | {_fmt_pct(logistic["accuracy"])} | {_fmt_pct(weighted["accuracy"])} |
| Balanced accuracy | {_fmt_pct(baseline["balanced_accuracy"])} | {_fmt_pct(logistic["balanced_accuracy"])} | {_fmt_pct(weighted["balanced_accuracy"])} |
| Precision | {_fmt_pct(baseline["precision"])} | {_fmt_pct(logistic["precision"])} | {_fmt_pct(weighted["precision"])} |
| Recall | {_fmt_pct(baseline["recall"])} | {_fmt_pct(logistic["recall"])} | {_fmt_pct(weighted["recall"])} |
| F1 | {_fmt_pct(baseline["f1"])} | {_fmt_pct(logistic["f1"])} | {_fmt_pct(weighted["f1"])} |
| ROC-AUC | 0.500 reference | {logistic["roc_auc"]:.3f} | {weighted["roc_auc"]:.3f} |
| Average precision | {block["test_positive_rate"]:.3f} prevalence | {logistic["average_precision"]:.3f} | {weighted["average_precision"]:.3f} |
| Brier score |  | {logistic["brier_score"]:.4f} | {weighted["brier_score"]:.4f} |

The constant-prevalence Brier score on the test set is {logistic["brier_constant_train_prevalence"]:.4f}. The unweighted model's 95% bootstrap interval for ROC-AUC is {low:.3f} to {high:.3f} ({block["bootstrap_draws"]} resamples). Confusion matrix for the unweighted model at probability 0.5: TN {matrix["tn"]:,}, FP {matrix["fp"]:,}, FN {matrix["fn"]:,}, TP {matrix["tp"]:,}.
"""


def _model_reading(gt7: dict, gt14: dict) -> str:
    parts = [_auc_reading(gt7, "7-day"), _auc_reading(gt14, "14-day")]
    for label, block in (("7-day", gt7), ("14-day", gt14)):
        gap = block["logistic"]["accuracy"] - block["baseline_majority"]["accuracy"]
        parts.append(
            f"On the {label} label, unweighted accuracy minus majority-class accuracy is {gap * 100:.2f} percentage points."
        )
        brier_gap = (
            block["logistic"]["brier_constant_train_prevalence"] - block["logistic"]["brier_score"]
        )
        parts.append(
            f"On the {label} label, the constant-prevalence Brier score minus the model Brier score is {brier_gap:.4f} (positive means a lower model Brier score)."
        )
    return " ".join(parts)


def _auc_reading(block: dict, label: str) -> str:
    low, high = block["test_roc_auc_bootstrap_95ci"]
    auc = block["logistic"]["roc_auc"]
    if low <= 0.5 <= high:
        place = "includes 0.500"
    elif low > 0.5:
        place = "is entirely above 0.500"
    else:
        place = "is entirely below 0.500"
    width_note = "close to chance" if high < 0.55 and low > 0.45 else "away from a purely flat curve"
    return (
        f"The {label} held-out ROC-AUC is {auc:.3f} and its 95% interval {place}. "
        f"The interval sits {width_note}."
    )


def _cv_sentence(block: dict) -> str:
    auc = block["logistic"]["roc_auc"]
    gap = abs(block["train_cv_roc_auc_mean"] - auc)
    if gap < 0.02:
        return "The training cross-validation estimate and the held-out estimate differ by less than 0.02 AUC."
    return "The training cross-validation estimate and the held-out estimate differ by 0.02 AUC or more, so the single split should be read with that gap in view."
