"""Clean the admissions extract and record every exclusion."""

from __future__ import annotations

import pandas as pd

EXPECTED_COLUMNS = [
    "Name",
    "Age",
    "Gender",
    "Blood Type",
    "Medical Condition",
    "Date of Admission",
    "Doctor",
    "Hospital",
    "Insurance Provider",
    "Billing Amount",
    "Room Number",
    "Admission Type",
    "Discharge Date",
    "Medication",
    "Test Results",
]

COLUMN_MAP = {
    "Name": "patient_name",
    "Age": "age",
    "Gender": "gender",
    "Blood Type": "blood_type",
    "Medical Condition": "medical_condition",
    "Date of Admission": "admission_date",
    "Doctor": "doctor",
    "Hospital": "hospital",
    "Insurance Provider": "insurance_provider",
    "Billing Amount": "billing_amount",
    "Room Number": "room_number",
    "Admission Type": "admission_type",
    "Discharge Date": "discharge_date",
    "Medication": "medication",
    "Test Results": "test_result",
}

# Fixed before model fitting. LOS > 7 is a common operational prolonged-stay
# flag. LOS > 14 is a second pre-specified cut, reported so the result is
# not an artifact of one threshold. Neither cut is chosen by test AUC.
PROLONGED_STAY_DAYS = 7
EXTENDED_STAY_DAYS = 14
MAX_PLAUSIBLE_STAY_DAYS = 365

IDENTIFIER_COLUMNS = ["patient_name", "doctor", "hospital", "room_number"]

AGE_BINS = [-1, 17, 39, 64, 200]
AGE_LABELS = ["0-17", "18-39", "40-64", "65+"]


def _blank_mask(series: pd.Series) -> pd.Series:
    text = series.astype("string").str.strip()
    return series.isna() | text.isna() | text.eq("")


def clean_admissions(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Return a de-identified analysis table and a validation report.

    Exclusions are applied one after another. A row removed for an earlier
    reason is not counted again.
    """
    columns = [str(column).replace("\ufeff", "").strip() for column in raw.columns]
    frame = raw.copy()
    frame.columns = columns
    missing = [column for column in EXPECTED_COLUMNS if column not in frame.columns]
    if missing:
        raise ValueError(f"Source file is missing columns: {missing}")

    frame = frame.loc[:, EXPECTED_COLUMNS].rename(columns=COLUMN_MAP)
    for column in frame.select_dtypes(include="object").columns:
        frame[column] = frame[column].astype("string").str.strip()

    report: dict = {
        "raw_rows": int(len(frame)),
        "raw_columns": int(frame.shape[1]),
        "missing_values": int(frame.isna().sum().sum()),
        "unique_names": int(frame["patient_name"].nunique(dropna=True)),
        "unique_doctors": int(frame["doctor"].nunique(dropna=True)),
        "unique_hospitals": int(frame["hospital"].nunique(dropna=True)),
        "unique_rooms": int(pd.to_numeric(frame["room_number"], errors="coerce").nunique(dropna=True)),
    }

    duplicate_rows = int(frame.duplicated().sum())
    frame = frame.drop_duplicates().reset_index(drop=True)
    report["exact_duplicate_rows_removed"] = duplicate_rows
    report["rows_after_deduplication"] = int(len(frame))

    frame["age"] = pd.to_numeric(frame["age"], errors="coerce")
    frame["billing_amount"] = pd.to_numeric(frame["billing_amount"], errors="coerce")
    frame["room_number"] = pd.to_numeric(frame["room_number"], errors="coerce")
    frame["admission_date"] = pd.to_datetime(frame["admission_date"], errors="coerce")
    frame["discharge_date"] = pd.to_datetime(frame["discharge_date"], errors="coerce")
    frame["length_of_stay"] = (frame["discharge_date"] - frame["admission_date"]).dt.days

    def _exclude(table: pd.DataFrame, name: str, mask: pd.Series) -> pd.DataFrame:
        report[name] = int(mask.fillna(True).sum())
        return table.loc[~mask.fillna(True)].copy()

    age_invalid = (
        frame["age"].isna()
        | (frame["age"] < 0)
        | (frame["age"] > 120)
        | (frame["age"] % 1 != 0)
    )
    frame = _exclude(frame, "invalid_age_removed", age_invalid)

    dates_invalid = (
        frame["admission_date"].isna()
        | frame["discharge_date"].isna()
        | frame["length_of_stay"].isna()
        | (frame["length_of_stay"] < 0)
        | (frame["length_of_stay"] > MAX_PLAUSIBLE_STAY_DAYS)
    )
    frame = _exclude(frame, "invalid_dates_removed", dates_invalid)

    billing_invalid = frame["billing_amount"].isna() | (frame["billing_amount"] < 0)
    frame = _exclude(frame, "negative_or_missing_billing_removed", billing_invalid)

    category_columns = [
        "gender",
        "blood_type",
        "medical_condition",
        "admission_type",
        "insurance_provider",
        "medication",
        "test_result",
    ]
    categories_invalid = _blank_mask(frame[category_columns[0]])
    for column in category_columns[1:]:
        categories_invalid = categories_invalid | _blank_mask(frame[column])
    frame = _exclude(frame, "blank_categories_removed", categories_invalid)

    frame["gender"] = frame["gender"].str.title()
    frame["blood_type"] = frame["blood_type"].str.upper()
    frame["age"] = frame["age"].astype(int)
    frame["length_of_stay"] = frame["length_of_stay"].astype(int)
    frame["age_group"] = pd.cut(
        frame["age"],
        bins=AGE_BINS,
        labels=AGE_LABELS,
        right=True,
    ).astype(str)
    frame["admission_year"] = frame["admission_date"].dt.year.astype(int)
    frame["admission_month"] = frame["admission_date"].dt.strftime("%Y-%m")
    frame["admission_month_number"] = frame["admission_date"].dt.month.astype(int)
    frame["admission_dow"] = frame["admission_date"].dt.day_name()
    frame["admission_date"] = frame["admission_date"].dt.strftime("%Y-%m-%d")
    frame["discharge_date"] = frame["discharge_date"].dt.strftime("%Y-%m-%d")

    kept = frame.drop(columns=IDENTIFIER_COLUMNS).reset_index(drop=True)
    kept.insert(0, "admission_id", kept.index + 1)
    report["rows_retained"] = int(len(kept))
    report["columns_retained"] = [str(column) for column in kept.columns]
    report["identifier_columns_excluded"] = IDENTIFIER_COLUMNS
    report["prolonged_stay_days"] = PROLONGED_STAY_DAYS
    report["extended_stay_days"] = EXTENDED_STAY_DAYS
    report["first_admission"] = None if kept.empty else str(kept["admission_date"].min())
    report["last_admission"] = None if kept.empty else str(kept["admission_date"].max())
    return kept, report
