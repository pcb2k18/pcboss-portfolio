"""Static charts for the portfolio case study and dashboard."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve

from hospital_ops.clean import AGE_LABELS

BLUE = "#0F4C81"
TEAL = "#1F7A6B"
AMBER = "#C47B2B"
SLATE = "#52606D"
GRID = "#D9E2EC"
FOOTNOTE = "Synthetic data: Kaggle prasad22/healthcare-dataset, CC0."


def write_charts(
    admissions: pd.DataFrame,
    tables: dict[str, pd.DataFrame],
    curves: dict | None,
    figure_dir: Path,
    overall_gt7: float,
    overall_gt14: float,
) -> list[str]:
    figure_dir.mkdir(parents=True, exist_ok=True)
    _apply_style()
    paths = [
        _monthly(tables["monthly_admissions"], figure_dir / "01_monthly_admissions.png"),
        _age_gender(tables["admissions_by_age_gender"], figure_dir / "02_admissions_by_age_and_gender.png"),
        _length_of_stay(admissions, figure_dir / "03_length_of_stay.png"),
        _billing(admissions, tables["billing_by_insurance"], figure_dir / "04_billing.png"),
        _prolonged_rates(
            tables["stay_by_condition"],
            tables["stay_by_admission_type"],
            figure_dir / "05_prolonged_stay_rates.png",
            overall_gt7,
            overall_gt14,
        ),
    ]
    if curves is not None:
        paths.append(_roc(curves, figure_dir / "06_prolonged_stay_roc.png"))
    plt.close("all")
    return [path.name for path in paths]


def _apply_style() -> None:
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.titlesize": 13,
            "axes.titleweight": "semibold",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.edgecolor": SLATE,
            "axes.labelcolor": "#1C2833",
            "xtick.color": SLATE,
            "ytick.color": SLATE,
            "text.color": "#1C2833",
        }
    )


def _finish(fig: plt.Figure, path: Path) -> Path:
    fig.text(0.01, 0.01, FOOTNOTE, fontsize=8, color=SLATE)
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return path


def _monthly(table: pd.DataFrame, path: Path) -> Path:
    fig, ax = plt.subplots(figsize=(10, 4.6))
    x_pos = np.arange(len(table))
    ax.plot(x_pos, table["admissions"], color=BLUE, linewidth=1.8)
    ax.fill_between(x_pos, table["admissions"], color=BLUE, alpha=0.12)
    step = max(1, len(table) // 8)
    ax.set_xticks(x_pos[::step])
    ax.set_xticklabels(table["admission_month"].iloc[::step], rotation=40, ha="right")
    ax.set_ylabel("Admissions")
    ax.set_xlabel("Admission month")
    ax.set_title("Monthly admissions")
    ax.grid(axis="y", color=GRID)
    return _finish(fig, path)


def _age_gender(table: pd.DataFrame, path: Path) -> Path:
    pivot = (
        table.pivot(index="age_group", columns="gender", values="admissions")
        .reindex(AGE_LABELS)
        .fillna(0)
    )
    fig, ax = plt.subplots(figsize=(8, 4.6))
    x_pos = np.arange(len(pivot.index))
    width = 0.36
    genders = list(pivot.columns)
    colors = [BLUE, TEAL]
    ceiling = float(pivot.to_numpy().max()) if len(pivot) else 0
    for offset, gender in zip((-width / 2, width / 2), genders):
        color = colors[genders.index(gender) % len(colors)]
        bars = ax.bar(x_pos + offset, pivot[gender], width=width, label=gender, color=color)
        for rect in bars:
            height = rect.get_height()
            if ceiling and height < ceiling * 0.05:
                ax.annotate(
                    f"{int(height)}",
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 4),
                    textcoords="offset points",
                    ha="center",
                    va="bottom",
                    fontsize=8,
                    color=SLATE,
                )
    ax.set_xticks(x_pos)
    ax.set_xticklabels(pivot.index)
    ax.set_ylabel("Admissions")
    ax.set_xlabel("Age group")
    ax.set_title("Admissions by age group and gender")
    ax.legend(frameon=False)
    ax.grid(axis="y", color=GRID)
    return _finish(fig, path)


def _length_of_stay(admissions: pd.DataFrame, path: Path) -> Path:
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    bins = np.arange(0.5, 31.5, 1)
    ax.hist(
        admissions["length_of_stay"],
        bins=bins,
        color=BLUE,
        edgecolor="white",
    )
    ax.axvline(7.5, color=AMBER, linestyle="--", linewidth=1.4, label="LOS > 7 starts")
    ax.axvline(14.5, color=TEAL, linestyle="--", linewidth=1.4, label="LOS > 14 starts")
    ax.set_xlabel("Length of stay (days)")
    ax.set_ylabel("Admissions")
    ax.set_title("Length of stay")
    ax.legend(frameon=False)
    return _finish(fig, path)


def _billing(admissions: pd.DataFrame, by_insurance: pd.DataFrame, path: Path) -> Path:
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.6))
    axes[0].hist(admissions["billing_amount"], bins=40, color=BLUE, edgecolor="white")
    axes[0].set_title("Billed amount")
    axes[0].set_xlabel("Billed amount")
    axes[0].set_ylabel("Admissions")
    axes[1].bar(
        by_insurance["insurance_provider"],
        by_insurance["mean_billing_amount"],
        color=TEAL,
    )
    axes[1].set_ylim(0, max(by_insurance["mean_billing_amount"]) * 1.25)
    axes[1].tick_params(axis="x", rotation=30)
    axes[1].set_title("Mean billed amount by insurer")
    axes[1].set_ylabel("Mean billed amount")
    for axis in axes:
        axis.grid(axis="y", color=GRID)
    return _finish(fig, path)


def _prolonged_rates(
    by_condition: pd.DataFrame,
    by_type: pd.DataFrame,
    path: Path,
    overall_gt7: float,
    overall_gt14: float,
) -> Path:
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.8))
    _rate_bars(
        axes[0],
        by_condition["medical_condition"],
        by_condition["prolonged_gt7_percent"],
        by_condition["prolonged_gt14_percent"],
        "By medical condition",
    )
    _rate_bars(
        axes[1],
        by_type["admission_type"],
        by_type["prolonged_gt7_percent"],
        by_type["prolonged_gt14_percent"],
        "By admission type",
    )
    for axis in axes:
        axis.axhline(overall_gt7, color=BLUE, linestyle=":", linewidth=1)
        axis.axhline(overall_gt14, color=TEAL, linestyle=":", linewidth=1)
        axis.set_ylim(0, 100)
        axis.grid(axis="y", color=GRID)
    axes[0].set_ylabel("Share of admissions (%)")
    return _finish(fig, path)


def _rate_bars(axis, labels, gt7, gt14, title: str) -> None:
    x_pos = np.arange(len(labels))
    width = 0.38
    axis.bar(x_pos - width / 2, gt7, width=width, color=BLUE, label="LOS > 7")
    axis.bar(x_pos + width / 2, gt14, width=width, color=TEAL, label="LOS > 14")
    axis.set_xticks(x_pos)
    axis.set_xticklabels(labels, rotation=30, ha="right")
    axis.set_title(title)
    axis.legend(frameon=False, fontsize=9)


def _roc(curves: dict, path: Path) -> Path:
    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    styles = {"gt7": (BLUE, "LOS > 7"), "gt14": (TEAL, "LOS > 14")}
    for key, (color, label) in styles.items():
        curve = curves[key]
        fpr, tpr, _ = roc_curve(curve["y_true"], curve["scores"])
        ax.plot(fpr, tpr, color=color, linewidth=1.8, label=f"{label} (AUC {curve['auc']:.3f})")
    ax.plot([0, 1], [0, 1], color=SLATE, linestyle="--", linewidth=1, label="Chance (AUC 0.500)")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("Held-out ROC, admission-time model")
    ax.set_aspect("equal", adjustable="box")
    ax.legend(frameon=False, loc="lower right")
    return _finish(fig, path)
