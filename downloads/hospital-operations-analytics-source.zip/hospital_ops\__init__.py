"""Hospital operations analytics on a documented synthetic admissions file."""

__version__ = "1.0.0"
