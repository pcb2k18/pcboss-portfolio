"""Admission-time prolonged-stay models with a held-out evaluation."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RANDOM_STATE = 42
TEST_SIZE = 0.2
BOOTSTRAP_DRAWS = 500

# Known when the patient arrives. Month number is categorical so December is
# not treated as a larger quantity than January.
NUMERIC_FEATURES = ["age"]
CATEGORICAL_FEATURES = [
    "gender",
    "blood_type",
    "medical_condition",
    "admission_type",
    "insurance_provider",
    "admission_month_number",
    "admission_dow",
]
ADMISSION_FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

# Discharge timing defines the label. Billing, medication, and test results
# are recorded during the stay in this file, so they are not admission-time
# predictors. Names and room numbers are identifiers.
EXCLUDED_FEATURES = [
    "admission_id",
    "patient_name",
    "doctor",
    "hospital",
    "room_number",
    "admission_date",
    "discharge_date",
    "length_of_stay",
    "billing_amount",
    "medication",
    "test_result",
    "age_group",
    "admission_year",
    "admission_month",
]


def make_estimator(class_weight: str | None) -> Pipeline:
    encoder = ColumnTransformer(
        transformers=[
            ("numeric", StandardScaler(), NUMERIC_FEATURES),
            (
                "categorical",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                CATEGORICAL_FEATURES,
            ),
        ]
    )
    classifier = LogisticRegression(
        max_iter=1000,
        solver="lbfgs",
        class_weight=class_weight,
        random_state=RANDOM_STATE,
    )
    return Pipeline([("encoder", encoder), ("classifier", classifier)])


def evaluate_models(admissions: pd.DataFrame) -> tuple[dict, dict]:
    """Fit pre-specified models. Test metrics are computed once."""
    missing = [column for column in ADMISSION_FEATURES if column not in admissions.columns]
    if missing:
        raise ValueError(f"Cleaned table is missing model features: {missing}")
    overlap = sorted(set(ADMISSION_FEATURES) & set(EXCLUDED_FEATURES))
    if overlap:
        raise ValueError(f"Feature list overlaps excluded columns: {overlap}")

    results = {
        "random_state": RANDOM_STATE,
        "test_size": TEST_SIZE,
        "features": ADMISSION_FEATURES,
        "excluded_features": EXCLUDED_FEATURES,
        "estimator": "LogisticRegression(solver='lbfgs', max_iter=1000)",
        "thresholds": {},
    }
    curves = {}
    for name, threshold in (("gt7", 7), ("gt14", 14)):
        metrics, curve = _evaluate_threshold(admissions, threshold)
        results["thresholds"][name] = metrics
        curves[name] = curve
    return results, curves


def _evaluate_threshold(admissions: pd.DataFrame, threshold: int) -> tuple[dict, dict]:
    features = admissions.loc[:, ADMISSION_FEATURES].copy()
    features["admission_month_number"] = features["admission_month_number"].astype(str)
    target = (admissions["length_of_stay"] > threshold).astype(int)
    if target.nunique() < 2:
        raise ValueError(f"Threshold > {threshold} produced one class.")

    x_train, x_test, y_train, y_test = train_test_split(
        features,
        target,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=target,
    )
    y_train_np = y_train.to_numpy()
    y_test_np = y_test.to_numpy()

    primary = make_estimator(None)
    primary.fit(x_train, y_train)
    primary_scores = primary.predict_proba(x_test)[:, 1]
    primary_pred = (primary_scores >= 0.5).astype(int)

    balanced = make_estimator("balanced")
    balanced.fit(x_train, y_train)
    balanced_scores = balanced.predict_proba(x_test)[:, 1]
    balanced_pred = (balanced_scores >= 0.5).astype(int)

    majority = DummyClassifier(strategy="most_frequent", random_state=RANDOM_STATE)
    majority.fit(x_train, y_train)
    majority_pred = majority.predict(x_test)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    cv_scores = cross_val_score(
        make_estimator(None),
        x_train,
        y_train,
        cv=cv,
        scoring="roc_auc",
        n_jobs=1,
    )
    auc, auc_low, auc_high = _bootstrap_auc(y_test_np, primary_scores)
    train_prevalence = float(y_train_np.mean())
    constant_scores = np.full(len(y_test_np), train_prevalence)

    return (
        {
            "rule": f"length_of_stay > {threshold}",
            "threshold_days": threshold,
            "train_rows": int(len(y_train)),
            "test_rows": int(len(y_test)),
            "train_positive_rate": train_prevalence,
            "test_positive_rate": float(y_test_np.mean()),
            "majority_class_predicts_positive": bool(majority_pred[0] == 1),
            "baseline_majority": _classification_metrics(y_test_np, majority_pred, None),
            "logistic": _score_block(y_test_np, primary_pred, primary_scores, constant_scores),
            "logistic_balanced_sensitivity": _score_block(
                y_test_np, balanced_pred, balanced_scores, constant_scores
            ),
            "train_cv_roc_auc_mean": float(cv_scores.mean()),
            "train_cv_roc_auc_std": float(cv_scores.std(ddof=1)),
            "test_roc_auc_bootstrap_95ci": [auc_low, auc_high],
            "bootstrap_draws": BOOTSTRAP_DRAWS,
        },
        {"y_true": y_test_np, "scores": primary_scores, "auc": auc},
    )


def _score_block(
    y_true: np.ndarray,
    predicted: np.ndarray,
    scores: np.ndarray,
    constant_scores: np.ndarray,
) -> dict:
    metrics = _classification_metrics(y_true, predicted, scores)
    metrics["brier_score"] = float(brier_score_loss(y_true, scores))
    metrics["brier_constant_train_prevalence"] = float(brier_score_loss(y_true, constant_scores))
    metrics["average_precision"] = float(average_precision_score(y_true, scores))
    metrics["average_precision_prevalence_baseline"] = float(y_true.mean())
    return metrics


def _classification_metrics(
    y_true: np.ndarray,
    predicted: np.ndarray,
    scores: np.ndarray | None,
) -> dict:
    labels = [0, 1]
    matrix = confusion_matrix(y_true, predicted, labels=labels)
    metrics = {
        "accuracy": float(accuracy_score(y_true, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, predicted)),
        "precision": float(precision_score(y_true, predicted, zero_division=0)),
        "recall": float(recall_score(y_true, predicted, zero_division=0)),
        "f1": float(f1_score(y_true, predicted, zero_division=0)),
        "confusion_matrix": {
            "labels": labels,
            "tn": int(matrix[0, 0]),
            "fp": int(matrix[0, 1]),
            "fn": int(matrix[1, 0]),
            "tp": int(matrix[1, 1]),
        },
    }
    if scores is not None and len(np.unique(y_true)) > 1:
        metrics["roc_auc"] = float(roc_auc_score(y_true, scores))
    return metrics


def _bootstrap_auc(y_true: np.ndarray, scores: np.ndarray) -> tuple[float, float, float]:
    point = float(roc_auc_score(y_true, scores))
    rng = np.random.default_rng(RANDOM_STATE)
    draws = []
    n_obs = len(y_true)
    for _ in range(BOOTSTRAP_DRAWS):
        index = rng.integers(0, n_obs, n_obs)
        sample = y_true[index]
        if len(np.unique(sample)) < 2:
            continue
        draws.append(roc_auc_score(sample, scores[index]))
    if len(draws) < 20:
        return point, point, point
    low, high = np.percentile(draws, [2.5, 97.5])
    return point, float(low), float(high)
