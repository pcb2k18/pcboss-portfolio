"""Copy the Kaggle source file into the local raw-data directory."""

from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

from hospital_ops.paths import DATA_RAW, RAW_FILENAME

DATASET_SLUG = "prasad22/healthcare-dataset"
DATASET_VERSION = "2"
SOURCE_URL = "https://www.kaggle.com/datasets/prasad22/healthcare-dataset"
LICENSE_ID = "CC0-1.0"
LICENSE_NAME = "CC0: Public Domain"
SYNTHETIC = True
CITATION = (
    "Patil, P. Healthcare Dataset (Version 2) [Data set]. Kaggle. "
    "https://www.kaggle.com/datasets/prasad22/healthcare-dataset"
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_metadata(path: Path) -> dict:
    return {
        "slug": DATASET_SLUG,
        "version": DATASET_VERSION,
        "url": SOURCE_URL,
        "license_id": LICENSE_ID,
        "license_name": LICENSE_NAME,
        "synthetic": SYNTHETIC,
        "generator": "Python Faker, as stated by the dataset author on Kaggle",
        "citation": CITATION,
        "local_file": path.name,
        "bytes": path.stat().st_size,
        "sha256": file_sha256(path),
    }


def locate_or_download(raw_dir: Path | None = None) -> Path:
    """Return the local CSV, downloading the public Kaggle file if needed.

    kagglehub stores the official archive in the user cache and this function
    copies only that CSV into ``data/raw``. The raw file is gitignored.
    """
    destination_dir = raw_dir or DATA_RAW
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / RAW_FILENAME
    if destination.exists() and destination.stat().st_size > 0:
        return destination

    import kagglehub

    downloaded = Path(kagglehub.dataset_download(DATASET_SLUG))
    csv_files = sorted(downloaded.glob("*.csv"))
    if len(csv_files) != 1:
        found = [path.name for path in csv_files]
        raise RuntimeError(f"Expected one CSV in {downloaded}, found {found}.")
    shutil.copyfile(csv_files[0], destination)
    return destination
