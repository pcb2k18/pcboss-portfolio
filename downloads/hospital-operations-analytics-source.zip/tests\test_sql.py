from pathlib import Path

import pandas as pd

from hospital_ops.analysis import category_balance, parse_named_sql, run_sql
from hospital_ops.paths import SQL_DIR


def analysis_row(**overrides) -> dict:
    row = {
        "admission_id": 1,
        "age": 40,
        "age_group": "40-64",
        "gender": "Female",
        "blood_type": "O+",
        "medical_condition": "Asthma",
        "admission_date": "2021-01-01",
        "discharge_date": "2021-01-02",
        "length_of_stay": 1,
        "admission_type": "Elective",
        "admission_year": 2021,
        "admission_month": "2021-01",
        "admission_month_number": 1,
        "admission_dow": "Friday",
        "insurance_provider": "Aetna",
        "billing_amount": 1000.0,
        "medication": "Aspirin",
        "test_result": "Normal",
    }
    row.update(overrides)
    return row


def test_named_sql_includes_both_stay_thresholds():
    text = (SQL_DIR / "summaries.sql").read_text(encoding="utf-8")
    names = [name for name, _statement in parse_named_sql(text)]
    assert "kpi_overview" in names
    assert "billing_by_insurance" in names
    assert "length_of_stay > 7" in text
    assert "length_of_stay > 14" in text


def test_sql_counts_and_median_match_pandas(tmp_path: Path):
    rows = [
        analysis_row(admission_id=1, length_of_stay=1, admission_month="2021-01"),
        analysis_row(admission_id=2, length_of_stay=2, admission_month="2021-01", gender="Male"),
        analysis_row(admission_id=3, length_of_stay=3, admission_month="2021-02"),
        analysis_row(admission_id=4, length_of_stay=4, admission_month="2021-02"),
    ]
    frame = pd.DataFrame(rows)
    tables = run_sql(frame, tmp_path)
    assert int(tables["kpi_overview"].loc[0, "admissions"]) == 4
    assert float(tables["kpi_overview"].loc[0, "median_length_of_stay"]) == 2.5
    assert tables["monthly_admissions"]["admissions"].sum() == 4
    monthly = tables["monthly_admissions"].set_index("admission_month")["admissions"]
    assert int(monthly["2021-01"]) == 2
    assert "patient_name" not in tables["kpi_overview"].columns
    assert float(frame["length_of_stay"].median()) == 2.5


def test_sql_median_for_odd_count():
    rows = [
        analysis_row(admission_id=index, length_of_stay=stay)
        for index, stay in enumerate([1, 2, 9], start=1)
    ]
    tables = run_sql(pd.DataFrame(rows))
    assert float(tables["kpi_overview"].loc[0, "median_length_of_stay"]) == 2.0


def test_category_balance_is_zero_for_equal_groups():
    balance = category_balance(pd.Series(["A", "A", "B", "B"]))
    assert balance["max_abs_deviation_pp"] == 0


def test_public_tables_omit_identifier_columns():
    tables = Path("outputs/tables")
    if not tables.exists():
        return
    banned = {"name", "patient_name", "doctor", "hospital", "room_number"}
    found = list(tables.glob("*.csv"))
    assert found
    for path in found:
        header = path.read_text(encoding="utf-8").splitlines()[0].lower()
        columns = {part.strip() for part in header.split(",")}
        assert columns.isdisjoint(banned)


def test_discrete_uniform_reports_the_rare_bin():
    from hospital_ops.analysis import discrete_uniform_balance

    balance = discrete_uniform_balance(pd.Series([1] * 10 + [2] * 10 + [3]), 1, 3)
    assert balance["lowest_bins"][0] == {"value": 3, "count": 1}
    assert balance["highest_bin"]["count"] == 10
    assert balance["chi2_df"] == 2
