from pathlib import Path

import pandas as pd
import pytest

from hospital_ops.clean import clean_admissions


def raw_row(**overrides) -> dict:
    row = {
        "Name": "Alex Example",
        "Age": 40,
        "Gender": "Female",
        "Blood Type": "O+",
        "Medical Condition": "Asthma",
        "Date of Admission": "2021-01-01",
        "Doctor": "Dr Example",
        "Hospital": "Example Hospital",
        "Insurance Provider": "Aetna",
        "Billing Amount": 1200.5,
        "Room Number": 210,
        "Admission Type": "Elective",
        "Discharge Date": "2021-01-11",
        "Medication": "Aspirin",
        "Test Results": "Normal",
    }
    row.update(overrides)
    return row


def cleaned(rows: list[dict]) -> tuple[pd.DataFrame, dict]:
    return clean_admissions(pd.DataFrame(rows))


def test_length_of_stay_is_discharge_minus_admission():
    frame, report = cleaned([raw_row()])
    assert report["rows_retained"] == 1
    assert int(frame.loc[0, "length_of_stay"]) == 10
    assert frame.loc[0, "admission_month"] == "2021-01"
    assert frame.loc[0, "age_group"] == "40-64"


def test_exact_duplicates_are_removed_once():
    frame, report = cleaned([raw_row(), raw_row(), raw_row(Name="Blair Example", Age=70)])
    assert report["exact_duplicate_rows_removed"] == 1
    assert report["rows_retained"] == 2
    assert set(frame["age_group"]) == {"40-64", "65+"}


def test_negative_billing_is_removed_and_names_are_not_kept():
    frame, report = cleaned([raw_row(), raw_row(Name="Casey Example", **{"Billing Amount": -15})])
    assert report["negative_or_missing_billing_removed"] == 1
    assert report["rows_retained"] == 1
    assert "patient_name" not in frame.columns
    assert "doctor" not in frame.columns
    assert "hospital" not in frame.columns
    assert "Name" not in frame.columns


def test_invalid_dates_are_counted_before_billing():
    _frame, report = cleaned(
        [
            raw_row(
                Name="Drew Example",
                **{"Date of Admission": "2021-02-10", "Discharge Date": "2021-02-01", "Billing Amount": -5},
            )
        ]
    )
    assert report["invalid_dates_removed"] == 1
    assert report["negative_or_missing_billing_removed"] == 0
    assert report["rows_retained"] == 0


def test_fractional_age_is_removed():
    _frame, report = cleaned([raw_row(Age=40.5)])
    assert report["invalid_age_removed"] == 1
    assert report["rows_retained"] == 0


def test_whitespace_is_stripped():
    frame, _report = cleaned([raw_row(Gender=" female ", **{"Blood Type": " o+ "})])
    assert frame.loc[0, "gender"] == "Female"
    assert frame.loc[0, "blood_type"] == "O+"


def test_missing_source_column_raises():
    with pytest.raises(ValueError):
        clean_admissions(pd.DataFrame([{"Name": "Alex Example"}]))


def test_project_gitignore_excludes_patient_level_files():
    text = Path(".gitignore").read_text(encoding="utf-8")
    assert "data/raw/" in text
    assert "data/processed/" in text
    assert "*.sqlite" in text
