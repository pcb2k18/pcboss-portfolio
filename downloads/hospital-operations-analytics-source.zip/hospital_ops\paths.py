from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROCESSED = ROOT / "data" / "processed"
OUTPUTS = ROOT / "outputs"
FIGURES = OUTPUTS / "figures"
TABLES = OUTPUTS / "tables"
SQL_DIR = ROOT / "sql"

RAW_FILENAME = "healthcare_dataset.csv"
RESULTS_FILENAME = "results.json"
CASE_STUDY_FILENAME = "portfolio-case-study.md"
