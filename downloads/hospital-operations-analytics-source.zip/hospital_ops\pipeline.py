"""Run cleaning, SQL summaries, charts, the stay model, and the case study."""

from __future__ import annotations

import json
import platform
from importlib.metadata import version

import pandas as pd

from hospital_ops import __version__
from hospital_ops.acquire import locate_or_download, source_metadata
from hospital_ops.analysis import admissions_trend, association_report, run_sql, uniformity_report
from hospital_ops.charts import write_charts
from hospital_ops.clean import IDENTIFIER_COLUMNS, clean_admissions
from hospital_ops.model import evaluate_models
from hospital_ops.paths import CASE_STUDY_FILENAME, FIGURES, OUTPUTS, RESULTS_FILENAME, TABLES
from hospital_ops.report import build_case_study


def main() -> None:
    raw_path = locate_or_download()
    raw = pd.read_csv(raw_path)
    admissions, validation = clean_admissions(raw)
    _reject_identifiers(admissions)

    tables = run_sql(admissions, TABLES)
    kpis = _as_record(tables["kpi_overview"].iloc[0])
    if int(kpis["admissions"]) != len(admissions):
        raise RuntimeError("SQL admission count does not match the cleaned table.")
    pandas_median = float(admissions["length_of_stay"].median())
    if abs(pandas_median - float(kpis["median_length_of_stay"])) > 0.011:
        raise RuntimeError("SQL median length of stay does not match pandas.")

    results = {
        "project_version": __version__,
        "source": source_metadata(raw_path),
        "validation": validation,
        "uniformity": uniformity_report(admissions),
        "associations": association_report(admissions),
        "trend": admissions_trend(tables["monthly_admissions"]),
        "kpis": kpis,
        "age_groups": _records(tables["admissions_by_age_group"]),
        "cohort": {"mean_age": float(admissions["age"].mean())},
        "spans": {
            "condition_mean_los": _span(tables["stay_by_condition"]["mean_length_of_stay"]),
            "condition_gt7": _span(tables["stay_by_condition"]["prolonged_gt7_percent"]),
            "type_mean_los": _span(tables["stay_by_admission_type"]["mean_length_of_stay"]),
            "insurance_mean_billing": _span(tables["billing_by_insurance"]["mean_billing_amount"]),
        },
        "versions": {
            "python": platform.python_version(),
            "pandas": version("pandas"),
            "numpy": version("numpy"),
            "scikit-learn": version("scikit-learn"),
            "scipy": version("scipy"),
            "matplotlib": version("matplotlib"),
            "streamlit": version("streamlit"),
        },
    }
    model_results, curves = evaluate_models(admissions)
    results["models"] = model_results
    results["figures"] = write_charts(
        admissions,
        tables,
        curves,
        FIGURES,
        overall_gt7=float(kpis["prolonged_gt7_percent"]),
        overall_gt14=float(kpis["prolonged_gt14_percent"]),
    )

    OUTPUTS.mkdir(parents=True, exist_ok=True)
    results_path = OUTPUTS / RESULTS_FILENAME
    case_path = OUTPUTS / CASE_STUDY_FILENAME
    results_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    case_path.write_text(build_case_study(results), encoding="utf-8")
    print(f"Retained admissions: {validation['rows_retained']}")
    print(f"Wrote {results_path}")
    print(f"Wrote {case_path}")


def _reject_identifiers(admissions: pd.DataFrame) -> None:
    present = [column for column in IDENTIFIER_COLUMNS if column in admissions.columns]
    if present or "patient_name" in admissions.columns or "Name" in admissions.columns:
        raise RuntimeError(f"Identifier columns reached the analysis table: {present}")


def _span(series: pd.Series) -> dict:
    return {"min": float(series.min()), "max": float(series.max())}


def _records(table: pd.DataFrame) -> list[dict]:
    return [_as_record(row) for _, row in table.iterrows()]


def _as_record(row: pd.Series) -> dict:
    record = {}
    for key, value in row.items():
        if pd.isna(value):
            record[str(key)] = None
        elif hasattr(value, "item"):
            record[str(key)] = value.item()
        else:
            record[str(key)] = value
    return record


if __name__ == "__main__":
    main()
