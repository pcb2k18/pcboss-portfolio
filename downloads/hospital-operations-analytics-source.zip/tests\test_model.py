import numpy as np
import pandas as pd

from hospital_ops.clean import clean_admissions
from hospital_ops.model import ADMISSION_FEATURES, EXCLUDED_FEATURES, evaluate_models, make_estimator
from tests.test_clean import raw_row


def test_admission_features_do_not_include_leakage_columns():
    assert set(ADMISSION_FEATURES).isdisjoint(EXCLUDED_FEATURES)
    blocked = {
        "length_of_stay",
        "discharge_date",
        "admission_date",
        "billing_amount",
        "medication",
        "test_result",
        "patient_name",
        "doctor",
        "hospital",
        "room_number",
    }
    assert blocked.isdisjoint(ADMISSION_FEATURES)


def test_unknown_category_is_ignored():
    train = pd.DataFrame(
        {
            "age": [30, 50, 70],
            "gender": ["Female", "Female", "Female"],
            "blood_type": ["O+", "A+", "B+"],
            "medical_condition": ["Asthma", "Asthma", "Diabetes"],
            "admission_type": ["Elective", "Urgent", "Emergency"],
            "insurance_provider": ["Aetna", "Cigna", "Medicare"],
            "admission_month_number": ["1", "2", "3"],
            "admission_dow": ["Monday", "Tuesday", "Wednesday"],
        }
    )
    model = make_estimator(None)
    model.fit(train, [0, 1, 0])
    heldout = train.copy()
    heldout.loc[0, "gender"] = "Male"
    scores = model.predict_proba(heldout)
    assert scores.shape == (3, 2)


def test_heldout_metrics_stay_in_range():
    rng = np.random.default_rng(0)
    rows = []
    conditions = ["Asthma", "Diabetes", "Cancer"]
    insurers = ["Aetna", "Cigna", "Medicare"]
    types = ["Elective", "Urgent", "Emergency"]
    for index in range(240):
        admitted = pd.Timestamp("2020-01-01") + pd.Timedelta(days=int(rng.integers(0, 700)))
        stay = int(rng.integers(1, 31))
        rows.append(
            raw_row(
                Name=f"Person {index}",
                Age=int(rng.integers(18, 90)),
                Gender="Female" if index % 2 == 0 else "Male",
                **{
                    "Blood Type": "O+" if index % 2 == 0 else "A-",
                    "Medical Condition": conditions[index % 3],
                    "Date of Admission": admitted.strftime("%Y-%m-%d"),
                    "Discharge Date": (admitted + pd.Timedelta(days=stay)).strftime("%Y-%m-%d"),
                    "Insurance Provider": insurers[index % 3],
                    "Admission Type": types[index % 3],
                    "Billing Amount": float(rng.uniform(100, 5000)),
                },
            )
        )
    frame, _report = clean_admissions(pd.DataFrame(rows))
    results, curves = evaluate_models(frame)
    for key in ("gt7", "gt14"):
        block = results["thresholds"][key]
        auc = block["logistic"]["roc_auc"]
        low, high = block["test_roc_auc_bootstrap_95ci"]
        assert 0.0 <= auc <= 1.0
        assert low <= auc <= high
        assert block["train_rows"] + block["test_rows"] == len(frame)
        assert len(curves[key]["y_true"]) == block["test_rows"]
        assert "length_of_stay" not in results["features"]
        assert "billing_amount" not in results["features"]
