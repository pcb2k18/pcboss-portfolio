from hospital_ops.pipeline import main

if __name__ == "__main__":
    main()
