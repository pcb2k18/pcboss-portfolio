"""Load CSV extracts, clean them in DuckDB, and run the SQL questions."""

from __future__ import annotations

import json
from pathlib import Path

import duckdb
import pandas as pd

from src.config import ANALYSIS_YEAR, SQL_DIR

COLUMN_MAP = {
    "crm": {
        "msisdn": ("msisdn",),
        "gender": ("gender",),
        "year_of_birth": ("year_of_birth", "yearofbirth", "yob"),
        "system_status": ("system_status", "status"),
        "mobile_type": ("mobile_type", "mobiletype"),
        "value_segment": ("value_segment", "valuesegment", "segment"),
    },
    "revenue": {
        "msisdn": ("msisdn",),
        "week_number": ("week_number", "week", "weeknumber"),
        "revenue_usd": ("revenue_usd", "revenue", "amount_usd"),
    },
    "device": {
        "msisdn": ("msisdn",),
        "imei_tac": ("imei_tac", "tac", "imei"),
        "brand_name": ("brand_name", "brand"),
        "model_name": ("model_name", "model"),
        "os_name": ("os_name", "os"),
        "os_vendor": ("os_vendor", "vendor"),
    },
}

RESULT_TABLES = (
    "data_quality",
    "kpi_overview",
    "weekly_revenue",
    "revenue_by_mobile_type",
    "revenue_by_gender",
    "revenue_by_age_band",
    "crm_age_bands",
    "system_status_counts",
    "value_segment_counts",
    "weeks_per_customer",
    "device_brands",
    "device_os",
    "single_device_brand_revenue",
    "device_revenue_coverage",
)


def sql_path(path: Path) -> str:
    return path.resolve().as_posix().replace("'", "''")


def iter_statements(sql_text: str):
    buffer: list[str] = []
    for line in sql_text.splitlines():
        stripped = line.strip()
        if not buffer and (not stripped or stripped.startswith("--")):
            continue
        buffer.append(line)
        if stripped.endswith(";"):
            statement = "\n".join(buffer).strip()
            if statement.endswith(";"):
                statement = statement[:-1].strip()
            if statement:
                yield statement
            buffer = []
    tail = "\n".join(buffer).strip()
    if tail.endswith(";"):
        tail = tail[:-1].strip()
    if tail:
        yield tail


def execute_sql_file(connection: duckdb.DuckDBPyConnection, path: Path) -> None:
    script = path.read_text(encoding="utf-8")
    for statement in iter_statements(script):
        connection.execute(statement)


def _quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def canonicalize(connection: duckdb.DuckDBPyConnection, source_view: str, dest_view: str, role: str) -> None:
    described = connection.execute(f"DESCRIBE {source_view}").fetchall()
    available = {row[0].strip().lower(): row[0] for row in described}
    selected = []
    missing = []
    for canonical, aliases in COLUMN_MAP[role].items():
        found = None
        for alias in aliases:
            if alias in available:
                found = available[alias]
                break
        if found is None:
            missing.append(canonical)
            continue
        selected.append(f"{_quote_ident(found)} AS {canonical}")
    if missing:
        present = ", ".join(sorted(available)) or "(none)"
        raise ValueError(
            f"{role} file is missing {', '.join(missing)}. Columns found: {present}"
        )
    connection.execute(
        f"CREATE OR REPLACE VIEW {dest_view} AS SELECT {', '.join(selected)} FROM {source_view}"
    )


def load_csv_view(connection: duckdb.DuckDBPyConnection, view_name: str, path: Path) -> None:
    if not path.is_file():
        raise FileNotFoundError(path)
    connection.execute(
        f"""
        CREATE OR REPLACE VIEW {view_name} AS
        SELECT * FROM read_csv(
            '{sql_path(path)}',
            header = true,
            all_varchar = true,
            strict_mode = true
        )
        """
    )


def export_tables(connection: duckdb.DuckDBPyConnection, table_dir: Path) -> dict[str, pd.DataFrame]:
    table_dir.mkdir(parents=True, exist_ok=True)
    frames: dict[str, pd.DataFrame] = {}
    for name in RESULT_TABLES:
        frame = connection.execute(f"SELECT * FROM {name}").df()
        frame.to_csv(table_dir / f"{name}.csv", index=False)
        frames[name] = frame
    return frames


def add_week_changes(weekly: pd.DataFrame) -> pd.DataFrame:
    """Pandas step: week-to-week change on the SQL aggregate."""
    if weekly.empty:
        return weekly.copy()
    ordered = weekly.sort_values("week_number").reset_index(drop=True)
    ordered["revenue_change_usd"] = ordered["revenue_usd"].diff().round(2)
    ordered["revenue_change_pct"] = (ordered["revenue_usd"].pct_change() * 100).round(2)
    return ordered


def run_pipeline(
    crm_path: Path,
    revenue_path: Path,
    device_path: Path,
    output_dir: Path,
    source_kind: str,
    source_detail: dict | None = None,
) -> dict:
    """Clean and aggregate one extract. Returns a manifest of measured values."""
    if source_kind not in {"synthetic", "kaggle"}:
        raise ValueError("source_kind must be 'synthetic' or 'kaggle'")

    output_dir.mkdir(parents=True, exist_ok=True)
    table_dir = output_dir / "tables"
    connection = duckdb.connect(str(output_dir / "analysis.duckdb"))
    try:
        load_csv_view(connection, "crm_loaded", crm_path)
        load_csv_view(connection, "rev_loaded", revenue_path)
        load_csv_view(connection, "device_loaded", device_path)
        canonicalize(connection, "crm_loaded", "crm_input", "crm")
        canonicalize(connection, "rev_loaded", "rev_input", "revenue")
        canonicalize(connection, "device_loaded", "device_input", "device")
        connection.execute(
            "CREATE OR REPLACE TABLE analysis_params AS SELECT ?::INTEGER AS analysis_year",
            [ANALYSIS_YEAR],
        )
        execute_sql_file(connection, SQL_DIR / "clean.sql")
        execute_sql_file(connection, SQL_DIR / "analyze.sql")
        frames = export_tables(connection, table_dir)
        weekly = add_week_changes(frames["weekly_revenue"])
        weekly.to_csv(table_dir / "weekly_revenue.csv", index=False)
        frames["weekly_revenue"] = weekly

        from src.findings import write_findings
        from src.plots import write_figures

        figure_paths = write_figures(frames, output_dir / "figures", source_kind)
        findings_path = write_findings(
            frames,
            output_dir / "findings.md",
            source_kind=source_kind,
            figure_paths=figure_paths,
        )
        manifest = {
            "source_kind": source_kind,
            "kaggle_extract_was_loaded": source_kind == "kaggle",
            "analysis_year_assumption": ANALYSIS_YEAR,
            "inputs": {
                "crm": str(crm_path),
                "revenue": str(revenue_path),
                "device": str(device_path),
            },
            "source_detail": source_detail or {},
            "kpis": {
                row.metric: None if pd.isna(row.value) else float(row.value)
                for row in frames["kpi_overview"].itertuples(index=False)
            },
            "quality": {
                row.check_name: float(row.observed)
                for row in frames["data_quality"].itertuples(index=False)
            },
            "findings": str(findings_path),
            "figures": [str(path) for path in figure_paths],
        }
        manifest_path = output_dir / "run_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        manifest["manifest_path"] = str(manifest_path)
        return manifest
    finally:
        connection.close()
