"""Run the analytics pipeline on a synthetic sample or on local Kaggle files."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from src.config import OUTPUT_DIR, RAW_DIR, RAW_FILES, SYNTHETIC_DIR
from src.pipeline import run_pipeline
from src.synthetic_data import generate_synthetic_extract


def raw_paths(raw_dir: Path) -> dict[str, Path]:
    return {
        "crm": raw_dir / RAW_FILES["crm"],
        "revenue": raw_dir / RAW_FILES["revenue"],
        "device": raw_dir / RAW_FILES["device"],
    }


def detect_source(raw_dir: Path) -> str:
    paths = raw_paths(raw_dir)
    if all(path.is_file() for path in paths.values()):
        return "kaggle"
    return "synthetic"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Clean CRM, revenue, and device CSV files with DuckDB SQL, "
            "then write tables, charts, and findings."
        )
    )
    parser.add_argument(
        "--source",
        choices=("auto", "synthetic", "raw"),
        default="auto",
        help="auto uses data/raw when crm1.csv, rev1.csv, and device1.csv are all present.",
    )
    parser.add_argument("--raw-dir", type=Path, default=RAW_DIR)
    parser.add_argument("--synthetic-dir", type=Path, default=SYNTHETIC_DIR)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--seed", type=int, default=20261019)
    parser.add_argument("--customers", type=int, default=2000)
    parser.add_argument("--revenue-rows", type=int, default=4000)
    parser.add_argument("--device-rows", type=int, default=1800)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    chosen = args.source
    if chosen == "auto":
        chosen = "raw" if detect_source(args.raw_dir) == "kaggle" else "synthetic"

    if chosen == "raw":
        paths = raw_paths(args.raw_dir)
        missing = [str(path) for path in paths.values() if not path.is_file()]
        if missing:
            print("Kaggle CSV files were not found:", file=sys.stderr)
            for item in missing:
                print(f"  - {item}", file=sys.stderr)
            print(
                "Download the CC0 dataset when you have several GB free, "
                "or rerun with --source synthetic.",
                file=sys.stderr,
            )
            return 2
        detail = {"note": "Local files named like the Kaggle extract. This run counts those files."}
        source_kind = "kaggle"
        crm_path, revenue_path, device_path = paths["crm"], paths["revenue"], paths["device"]
    else:
        detail = generate_synthetic_extract(
            args.synthetic_dir,
            seed=args.seed,
            customer_count=args.customers,
            revenue_rows=args.revenue_rows,
            device_rows=args.device_rows,
        )
        source_kind = "synthetic"
        crm_path = args.synthetic_dir / "crm1.csv"
        revenue_path = args.synthetic_dir / "rev1.csv"
        device_path = args.synthetic_dir / "device1.csv"
        print("Using a synthetic extract. It is not the Kaggle dataset.")

    manifest = run_pipeline(
        crm_path=crm_path,
        revenue_path=revenue_path,
        device_path=device_path,
        output_dir=args.output_dir,
        source_kind=source_kind,
        source_detail=detail,
    )
    print(json.dumps({
        "source_kind": manifest["source_kind"],
        "kaggle_extract_was_loaded": manifest["kaggle_extract_was_loaded"],
        "kpis": manifest["kpis"],
        "findings": manifest["findings"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
