"""Telecom customer and revenue analytics."""

__version__ = "0.1.0"
