-- Aggregate questions. analysis_params is a one-row table created in Python.
-- Age bands use ANALYSIS_YEAR minus year_of_birth. The source has no
-- transaction year, so the band is an assumption, not a birthday.

CREATE OR REPLACE MACRO age_band(birth_year, analysis_year) AS
CASE
    WHEN birth_year IS NULL THEN 'UNKNOWN_BIRTH_YEAR'
    WHEN analysis_year - birth_year < 25 THEN 'UNDER_25'
    WHEN analysis_year - birth_year < 35 THEN '25_34'
    WHEN analysis_year - birth_year < 45 THEN '35_44'
    WHEN analysis_year - birth_year < 55 THEN '45_54'
    WHEN analysis_year - birth_year < 65 THEN '55_64'
    ELSE '65_PLUS'
END;

CREATE OR REPLACE TABLE kpi_overview AS
SELECT 'crm_customers' AS metric, COUNT(*)::DOUBLE AS value
FROM crm_clean
UNION ALL
SELECT 'revenue_rows', COUNT(*)::DOUBLE FROM rev_clean
UNION ALL
SELECT 'paying_customers', COUNT(DISTINCT msisdn)::DOUBLE FROM rev_clean
UNION ALL
SELECT 'device_rows', COUNT(*)::DOUBLE FROM device_clean
UNION ALL
SELECT 'device_customers', COUNT(DISTINCT msisdn)::DOUBLE FROM device_clean
UNION ALL
SELECT 'total_revenue_usd', ROUND(COALESCE(SUM(revenue_usd), 0), 2)::DOUBLE FROM rev_clean
UNION ALL
SELECT 'avg_transaction_usd', ROUND(AVG(revenue_usd), 2)::DOUBLE FROM rev_clean
UNION ALL
SELECT 'arpu_usd',
    ROUND(
        SUM(revenue_usd) / NULLIF(COUNT(DISTINCT msisdn), 0),
        2
    )::DOUBLE
FROM rev_clean
UNION ALL
SELECT 'matched_paying_customers', COUNT(DISTINCT r.msisdn)::DOUBLE
FROM rev_clean r
INNER JOIN crm_clean c ON r.msisdn = c.msisdn
UNION ALL
SELECT 'orphan_revenue_usd',
    ROUND(COALESCE(SUM(r.revenue_usd), 0), 2)::DOUBLE
FROM rev_clean r
LEFT JOIN crm_clean c ON r.msisdn = c.msisdn
WHERE c.msisdn IS NULL
UNION ALL
SELECT 'matched_revenue_usd',
    ROUND(COALESCE(SUM(r.revenue_usd), 0), 2)::DOUBLE
FROM rev_clean r
INNER JOIN crm_clean c ON r.msisdn = c.msisdn;

CREATE OR REPLACE TABLE weekly_revenue AS
SELECT
    week_number,
    COUNT(*) AS transactions,
    COUNT(DISTINCT msisdn) AS active_customers,
    ROUND(SUM(revenue_usd), 2) AS revenue_usd,
    ROUND(AVG(revenue_usd), 2) AS avg_transaction_usd
FROM rev_clean
GROUP BY week_number
ORDER BY week_number;

CREATE OR REPLACE TABLE revenue_by_mobile_type AS
SELECT
    CASE
        WHEN c.msisdn IS NULL THEN 'UNMATCHED'
        ELSE c.mobile_type
    END AS mobile_type,
    COUNT(*) AS transactions,
    COUNT(DISTINCT r.msisdn) AS customers,
    ROUND(SUM(r.revenue_usd), 2) AS revenue_usd,
    ROUND(AVG(r.revenue_usd), 2) AS avg_transaction_usd
FROM rev_clean r
LEFT JOIN crm_clean c ON r.msisdn = c.msisdn
GROUP BY 1
ORDER BY revenue_usd DESC;

CREATE OR REPLACE TABLE revenue_by_gender AS
SELECT
    CASE
        WHEN c.msisdn IS NULL THEN 'UNMATCHED'
        ELSE c.gender
    END AS gender,
    COUNT(*) AS transactions,
    COUNT(DISTINCT r.msisdn) AS customers,
    ROUND(SUM(r.revenue_usd), 2) AS revenue_usd
FROM rev_clean r
LEFT JOIN crm_clean c ON r.msisdn = c.msisdn
GROUP BY 1
ORDER BY revenue_usd DESC;

CREATE OR REPLACE TABLE revenue_by_age_band AS
SELECT
    CASE
        WHEN c.msisdn IS NULL THEN 'UNMATCHED'
        ELSE age_band(c.year_of_birth, p.analysis_year)
    END AS age_band,
    COUNT(*) AS transactions,
    COUNT(DISTINCT r.msisdn) AS customers,
    ROUND(SUM(r.revenue_usd), 2) AS revenue_usd
FROM rev_clean r
LEFT JOIN crm_clean c ON r.msisdn = c.msisdn
CROSS JOIN analysis_params p
GROUP BY 1
ORDER BY
    CASE
        WHEN age_band = 'UNDER_25' THEN 1
        WHEN age_band = '25_34' THEN 2
        WHEN age_band = '35_44' THEN 3
        WHEN age_band = '45_54' THEN 4
        WHEN age_band = '55_64' THEN 5
        WHEN age_band = '65_PLUS' THEN 6
        WHEN age_band = 'UNKNOWN_BIRTH_YEAR' THEN 7
        WHEN age_band = 'UNMATCHED' THEN 8
        ELSE 9
    END;

CREATE OR REPLACE TABLE crm_age_bands AS
SELECT
    age_band(c.year_of_birth, p.analysis_year) AS age_band,
    COUNT(*) AS customers
FROM crm_clean c
CROSS JOIN analysis_params p
GROUP BY 1
ORDER BY
    CASE
        WHEN age_band = 'UNDER_25' THEN 1
        WHEN age_band = '25_34' THEN 2
        WHEN age_band = '35_44' THEN 3
        WHEN age_band = '45_54' THEN 4
        WHEN age_band = '55_64' THEN 5
        WHEN age_band = '65_PLUS' THEN 6
        WHEN age_band = 'UNKNOWN_BIRTH_YEAR' THEN 7
        ELSE 8
    END;

CREATE OR REPLACE TABLE system_status_counts AS
SELECT system_status, COUNT(*) AS customers
FROM crm_clean
GROUP BY 1
ORDER BY customers DESC;

CREATE OR REPLACE TABLE value_segment_counts AS
SELECT value_segment, COUNT(*) AS customers
FROM crm_clean
GROUP BY 1
ORDER BY customers DESC;

CREATE OR REPLACE TABLE weeks_per_customer AS
SELECT weeks_active, COUNT(*) AS customers
FROM (
    SELECT msisdn, COUNT(DISTINCT week_number) AS weeks_active
    FROM rev_clean
    GROUP BY msisdn
) activity
GROUP BY weeks_active
ORDER BY weeks_active;

CREATE OR REPLACE TABLE device_brands AS
SELECT
    brand_name,
    COUNT(*) AS device_rows,
    COUNT(DISTINCT msisdn) AS customers
FROM device_clean
GROUP BY brand_name
ORDER BY device_rows DESC, brand_name;

CREATE OR REPLACE TABLE device_os AS
SELECT
    os_name,
    COUNT(*) AS device_rows,
    COUNT(DISTINCT msisdn) AS customers
FROM device_clean
GROUP BY os_name
ORDER BY device_rows DESC, os_name;

-- Revenue attributed to a brand only when the customer has exactly one
-- cleaned device row. Customers with several devices are reported separately
-- so a single payment is not assigned to every handset they hold.
CREATE OR REPLACE TABLE single_device_brand_revenue AS
WITH device_counts AS (
    SELECT msisdn, COUNT(*) AS device_rows, MIN(brand_name) AS brand_name
    FROM device_clean
    GROUP BY msisdn
),
one_device AS (
    SELECT msisdn, brand_name
    FROM device_counts
    WHERE device_rows = 1
)
SELECT
    d.brand_name,
    COUNT(DISTINCT d.msisdn) AS customers,
    ROUND(SUM(r.revenue_usd), 2) AS revenue_usd
FROM one_device d
INNER JOIN rev_clean r ON r.msisdn = d.msisdn
GROUP BY d.brand_name
ORDER BY revenue_usd DESC, d.brand_name;

CREATE OR REPLACE TABLE device_revenue_coverage AS
WITH device_counts AS (
    SELECT msisdn, COUNT(*) AS device_rows
    FROM device_clean
    GROUP BY msisdn
)
SELECT
    CASE
        WHEN d.msisdn IS NULL THEN 'NO_DEVICE'
        WHEN d.device_rows = 1 THEN 'ONE_DEVICE'
        ELSE 'MULTIPLE_DEVICES'
    END AS device_link,
    COUNT(*) AS transactions,
    COUNT(DISTINCT r.msisdn) AS customers,
    ROUND(SUM(r.revenue_usd), 2) AS revenue_usd
FROM rev_clean r
LEFT JOIN device_counts d ON r.msisdn = d.msisdn
GROUP BY 1
ORDER BY 1;
