"""Shared settings for the local analytics pipeline."""

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SQL_DIR = PROJECT_ROOT / "sql"
DATA_DIR = PROJECT_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
SYNTHETIC_DIR = DATA_DIR / "synthetic"
OUTPUT_DIR = PROJECT_ROOT / "outputs"

# Age is computed as ANALYSIS_YEAR minus year_of_birth.
# The source schema has a week number and no calendar year, so this is an
# explicit assumption used only to group customers into age bands.
ANALYSIS_YEAR = 2026

# Plausible birth years kept as integers. Values outside this range stay null
# and are counted in the data-quality table. They are not imputed.
MIN_BIRTH_YEAR = 1900
MAX_BIRTH_YEAR = 2015

RAW_FILES = {
    "crm": "crm1.csv",
    "revenue": "rev1.csv",
    "device": "device1.csv",
}

# Public Kaggle extract, measured from the dataset API on 19 October 2026.
# These sizes are file sizes, not a claim that this project loaded the files.
KAGGLE_DATASET = {
    "title": "Telecom IOT, Customer and Revenue Dataset",
    "owner": "Krishna Cheedella",
    "ref": "krishnacheedella/telecom-iot-crm-dataset",
    "url": "https://www.kaggle.com/datasets/krishnacheedella/telecom-iot-crm-dataset",
    "license": "CC0: Public Domain",
    "total_bytes": 1_224_154_020,
    "files": {
        "crm1.csv": 880_084_718,
        "device1.csv": 251_218_237,
        "rev1.csv": 92_851_065,
    },
}
