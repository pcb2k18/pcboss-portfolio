# Telecom Customer and Revenue Analytics

Independent analytics project for the GitHub portfolio of [pcb2k18](https://github.com/pcb2k18). It cleans three related tables and measures customer mix, weekly revenue, and device inventory with Python, Pandas, SQL, and DuckDB.

The questions follow the public problem framed by [Abdrihman-Hussein/Telecom-Iot-Insights](https://github.com/Abdrihman-Hussein/Telecom-Iot-Insights): a CRM extract, a weekly revenue extract, and a device extract, joined on a customer identifier. The code, charts, and findings in this folder were written for this project. That repository has no license file, and the GitHub API reported `license: null` on 19 October 2026, so none of its scripts, notebooks, dashboard, images, or DAX were copied.

## Dataset

The public source is Krishna Cheedella’s Kaggle dataset [Telecom IOT, Customer and Revenue Dataset](https://www.kaggle.com/datasets/krishnacheedella/telecom-iot-crm-dataset) (`krishnacheedella/telecom-iot-crm-dataset`).

Checked against the Kaggle dataset API on 19 October 2026:

| Item | Recorded value |
| --- | --- |
| License | CC0: Public Domain |
| Visibility | Public |
| Version | 6, updated 16 April 2026 |
| Total size | 1,224,154,020 bytes (about 1.22 GB) |
| `crm1.csv` | 880,084,718 bytes |
| `device1.csv` | 251,218,237 bytes |
| `rev1.csv` | 92,851,065 bytes |

CC0, as listed by Kaggle, places the dataset in the public domain and allows use without a required attribution clause. This README still cites it. Downloading through Kaggle also requires a Kaggle account and Kaggle’s site terms. The dataset card points at `https://telecom-case-study-ml-hive-sqoop.s3.amazonaws.com/` for the CSV files. Those three URLs returned HTTP 404 on 19 October 2026, so they are not a working direct download.

Columns, from the Kaggle description:

| File | Columns |
| --- | --- |
| CRM | `msisdn`, `gender`, `year_of_birth`, `system_status`, `mobile_type`, `value_segment` |
| Revenue | `msisdn`, `week_number`, `Revenue_usd` |
| Device | `msisdn`, `imei_tac`, `brand_name`, `model_name`, `os_name`, `os_vendor` |

`msisdn` is the customer key. The Kaggle text calls `imei_tac` a location identifier. A TAC is usually the type-allocation code of a handset, so this project keeps the column and does not treat it as a place.

The dataset card’s own preview shows mixed-case gender values, `ACTIVE` and `SUSPEND`, prepaid and postpaid, and a single displayed value for `value_segment` (`Tier_3`). Those are observations from the card, not counts produced by this repository.

The reference README reports about 17.8 million raw rows and about 15.4 million cleaned rows. This project did not load those files, so it does not confirm those counts.

## What this folder actually ran

The Kaggle extract was not downloaded. The C: drive had about 0.21 GB free, the extract is about 1.22 GB, and the Kaggle CLI was not installed.

The runnable results in `outputs/` come from a **synthetic sample** written by `src/synthetic_data.py` with seed `20261019`. Every identifier starts with `SYN`. Brand names are invented (`NORTHWIND`, `HARBOR`, `KESTREL`, `LUMEN`, `ORBIT`). A `SOURCE.txt` file is written next to the CSVs. Prepaid, gender, age, and brand mixes follow that generator. They are not estimates for the Kaggle population.

Measured on that sample:

| Measure | Value |
| --- | ---: |
| CRM rows in | 2,200 |
| CRM profiles after removing duplicate `msisdn` values | 2,000 |
| Revenue rows in | 4,000 |
| Revenue rows kept | 3,920 |
| Revenue rows rejected | 80 |
| Device rows in | 1,800 |
| Device rows kept | 1,776 |
| Paying customers | 1,797 |
| Total revenue | 36,720.32 USD |
| Revenue with no CRM profile | 4,512.39 USD |
| Revenue joined to CRM | 32,207.93 USD |

`4,512.39 + 32,207.93 = 36,720.32`. The matched and unmatched pieces add back to the total. The full tables, the week-by-week series, and the chart list are in [`outputs/findings.md`](outputs/findings.md), which the pipeline writes from the query results.

## Method

DuckDB reads the CSVs as text, so a birth year is not parsed as a timestamp. SQL then:

- maps gender to `MALE`, `FEMALE`, or `UNKNOWN` (blank, `Not Available`, and other text stay unknown)
- keeps birth years from 1900 through 2015 as integers and leaves other values null
- standardizes service status, prepaid/postpaid, and value segment
- keeps one CRM row per `msisdn`, preferring `ACTIVE`, then a known gender, then a known birth year
- rounds revenue to cents, drops rows with no id, no amount, or a week outside 1–53, and keeps negative amounts while counting them
- uppercases device fields and drops device rows with no `msisdn`

Pandas sorts the weekly aggregate and computes the change from the previous week. Age bands use `2026 - year_of_birth`. The source has a week number and no calendar year, so the band is a documented assumption. Revenue is attached to a device brand only when that customer has exactly one cleaned device row.

## Run it

```text
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m src.run_analysis --source synthetic
```

On 19 October 2026, `python -m unittest discover -s tests -v` reported 3 tests, OK, using Python 3.13.7, pandas 2.3.2, matplotlib 3.10.7, and duckdb 1.5.6.

To analyze the Kaggle files later, free several GB of disk, install the Kaggle CLI, place the API token outside Git, unzip the three CSVs into `data/raw/`, and run:

```text
python -m src.run_analysis --source raw
```

`--source auto` does the same when `data/raw/crm1.csv`, `data/raw/rev1.csv`, and `data/raw/device1.csv` are all present. Otherwise it builds the synthetic sample and says so.

## Layout

```text
sql/clean.sql            Cleaning queries
sql/analyze.sql          KPI and breakdown queries
src/synthetic_data.py    Labeled synthetic extract
src/pipeline.py          DuckDB load, SQL, Pandas week changes
src/plots.py             Charts
src/findings.py          Findings written from the result tables
src/run_analysis.py      Command line
tests/test_analysis.py   Fixture totals and synthetic labeling
outputs/findings.md      Latest written findings
outputs/figures/         Latest charts
outputs/tables/          Latest aggregate CSVs
data/raw/                Local Kaggle files, not for Git
data/synthetic/          Generated sample, not for Git
```

`data/raw/`, `data/synthetic/`, `*.duckdb`, `.env`, and `kaggle.json` are listed in `.gitignore`.

## License

Original code in this folder is under the MIT license in `LICENSE`. The Kaggle dataset, when you download it, remains under the CC0 dedication on its dataset page. The synthetic CSVs are fake data produced by this repository.
