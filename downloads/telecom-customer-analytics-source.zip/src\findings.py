"""Write findings from measured tables. Numbers are not typed in by hand."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.config import ANALYSIS_YEAR

SOURCE_BANNERS = {
    "synthetic": (
        "**Data source: synthetic sample.** These records were invented by "
        "`src/synthetic_data.py` so the pipeline can run without the Kaggle files. "
        "They are not a sample of that dataset. Prepaid, gender, age, and brand "
        "mixes follow that generator. Do not describe these totals as measurements "
        "of the public telecom extract, and do not describe this run as an analysis "
        "of 15 million records."
    ),
    "kaggle": (
        "**Data source: local copies of the Kaggle CSV files.** Totals below are "
        "`COUNT` and `SUM` results from this run. They are not copied from another "
        "project's README."
    ),
}


def _metric(kpis: pd.DataFrame, name: str) -> float:
    match = kpis.loc[kpis["metric"] == name, "value"]
    if match.empty or pd.isna(match.iloc[0]):
        return float("nan")
    return float(match.iloc[0])


def _quality(quality: pd.DataFrame, name: str) -> float:
    match = quality.loc[quality["check_name"] == name, "observed"]
    if match.empty or pd.isna(match.iloc[0]):
        return float("nan")
    return float(match.iloc[0])


def _money(value: float) -> str:
    if pd.isna(value):
        return "n/a"
    return f"{value:,.2f}"


def _count(value: float) -> str:
    if pd.isna(value):
        return "n/a"
    return f"{int(round(value)):,}"


def _frame_table(frame: pd.DataFrame) -> str:
    if frame.empty:
        return "_No rows._\n"
    display = frame.copy()
    for column in display.columns:
        if pd.api.types.is_float_dtype(display[column]):
            display[column] = display[column].map(lambda value: "" if pd.isna(value) else f"{value:,.2f}")
    header = "| " + " | ".join(display.columns) + " |"
    rule = "| " + " | ".join("---" for _ in display.columns) + " |"
    body = [
        "| " + " | ".join(str(value) for value in row) + " |"
        for row in display.itertuples(index=False, name=None)
    ]
    return "\n".join([header, rule, *body]) + "\n"


def write_findings(
    frames: dict[str, pd.DataFrame],
    path: Path,
    source_kind: str,
    figure_paths: list[Path],
) -> Path:
    kpis = frames["kpi_overview"]
    quality = frames["data_quality"]
    weekly = frames["weekly_revenue"].sort_values("week_number")
    lines = [
        "# Findings",
        "",
        SOURCE_BANNERS[source_kind],
        "",
        f"Age bands use {ANALYSIS_YEAR} minus `year_of_birth`. The source schema stores a week "
        "number and does not store a calendar year, so a band is a grouping "
        "assumption. Customers born before 1900 or after 2015 are left in "
        "`UNKNOWN_BIRTH_YEAR` rather than imputed.",
        "",
        "## Scale of this run",
        "",
        f"- CRM profiles after deduplication: {_count(_quality(quality, 'crm_rows_clean'))}",
        f"- CRM rows removed as duplicate msisdn values: {_count(_quality(quality, 'crm_duplicate_rows_removed'))}",
        f"- Revenue rows kept: {_count(_quality(quality, 'rev_rows_clean'))}",
        f"- Revenue rows rejected (missing id, missing amount, or week outside 1-53): {_count(_quality(quality, 'rev_rows_rejected'))}",
        f"- Negative revenue rows kept: {_count(_quality(quality, 'rev_negative_amounts'))}",
        f"- Device rows kept: {_count(_quality(quality, 'device_rows_clean'))}",
        f"- Distinct value segments in the cleaned CRM table: {_count(_quality(quality, 'crm_distinct_value_segments'))}",
        "",
        "## Revenue",
        "",
        f"- Total revenue: {_money(_metric(kpis, 'total_revenue_usd'))} USD",
        f"- Paying customers: {_count(_metric(kpis, 'paying_customers'))}",
        f"- Average transaction: {_money(_metric(kpis, 'avg_transaction_usd'))} USD",
        f"- Revenue per paying customer (total revenue divided by distinct paying msisdn): {_money(_metric(kpis, 'arpu_usd'))} USD",
        f"- Revenue joined to a CRM profile: {_money(_metric(kpis, 'matched_revenue_usd'))} USD",
        f"- Revenue with no CRM profile: {_money(_metric(kpis, 'orphan_revenue_usd'))} USD",
        f"- Paying customers joined to CRM: {_count(_metric(kpis, 'matched_paying_customers'))}",
        "",
        "### Revenue by week",
        "",
        _frame_table(weekly),
        "",
    ]

    if len(weekly) >= 2 and weekly["revenue_usd"].notna().all():
        first = weekly.iloc[0]
        last = weekly.iloc[-1]
        change = float(last["revenue_usd"]) - float(first["revenue_usd"])
        base = float(first["revenue_usd"])
        pct = (change / base * 100) if base else float("nan")
        lines.extend(
            [
                (
                    f"From week {int(first['week_number'])} to week {int(last['week_number'])}, "
                    f"revenue changed by {_money(change)} USD"
                    + (f" ({pct:.1f}%)." if pd.notna(pct) else ".")
                ),
                "That comparison is the first and last week present in this extract, not a fitted trend.",
                "",
            ]
        )

    lines.extend(
        [
            "### Revenue by mobile type",
            "",
            "Unmatched revenue is kept in its own row. It is not assigned to prepaid or postpaid.",
            "",
            _frame_table(frames["revenue_by_mobile_type"]),
            "",
            "### Revenue by gender",
            "",
            "`UNKNOWN` means the CRM gender was blank or not male/female. `UNMATCHED` means the payment had no CRM row.",
            "",
            _frame_table(frames["revenue_by_gender"]),
            "",
            "### Revenue by age band",
            "",
            _frame_table(frames["revenue_by_age_band"]),
            "",
            "## Customers",
            "",
            "### CRM age bands",
            "",
            _frame_table(frames["crm_age_bands"]),
            "",
            "### Service status",
            "",
            _frame_table(frames["system_status_counts"]),
            "",
            "### Value segment",
            "",
            _frame_table(frames["value_segment_counts"]),
            "",
            "### Weeks with a payment, per customer",
            "",
            _frame_table(frames["weeks_per_customer"]),
            "",
            "## Devices",
            "",
            "Brand and operating-system tables count device rows. A customer can hold more than one device.",
            "",
            _frame_table(frames["device_brands"]),
            "",
            _frame_table(frames["device_os"]),
            "",
            "Revenue is summed by brand only for customers with exactly one cleaned device row.",
            "",
            _frame_table(frames["single_device_brand_revenue"]),
            "",
            _frame_table(frames["device_revenue_coverage"]),
            "",
            "## Figures",
            "",
        ]
    )
    if figure_paths:
        for figure in figure_paths:
            lines.append(f"- `{figure.name}`")
    else:
        lines.append("- No figures were written because the aggregate tables were empty.")
    lines.append("")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    return path
