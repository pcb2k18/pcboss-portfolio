-- Row-level cleaning for CRM, revenue, and device extracts.
-- Input views crm_input, rev_input, and device_input are created by Python
-- with canonical column names. Every value arrives as text.

CREATE OR REPLACE TABLE crm_standardized AS
SELECT
    NULLIF(upper(trim(msisdn)), '') AS msisdn,
    CASE
        WHEN upper(trim(coalesce(gender, ''))) IN ('M', 'MALE') THEN 'MALE'
        WHEN upper(trim(coalesce(gender, ''))) IN ('F', 'FEMALE') THEN 'FEMALE'
        ELSE 'UNKNOWN'
    END AS gender,
    CASE
        WHEN regexp_full_match(trim(coalesce(year_of_birth, '')), '^[0-9]{4}$')
         AND TRY_CAST(trim(year_of_birth) AS INTEGER) BETWEEN 1900 AND 2015
        THEN TRY_CAST(trim(year_of_birth) AS INTEGER)
        ELSE NULL
    END AS year_of_birth,
    CASE
        WHEN trim(coalesce(system_status, '')) = '' THEN 'UNKNOWN'
        ELSE upper(trim(system_status))
    END AS system_status,
    CASE
        WHEN upper(trim(coalesce(mobile_type, ''))) IN ('PREPAID', 'PRE-PAID', 'PRE PAID') THEN 'PREPAID'
        WHEN upper(trim(coalesce(mobile_type, ''))) IN ('POSTPAID', 'POST-PAID', 'POST PAID') THEN 'POSTPAID'
        ELSE 'UNKNOWN'
    END AS mobile_type,
    CASE
        WHEN trim(coalesce(value_segment, '')) = '' THEN 'UNKNOWN'
        ELSE upper(trim(value_segment))
    END AS value_segment
FROM crm_input;

-- One CRM profile per msisdn.
-- Preference: ACTIVE status, then a known gender, then a known birth year.
CREATE OR REPLACE TABLE crm_clean AS
SELECT
    msisdn,
    gender,
    year_of_birth,
    system_status,
    mobile_type,
    value_segment
FROM (
    SELECT
        *,
        row_number() OVER (
            PARTITION BY msisdn
            ORDER BY
                CASE WHEN system_status = 'ACTIVE' THEN 0 ELSE 1 END,
                CASE WHEN gender = 'UNKNOWN' THEN 1 ELSE 0 END,
                year_of_birth DESC NULLS LAST,
                mobile_type,
                value_segment
        ) AS rn
    FROM crm_standardized
    WHERE msisdn IS NOT NULL
) ranked
WHERE rn = 1;

CREATE OR REPLACE TABLE rev_standardized AS
SELECT
    NULLIF(upper(trim(msisdn)), '') AS msisdn,
    TRY_CAST(trim(week_number) AS INTEGER) AS week_number,
    ROUND(TRY_CAST(trim(revenue_usd) AS DOUBLE), 2) AS revenue_usd
FROM rev_input;

-- Week numbers outside 1-53 and rows without an amount are retained only
-- in the quality counts below. Negative amounts are kept; they may be
-- adjustments, and the quality table reports how many there are.
CREATE OR REPLACE TABLE rev_clean AS
SELECT
    msisdn,
    week_number,
    revenue_usd,
    revenue_usd < 0 AS is_negative
FROM rev_standardized
WHERE msisdn IS NOT NULL
  AND revenue_usd IS NOT NULL
  AND week_number BETWEEN 1 AND 53;

CREATE OR REPLACE TABLE device_clean AS
SELECT DISTINCT
    msisdn,
    imei_tac,
    brand_name,
    model_name,
    os_name,
    os_vendor
FROM (
    SELECT
        NULLIF(upper(trim(msisdn)), '') AS msisdn,
        NULLIF(upper(trim(coalesce(imei_tac, ''))), '') AS imei_tac,
        CASE
            WHEN trim(coalesce(brand_name, '')) = '' THEN 'UNKNOWN'
            ELSE upper(trim(brand_name))
        END AS brand_name,
        CASE
            WHEN trim(coalesce(model_name, '')) = '' THEN 'UNKNOWN'
            ELSE upper(trim(model_name))
        END AS model_name,
        CASE
            WHEN trim(coalesce(os_name, '')) = '' THEN 'UNKNOWN'
            ELSE upper(trim(os_name))
        END AS os_name,
        CASE
            WHEN trim(coalesce(os_vendor, '')) = '' THEN 'UNKNOWN'
            ELSE upper(trim(os_vendor))
        END AS os_vendor
    FROM device_input
) staged
WHERE msisdn IS NOT NULL;

CREATE OR REPLACE TABLE data_quality AS
SELECT 'crm_input_rows' AS check_name, COUNT(*)::DOUBLE AS observed
FROM crm_input
UNION ALL
SELECT 'crm_rows_missing_msisdn', COUNT(*)::DOUBLE
FROM crm_standardized
WHERE msisdn IS NULL
UNION ALL
SELECT 'crm_rows_before_dedup', COUNT(*)::DOUBLE
FROM crm_standardized
WHERE msisdn IS NOT NULL
UNION ALL
SELECT 'crm_rows_clean', COUNT(*)::DOUBLE
FROM crm_clean
UNION ALL
SELECT 'crm_duplicate_rows_removed',
    (SELECT COUNT(*) FROM crm_standardized WHERE msisdn IS NOT NULL)::DOUBLE
    - (SELECT COUNT(*) FROM crm_clean)::DOUBLE
UNION ALL
SELECT 'crm_unknown_gender', COUNT(*)::DOUBLE
FROM crm_clean
WHERE gender = 'UNKNOWN'
UNION ALL
SELECT 'crm_invalid_or_missing_birth_year', COUNT(*)::DOUBLE
FROM crm_clean
WHERE year_of_birth IS NULL
UNION ALL
SELECT 'crm_distinct_value_segments', COUNT(DISTINCT value_segment)::DOUBLE
FROM crm_clean
UNION ALL
SELECT 'rev_input_rows', COUNT(*)::DOUBLE
FROM rev_input
UNION ALL
SELECT 'rev_rows_rejected',
    (SELECT COUNT(*) FROM rev_input)::DOUBLE
    - (SELECT COUNT(*) FROM rev_clean)::DOUBLE
UNION ALL
SELECT 'rev_rows_clean', COUNT(*)::DOUBLE
FROM rev_clean
UNION ALL
SELECT 'rev_negative_amounts', COUNT(*)::DOUBLE
FROM rev_clean
WHERE is_negative
UNION ALL
SELECT 'device_input_rows', COUNT(*)::DOUBLE
FROM device_input
UNION ALL
SELECT 'device_rows_clean', COUNT(*)::DOUBLE
FROM device_clean
UNION ALL
SELECT 'device_rows_missing_msisdn', COUNT(*)::DOUBLE
FROM device_input
WHERE NULLIF(upper(trim(coalesce(msisdn, ''))), '') IS NULL;
