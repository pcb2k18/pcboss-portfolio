﻿# Reproduction

This archive is the implementation only. It does not include the Kaggle CSV files, the DuckDB database, or customer-level records.

The case study published at https://pcboss.me/projects/telecom-customer-analytics/ was computed from a local copy of the public Kaggle extract. Running the synthetic path will not reproduce those totals.

## Requirements

Python 3.11 or newer, then:

```text
python -m pip install -r requirements.txt
```

Packages: pandas>=2.2, duckdb>=1.1, matplotlib>=3.8.

## Tests

```text
python -m unittest discover -s tests -v
```

The tests use small hand-written fixtures and a synthetic labeling check. They do not need the Kaggle files.

## Synthetic sample

```text
python -m src.run_analysis --source synthetic
```

This writes a labeled sample whose identifiers start with SYN. It is not the published extract and it will not reproduce the published revenue total.

## Published extract

Download crm1.csv, rev1.csv, and device1.csv yourself from the public Kaggle dataset krishnacheedella/telecom-iot-crm-dataset. Place them in data/raw/ and run:

```text
python -m src.run_analysis --source raw
```

`--source auto` uses those three files when all of them are present. Otherwise it builds the synthetic sample and says so.

Age bands use 2026 minus year of birth. The source file has a week number and no calendar year, so that reference year is an assumption.
