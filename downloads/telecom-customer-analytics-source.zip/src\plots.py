"""Save charts from the aggregate tables. Titles name the data source."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from src.config import ANALYSIS_YEAR

SOURCE_LABELS = {
    "synthetic": "Synthetic sample, not the Kaggle extract",
    "kaggle": "Local Kaggle CSV extract",
}


def _finish(fig: plt.Figure, path: Path, source_kind: str) -> None:
    fig.text(
        0.99,
        0.01,
        SOURCE_LABELS[source_kind],
        ha="right",
        va="bottom",
        fontsize=8,
        color="#555555",
    )
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def _barh(
    frame: pd.DataFrame,
    label_col: str,
    value_col: str,
    title: str,
    xlabel: str,
    path: Path,
    source_kind: str,
    keep_order: bool = False,
) -> None:
    # barh draws the first row at the bottom, so a kept order is reversed
    # and the first category appears at the top of the chart.
    ordered = frame.iloc[::-1] if keep_order else frame.sort_values(value_col, ascending=True)
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.barh(ordered[label_col].astype(str), ordered[value_col], color="#1f4e79")
    ax.set_title(f"{title}\n({SOURCE_LABELS[source_kind]})")
    ax.set_xlabel(xlabel)
    _finish(fig, path, source_kind)


def write_figures(frames: dict[str, pd.DataFrame], figure_dir: Path, source_kind: str) -> list[Path]:
    figure_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    label = SOURCE_LABELS[source_kind]

    weekly = frames["weekly_revenue"]
    if not weekly.empty:
        path = figure_dir / "weekly_revenue.png"
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(weekly["week_number"], weekly["revenue_usd"], marker="o", color="#1f4e79")
        ax.set_title(f"Revenue by week number\n({label})")
        ax.set_xlabel("Week number")
        ax.set_ylabel("Revenue (USD)")
        ax.set_ylim(bottom=0)
        ax.set_xticks(list(weekly["week_number"]))
        _finish(fig, path, source_kind)
        written.append(path)

    mobile = frames["revenue_by_mobile_type"]
    if not mobile.empty:
        path = figure_dir / "revenue_by_mobile_type.png"
        _barh(mobile, "mobile_type", "revenue_usd", "Revenue by mobile type", "Revenue (USD)", path, source_kind)
        written.append(path)

    ages = frames["revenue_by_age_band"]
    if not ages.empty:
        path = figure_dir / "revenue_by_age_band.png"
        _barh(
            ages,
            "age_band",
            "revenue_usd",
            f"Revenue by age band, using {ANALYSIS_YEAR} minus birth year",
            "Revenue (USD)",
            path,
            source_kind,
            keep_order=True,
        )
        written.append(path)

    brands = frames["device_brands"].head(10)
    if not brands.empty:
        path = figure_dir / "device_brands.png"
        _barh(brands, "brand_name", "device_rows", "Device rows by brand", "Device rows", path, source_kind)
        written.append(path)

    systems = frames["device_os"]
    if not systems.empty:
        path = figure_dir / "device_os.png"
        fig, ax = plt.subplots(figsize=(6.5, 4.5))
        palette = ["#1f4e79", "#4c78a8", "#9ecae1", "#6b7280", "#d1d5db"]
        ax.pie(
            systems["device_rows"],
            labels=systems["os_name"].astype(str),
            autopct="%1.1f%%",
            startangle=90,
            colors=[palette[i % len(palette)] for i in range(len(systems))],
        )
        ax.set_title(f"Device rows by operating system\n({label})")
        _finish(fig, path, source_kind)
        written.append(path)

    coverage = frames["device_revenue_coverage"]
    if not coverage.empty:
        path = figure_dir / "revenue_by_device_link.png"
        _barh(
            coverage,
            "device_link",
            "revenue_usd",
            "Revenue by device-link status",
            "Revenue (USD)",
            path,
            source_kind,
        )
        written.append(path)

    return written
