"""Checks for cleaning rules, SQL totals, and synthetic labeling."""

from __future__ import annotations

import csv
import tempfile
import unittest
from pathlib import Path

from src.pipeline import run_pipeline
from src.synthetic_data import generate_synthetic_extract


def _write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


class FixtureAnalysisTest(unittest.TestCase):
    def test_cleaning_rules_and_hand_calculated_totals(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            raw = root / "raw"
            out = root / "out"
            raw.mkdir()
            _write_csv(
                raw / "crm.csv",
                ["msisdn", "gender", "year_of_birth", "system_status", "mobile_type", "value_segment"],
                [
                    {"msisdn": "A", "gender": "Male", "year_of_birth": "1985", "system_status": "ACTIVE", "mobile_type": "Prepaid", "value_segment": "Tier_3"},
                    {"msisdn": "A", "gender": "Female", "year_of_birth": "1985", "system_status": "SUSPEND", "mobile_type": "Postpaid", "value_segment": "Tier_3"},
                    {"msisdn": "B", "gender": "Not Available", "year_of_birth": "2046", "system_status": "ACTIVE", "mobile_type": "Postpaid", "value_segment": "Tier_3"},
                    {"msisdn": "C", "gender": "FEMALE", "year_of_birth": "1990", "system_status": "ACTIVE", "mobile_type": "Prepaid", "value_segment": ""},
                    {"msisdn": "", "gender": "MALE", "year_of_birth": "1970", "system_status": "ACTIVE", "mobile_type": "Prepaid", "value_segment": "Tier_3"},
                ],
            )
            _write_csv(
                raw / "rev.csv",
                ["msisdn", "week_number", "Revenue_usd"],
                [
                    {"msisdn": "A", "week_number": "1", "Revenue_usd": "10.126"},
                    {"msisdn": "A", "week_number": "2", "Revenue_usd": "5"},
                    {"msisdn": "B", "week_number": "1", "Revenue_usd": "20"},
                    {"msisdn": "D", "week_number": "1", "Revenue_usd": "7"},
                    {"msisdn": "C", "week_number": "2", "Revenue_usd": "-1.504"},
                    {"msisdn": "C", "week_number": "3", "Revenue_usd": ""},
                    {"msisdn": "A", "week_number": "99", "Revenue_usd": "100"},
                ],
            )
            _write_csv(
                raw / "device.csv",
                ["msisdn", "imei_tac", "brand_name", "model_name", "os_name", "os_vendor"],
                [
                    {"msisdn": "A", "imei_tac": "100", "brand_name": "samsung", "model_name": "m1", "os_name": "android", "os_vendor": "google"},
                    {"msisdn": "B", "imei_tac": "200", "brand_name": "nokia", "model_name": "m2", "os_name": "android", "os_vendor": "google"},
                    {"msisdn": "B", "imei_tac": "300", "brand_name": "nokia", "model_name": "m3", "os_name": "android", "os_vendor": "google"},
                    {"msisdn": "C", "imei_tac": "400", "brand_name": "", "model_name": "", "os_name": "ios", "os_vendor": "apple"},
                ],
            )
            manifest = run_pipeline(
                raw / "crm.csv",
                raw / "rev.csv",
                raw / "device.csv",
                out,
                source_kind="kaggle",
                source_detail={"note": "hand-built fixture, not the Kaggle download"},
            )
            kpis = manifest["kpis"]
            quality = manifest["quality"]
            self.assertEqual(quality["crm_rows_clean"], 3)
            self.assertEqual(quality["crm_duplicate_rows_removed"], 1)
            self.assertEqual(quality["rev_rows_clean"], 5)
            self.assertEqual(quality["rev_rows_rejected"], 2)
            self.assertAlmostEqual(kpis["total_revenue_usd"], 40.63, places=2)
            self.assertEqual(kpis["orphan_revenue_usd"], 7.0)
            self.assertAlmostEqual(kpis["matched_revenue_usd"], 33.63, places=2)
            self.assertEqual(kpis["paying_customers"], 4)

            import pandas as pd

            # Birth year 1985 is kept as 1985 (age 41 in 2026, band 35_44).
            # Treating the integer year as a timestamp would collapse it toward 1970.
            crm_ages = pd.read_csv(out / "tables" / "crm_age_bands.csv")
            self.assertEqual(int(crm_ages.loc[crm_ages["age_band"] == "35_44", "customers"].iloc[0]), 2)
            self.assertFalse((crm_ages["age_band"] == "55_64").any())
            ages = pd.read_csv(out / "tables" / "revenue_by_age_band.csv")
            band_35 = ages.loc[ages["age_band"] == "35_44", "revenue_usd"].iloc[0]
            self.assertAlmostEqual(float(band_35), 13.63, places=2)
            self.assertTrue((out / "figures" / "weekly_revenue.png").stat().st_size > 0)

            brands = pd.read_csv(out / "tables" / "single_device_brand_revenue.csv")
            samsung = brands.loc[brands["brand_name"] == "SAMSUNG", "revenue_usd"].iloc[0]
            self.assertAlmostEqual(float(samsung), 15.13, places=2)
            self.assertNotIn("NOKIA", set(brands["brand_name"]))

    def test_missing_column_is_reported(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            crm = root / "crm.csv"
            rev = root / "rev.csv"
            device = root / "device.csv"
            _write_csv(crm, ["msisdn"], [{"msisdn": "A"}])
            _write_csv(rev, ["msisdn", "week_number", "Revenue_usd"], [{"msisdn": "A", "week_number": "1", "Revenue_usd": "1"}])
            _write_csv(
                device,
                ["msisdn", "imei_tac", "brand_name", "model_name", "os_name", "os_vendor"],
                [{"msisdn": "A", "imei_tac": "1", "brand_name": "X", "model_name": "Y", "os_name": "Z", "os_vendor": "V"}],
            )
            with self.assertRaises(ValueError):
                run_pipeline(crm, rev, device, root / "out", source_kind="kaggle")


class SyntheticLabelTest(unittest.TestCase):
    def test_generated_run_is_labeled_and_does_not_reuse_reference_totals(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            detail = generate_synthetic_extract(
                root / "synthetic",
                seed=7,
                customer_count=30,
                extra_duplicate_rows=5,
                revenue_rows=40,
                device_rows=20,
                week_count=4,
            )
            self.assertEqual(detail["notice"], "synthetic")
            notice = (root / "synthetic" / "SOURCE.txt").read_text(encoding="utf-8")
            self.assertIn("not the Kaggle dataset", notice)
            sample = (root / "synthetic" / "crm1.csv").read_text(encoding="utf-8")
            self.assertIn("SYN", sample)
            manifest = run_pipeline(
                root / "synthetic" / "crm1.csv",
                root / "synthetic" / "rev1.csv",
                root / "synthetic" / "device1.csv",
                root / "out",
                source_kind="synthetic",
                source_detail=detail,
            )
            self.assertFalse(manifest["kaggle_extract_was_loaded"])
            text = Path(manifest["findings"]).read_text(encoding="utf-8")
            self.assertIn("synthetic sample", text.lower())
            for banned in ("17,772,194", "15,394,052", "11,249,351", "19.30M"):
                self.assertNotIn(banned, text)


if __name__ == "__main__":
    unittest.main()
