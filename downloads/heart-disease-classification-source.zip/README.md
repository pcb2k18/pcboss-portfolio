# Heart Disease Classification and Model Evaluation

An independent, reproducible machine-learning portfolio project comparing four
classifiers on the public UCI Cleveland heart-disease dataset.
Built for [pcboss.me](https://pcboss.me).

> **Not a medical device.** This is an educational analysis of a small, historical
> public dataset. The models are **not clinically validated** and must not be used
> for diagnosis, screening, or any clinical decision.

## Reference & independence

This project was inspired by the general task in
[dannydave/Heart-Disease-Diagnosis-using-Machine-Learning-and-Data-Mining](https://github.com/dannydave/Heart-Disease-Diagnosis-using-Machine-Learning-and-Data-Mining).
That repository carries **no licence** (`license: null` via the GitHub API, inspected
2026-10-20), so **no code was copied from it**. All code here is an original,
independent implementation; only the broad idea — classifying heart-disease
presence with classical ML — is shared.

## Dataset

| Item | Detail |
|---|---|
| Dataset | UCI Machine Learning Repository, *Heart Disease* (ID 45) — processed Cleveland database |
| Records | **303** patients, 13 features (before deduplication; 0 exact duplicates found) |
| Target | `num` binarised: 0 = no disease (164), 1 = disease, `num` 1–4 (139; 45.9% prevalence) |
| Missing values | 6 cells, marked `?` in the raw file (`ca`: 4, `thal`: 2), handled by imputation inside the pipeline |
| Age / sex | Age 29–77 years; sex coded 0/1 (97 / 206 in the file's coding) |
| Source | https://archive.ics.uci.edu/dataset/45/heart+disease |
| DOI | [10.24432/C52P4X](https://doi.org/10.24432/C52P4X) |
| Licence | **CC BY 4.0** under UCI Machine Learning Repository terms (attribution required) |
| Citation | Janosi, A., Steinbrunn, W., Pfisterer, M., & Detrano, R. (1989). *Heart Disease* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C52P4X |

The raw file is downloaded on first run and kept in `data/raw/` (git-ignored,
excluded from the ZIP). UCI states patient names/SSNs were removed and replaced
with dummy values. Public outputs contain only aggregate statistics and figures —
no patient-level records. See `data/README.md`.

**Features:** `age, sex, cp` (chest-pain type), `trestbps` (resting BP),
`chol` (cholesterol), `fbs` (fasting blood sugar >120 mg/dl), `restecg`,
`thalach` (max heart rate), `exang` (exercise-induced angina), `oldpeak`
(ST depression), `slope`, `ca` (major vessels coloured by fluoroscopy),
`thal` (thalassemia scan result).

## Method (leakage-safe)

1. **EDA & cleaning** — parse `?` as missing, check types, duplicates, target balance.
2. **Deduplication before splitting** — exact `(features + target)` duplicates dropped
   (0 found); train/test overlap is then asserted to be zero at runtime.
3. **Stratified split** — 80/20 (242 train / 61 test), `random_state=42`.
4. **Preprocessing inside a single `Pipeline`** — numeric: median imputation +
   standard scaling; categorical: most-frequent imputation + one-hot encoding.
   Every statistic is fit **only** on training data (or on each CV training fold).
5. **Models (fixed, pre-declared settings — no tuning on the test set):**
   Random Forest (300 trees), Decision Tree, Gaussian Naive Bayes,
   SVM (RBF, `C=1.0`, probability estimates enabled).
6. **Model comparison** — stratified 5-fold cross-validation on the **training
   data only**, then a **single** final evaluation on the held-out test set:
   accuracy, precision, recall, F1, ROC-AUC, confusion matrices, ROC curves.
7. **Feature importance** — Random Forest impurity importance (training data).

## Actual results (measured 2026-10-20, Python 3.13.7)

Held-out test set (61 patients: 33 negative, 28 positive):

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | TN | FP | FN | TP |
|---|---|---|---|---|---|---|---|---|---|
| **SVM** | **0.902** | **0.867** | 0.929 | **0.897** | **0.961** | 29 | 4 | 2 | 26 |
| Random Forest | 0.885 | 0.839 | 0.929 | 0.881 | 0.939 | 28 | 5 | 2 | 26 |
| Decision Tree | 0.754 | 0.686 | 0.857 | 0.762 | 0.762 | 22 | 11 | 4 | 24 |
| Naive Bayes | 0.672 | 0.595 | 0.893 | 0.714 | 0.848 | 16 | 17 | 3 | 25 |

Training-only 5-fold CV (mean accuracy / ROC-AUC): SVM 0.831 / 0.885,
Random Forest 0.810 / 0.890, Naive Bayes 0.723 / 0.871, Decision Tree 0.702 / 0.700.
The test set is small (≈60 patients), so treat test metrics as indicative, not precise.

Top Random Forest features: `thalach` (max heart rate, 0.100), `thal=3` (normal, 0.092),
`ca` (vessels, 0.092), `cp=4` (asymptomatic chest pain, 0.086), `oldpeak` (0.082),
`thal=7` (reversible defect, 0.079), `age` (0.076). Importance is impurity-based and
associational — it is not causal or clinical evidence.

Full machine-readable results: [`outputs/results.json`](outputs/results.json) ·
Case study for the portfolio site: [`outputs/portfolio-case-study.md`](outputs/portfolio-case-study.md)

## Figures (`outputs/figures/`)

1. `01_target_distribution.png` — class balance
2. `02_age_by_target.png` — age by disease status
3. `03_correlation_heatmap.png` — numeric-feature correlations
4. `04_feature_importance.png` — Random Forest importance
5. `05_model_comparison.png` — test metrics by model
6. `06_confusion_matrices.png` — all four confusion matrices
7. `07_roc_curves.png` — ROC curves with AUC

## Reproduce

```bash
pip install -r requirements.txt
python src/run_analysis.py   # downloads the UCI file if needed, writes outputs/
python -m pytest tests/ -q
```

Pinned environment (measured): Python 3.13.7, pandas 2.3.2, NumPy 2.3.3,
scikit-learn 1.7.2, Matplotlib 3.10.7, Seaborn 0.13.2 (`requirements.txt`).

## Project structure

```
src/heart_disease/   data.py · models.py · evaluate.py · plots.py
src/run_analysis.py  end-to-end runner
tests/               pytest suite (data, preprocessing-leakage, models/metrics)
data/README.md       dataset provenance; raw file is downloaded, not committed
outputs/             results.json · portfolio-case-study.md · figures/*.png
dist/                downloadable source-code ZIP (no raw data)
```

## Limitations — read before citing any number

- **Historical, single-centre cohort:** Cleveland patients from the 1980s (n = 303);
  not representative of modern, diverse, or non-referral populations.
- **Tiny held-out test set** (≈61 patients): metrics have wide confidence intervals.
- **Binarisation discards severity:** original `num` grades 1–4 are collapsed to “disease”.
- **1980s labels & measurements:** angiographic definitions and devices have changed.
- **No external validation, calibration, fairness/subgroup, or prospective analysis.**
- **Missing-data mechanism unknown** for `ca`/`thal`; values are imputed, not observed.
- **Impurity importance is biased** toward high-cardinality features and is not causal.
- These models are **educational demonstrations, not diagnostic tools**.

## Licence

Code: MIT (see `LICENSE`). Dataset: CC BY 4.0, © its creators, via UCI (above).
If you reuse the figures/results, credit both this project and the UCI dataset.
