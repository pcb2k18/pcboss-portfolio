import numpy as np
import pandas as pd

from heart_disease.data import FEATURES, parse_cleveland
from heart_disease.evaluate import evaluate_predictions
from heart_disease.models import build_models, build_preprocessor

ROWS = "\n".join([
    "63,1,1,145,233,1,2,150,0,2.3,3,0,6,0",
    "67,1,4,160,286,0,2,108,1,1.5,2,3,3,2",
    "37,1,3,130,250,0,0,187,0,3.5,3,0,3,0",
    "41,0,2,130,204,0,2,172,0,1.4,1,0,3,0",
    "56,1,2,120,236,0,0,178,0,0.8,1,0,7,1",
    "57,0,4,140,192,0,0,148,0,0.4,2,0,6,0",
    "57,1,4,130,131,0,0,115,1,1.2,2,1,7,3",
    "44,1,2,120,263,0,0,173,0,0.0,1,0,7,0",
    "52,1,3,172,199,1,0,162,0,0.5,1,0,7,0",
    "57,1,3,150,168,0,0,174,0,1.6,1,0,3,1",
    "54,1,4,140,239,0,0,160,0,1.2,1,0,3,0",
    "48,0,3,130,275,0,0,139,0,0.2,1,0,3,0",
])


def _xy():
    df = parse_cleveland(ROWS)
    return df[FEATURES], df["target"]


def test_all_models_fit_predict_and_score():
    X, y = _xy()
    for name, pipe in build_models().items():
        pipe.fit(X, y)
        pred = pipe.predict(X)
        proba = pipe.predict_proba(X)[:, 1]
        assert set(pred) <= {0, 1}, name
        m = evaluate_predictions(y, pred, proba)
        for k in ["accuracy", "precision", "recall", "f1", "roc_auc"]:
            assert 0.0 <= m[k] <= 1.0, (name, k)
        assert sum(sum(r) for r in m["confusion_matrix"]) == len(y)


def test_preprocessor_fit_on_train_only_no_leakage():
    """Scaler statistics must come from the data given to fit(), nothing else."""
    X, y = _xy()
    train, test = X.iloc[:8].copy(), X.iloc[8:].copy()
    train.loc[train.index[0], "age"] = np.nan  # force imputation path
    pre = build_preprocessor()
    Xt = pre.fit_transform(train)
    assert Xt.shape[0] == len(train)
    scaler = pre.named_transformers_["num"].named_steps["scaler"]
    expected_mean = train[["age", "trestbps", "chol", "thalach", "oldpeak", "ca"]] \
        .median().pipe(lambda med: train[["age", "trestbps", "chol", "thalach", "oldpeak", "ca"]].fillna(med).mean())
    np.testing.assert_allclose(scaler.mean_, expected_mean.to_numpy(), rtol=1e-6)
    # Transforming test data afterwards must not change fitted statistics
    before = scaler.mean_.copy()
    pre.transform(test)
    np.testing.assert_array_equal(scaler.mean_, before)


def test_metrics_known_values():
    m = evaluate_predictions([0, 0, 1, 1], [0, 1, 1, 1], [0.1, 0.6, 0.7, 0.9])
    assert m["accuracy"] == 0.75 and m["tp"] == 2 and m["fp"] == 1 and m["fn"] == 0
    assert m["roc_auc"] == 1.0
