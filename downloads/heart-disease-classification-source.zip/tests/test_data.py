import numpy as np
import pandas as pd
import pytest

from heart_disease.data import (
    COLUMNS, FEATURES, assert_no_split_overlap, binarise_target, deduplicate, parse_cleveland,
)

SAMPLE = """63,1,1,145,233,1,2,150,0,2.3,3,0,6,0
67,1,4,160,286,0,2,108,1,1.5,2,3,3,2
37,1,3,130,250,0,0,187,0,3.5,3,0,3,0
41,0,2,130,204,0,2,172,0,1.4,1,0,3,0
56,1,2,120,236,0,0,178,0,0.8,1,?,7,1"""


def test_parse_cleveland_shape_and_missing():
    df = parse_cleveland(SAMPLE)
    assert df.shape == (5, len(FEATURES) + 1)
    assert df["ca"].isna().sum() == 1  # the '?' row
    assert list(df.columns) == FEATURES + ["target"]


def test_binarise_target():
    raw = pd.DataFrame({"num": [0, 1, 2, 3, 4], "age": [1] * 5})
    out = binarise_target(raw)
    assert out["target"].tolist() == [0, 1, 1, 1, 1]
    assert "num" not in out.columns


def test_binarise_requires_num():
    with pytest.raises(ValueError):
        binarise_target(pd.DataFrame({"x": [1]}))


def test_deduplicate_drops_exact_dupes_only():
    df = parse_cleveland(SAMPLE)
    dup = pd.concat([df, df.iloc[[0]]], ignore_index=True)
    out, n = deduplicate(dup)
    assert n == 1 and len(out) == len(df)


def test_no_split_overlap_passes_and_fails():
    df = parse_cleveland(SAMPLE)
    assert_no_split_overlap(df.iloc[:3], df.iloc[3:])
    with pytest.raises(AssertionError):
        assert_no_split_overlap(df.iloc[:3], df.iloc[2:])

def test_columns_contract():
    assert len(COLUMNS) == 14 and FEATURES[0] == "age" and "thal" in FEATURES
