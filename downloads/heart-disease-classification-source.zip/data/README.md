# Data

The raw data is **not stored in this repository or in the downloadable ZIP**.
It is downloaded on first run from the UCI Machine Learning Repository.

| Item | Detail |
|---|---|
| Dataset | Heart Disease (UCI ID 45), processed Cleveland database |
| File used | `processed.cleveland.data` (inside the UCI zip) |
| Source | https://archive.ics.uci.edu/dataset/45/heart+disease |
| Direct download | https://archive.ics.uci.edu/static/public/45/heart+disease.zip |
| DOI | 10.24432/C52P4X |
| Licence | CC BY 4.0 — UCI Machine Learning Repository terms (attribution required) |
| Citation | Janosi, A., Steinbrunn, W., Pfisterer, M., & Detrano, R. (1989). *Heart Disease* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C52P4X |

`src/run_analysis.py` downloads the file to `data/raw/` (git-ignored).
UCI states that patient names and social-security numbers were removed from
this database and replaced with dummy values. Do not attempt to re-identify
any individual. Public outputs in `outputs/` contain only aggregate
statistics and figures — no patient-level records.
