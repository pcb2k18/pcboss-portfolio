---
title: "Heart Disease Classification and Model Evaluation"
site: "https://pcboss.me"
status: "Ready for publication (not yet published)"
date_measured: "2026-10-20"
download: "dist/heart-disease-classification-source.zip"
---

# Heart Disease Classification and Model Evaluation

## Summary

A reproducible comparison of four classical machine-learning classifiers —
Random Forest, Decision Tree, Naive Bayes and Support Vector Machine (SVM) —
on the public UCI Cleveland heart-disease dataset (303 patients, 13 clinical
features). The emphasis is methodological: leakage-safe preprocessing,
training-only cross-validation, and a single held-out test evaluation.

> ⚠️ Educational portfolio project. **Not a clinically validated diagnostic
> tool** and not suitable for any medical decision.

## Why this project

- Demonstrates an end-to-end, test-covered ML workflow on real clinical-style data.
- Shows honest model comparison: cross-validation for ranking, held-out test
  set touched once, no tuning on test data.
- Makes limitations explicit instead of overselling accuracy on a tiny dataset.

## Data

- **Source:** UCI Machine Learning Repository, *Heart Disease* (ID 45),
  processed Cleveland file — https://archive.ics.uci.edu/dataset/45/heart+disease
- **Licence:** CC BY 4.0 (UCI terms). DOI: 10.24432/C52P4X. Citation: Janosi,
  Steinbrunn, Pfisterer & Detrano (1989).
- **Size:** 303 records · 164 without disease / 139 with disease (45.9%).
- **Missing:** 6 cells (`ca` ×4, `thal` ×2), imputed inside the pipeline.
- The public dataset contains no identifiers (UCI removed names/SSNs);
  published outputs here are aggregates and figures only.

## Method in brief

Stratified 80/20 split (242 train / 61 test, seed 42) → preprocessing
(median/most-frequent imputation, scaling, one-hot encoding) fit **only**
inside training pipelines → stratified 5-fold CV on training data →
one final test evaluation. Exact duplicates were checked before splitting
(none found) and train/test overlap is asserted programmatically.

## Results (measured 2026-10-20 — actual, not illustrative)

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| SVM | 0.902 | 0.867 | 0.929 | 0.897 | 0.961 |
| Random Forest | 0.885 | 0.839 | 0.929 | 0.881 | 0.939 |
| Decision Tree | 0.754 | 0.686 | 0.857 | 0.762 | 0.762 |
| Naive Bayes | 0.672 | 0.595 | 0.893 | 0.714 | 0.848 |

SVM and Random Forest performed best on both CV and the held-out test set;
Naive Bayes achieved high recall (0.893) at the cost of many false positives
(17 of 33 negatives misclassified). With only 61 test patients, differences
of a few percentage points are within noise.

**Most influential variables (Random Forest):** maximum heart rate achieved
(`thalach`), thalassemia scan result (`thal`), number of major vessels (`ca`),
asymptomatic chest-pain type (`cp=4`) and exercise ST depression (`oldpeak`).

## Figures

![Target distribution](figures/01_target_distribution.png)
![Age by target](figures/02_age_by_target.png)
![Correlation heatmap](figures/03_correlation_heatmap.png)
![Feature importance](figures/04_feature_importance.png)
![Model comparison](figures/05_model_comparison.png)
![Confusion matrices](figures/06_confusion_matrices.png)
![ROC curves](figures/07_roc_curves.png)

## Limitations

Single-centre 1980s cohort, n = 303; ≈61-patient test set; disease severity
(`num` 1–4) collapsed to binary; historical angiographic labels; no external
validation, calibration, or subgroup/fairness analysis; missing-data mechanism
unknown. Results describe this dataset only.

## Reproduce / download

- Source ZIP: `dist/heart-disease-classification-source.zip` (code, tests,
  outputs — raw patient-level data excluded; the script re-downloads it from UCI).
- Run: `pip install -r requirements.txt && python src/run_analysis.py && python -m pytest tests/ -q`
- Machine-readable results: `outputs/results.json`

## Independence note

Inspired by the task idea in a public GitHub repository that carries no
licence; no code was copied. This is an original implementation.
