"""Evaluation helpers: metrics, cross-validation, feature importance."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import (
    accuracy_score, confusion_matrix, f1_score, precision_score,
    recall_score, roc_auc_score, roc_curve,
)
from sklearn.model_selection import StratifiedKFold, cross_validate


def evaluate_predictions(y_true, y_pred, y_score) -> dict:
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, y_score)) if y_score is not None else None,
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=[0, 1]).tolist(),
        # rows = actual [neg, pos]; TN, FP, FN, TP unpacked for readability
        "tn": int(confusion_matrix(y_true, y_pred, labels=[0, 1])[0, 0]),
        "fp": int(confusion_matrix(y_true, y_pred, labels=[0, 1])[0, 1]),
        "fn": int(confusion_matrix(y_true, y_pred, labels=[0, 1])[1, 0]),
        "tp": int(confusion_matrix(y_true, y_pred, labels=[0, 1])[1, 1]),
    }


def cross_validate_models(models: dict, X, y, n_splits: int = 5,
                          random_state: int = 42) -> dict:
    """Stratified CV on the training data only (preprocessing refit per fold)."""
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    scoring = ["accuracy", "precision", "recall", "f1", "roc_auc"]
    out = {}
    for name, pipe in models.items():
        res = cross_validate(clone(pipe), X, y, cv=cv, scoring=scoring)
        out[name] = {
            m: {"mean": float(res[f"test_{m}"].mean()), "std": float(res[f"test_{m}"].std())}
            for m in scoring
        }
    return out


def roc_points(y_true, y_score) -> dict:
    fpr, tpr, _ = roc_curve(y_true, y_score)
    return {"fpr": fpr.tolist(), "tpr": tpr.tolist()}


def random_forest_importance(fitted_pipeline, top_n: int | None = None) -> pd.DataFrame:
    """Impurity-based importance (Random Forest only), human-readable names."""
    names = fitted_pipeline.named_steps["preprocess"].get_feature_names_out()
    importances = fitted_pipeline.named_steps["model"].feature_importances_
    clean = [n.split("__", 1)[-1] for n in names]
    df = (pd.DataFrame({"feature": clean, "importance": importances})
          .sort_values("importance", ascending=False).reset_index(drop=True))
    return df.head(top_n) if top_n else df
