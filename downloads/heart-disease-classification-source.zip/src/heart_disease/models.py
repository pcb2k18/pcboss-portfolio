"""Preprocessing and model definitions.

Leakage controls
-----------------
* All imputation / scaling / encoding lives inside a single
  ``sklearn.pipeline.Pipeline`` per model, so every statistic is fit
  only on the data passed to ``fit`` (the training split, or the
  training fold inside cross-validation).
* Hyper-parameters are fixed in advance (below); the held-out test set
  is never used for tuning.
"""
from __future__ import annotations

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from .data import CATEGORICAL_FEATURES, NUMERIC_FEATURES

RANDOM_STATE = 42


def build_preprocessor() -> ColumnTransformer:
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    # sparse_threshold=0.0 -> dense output, required by GaussianNB.
    return ColumnTransformer(
        [
            ("num", numeric, NUMERIC_FEATURES),
            ("cat", categorical, CATEGORICAL_FEATURES),
        ],
        sparse_threshold=0.0,
    )


def build_models(random_state: int = RANDOM_STATE) -> dict[str, Pipeline]:
    """Fixed, pre-declared model configurations (no test-set tuning)."""
    def make(clf) -> Pipeline:
        return Pipeline([("preprocess", build_preprocessor()), ("model", clf)])

    return {
        "Random Forest": make(RandomForestClassifier(
            n_estimators=300, random_state=random_state, n_jobs=-1)),
        "Decision Tree": make(DecisionTreeClassifier(
            random_state=random_state)),
        "Naive Bayes": make(GaussianNB()),
        "SVM": make(SVC(
            kernel="rbf", C=1.0, probability=True, random_state=random_state)),
    }
