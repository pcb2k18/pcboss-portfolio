"""Dataset loading for the UCI Heart Disease (Cleveland) dataset.

Independent implementation. No code is copied from the reference
repository (which carries no licence); only the general research idea
/classification task is shared.

Dataset
-------
UCI Machine Learning Repository, *Heart Disease* (ID 45), processed
Cleveland file. Donated 1988/1989; creators: Andras Janosi, William
Steinbrunn, Matthias Pfisterer, Robert Detrano.
DOI: 10.24432/C52P4X -- https://archive.ics.uci.edu/dataset/45/heart+disease
UCI distributes datasets under CC BY 4.0 (attribution required).
The file distributed by UCI contains no names/identifiers: UCI states
names and SSNs were removed and replaced with dummy values long ago.
"""
from __future__ import annotations

import io
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

UCI_ZIP_URL = "https://archive.ics.uci.edu/static/public/45/heart+disease.zip"
UCI_DATASET_URL = "https://archive.ics.uci.edu/dataset/45/heart+disease"
DATASET_DOI = "10.24432/C52P4X"

COLUMNS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal", "num",
]
FEATURES = COLUMNS[:-1]
TARGET_ORIGINAL = "num"
TARGET = "target"

NUMERIC_FEATURES = ["age", "trestbps", "chol", "thalach", "oldpeak", "ca"]
CATEGORICAL_FEATURES = ["sex", "cp", "fbs", "restecg", "exang", "slope", "thal"]


def binarise_target(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy with binary `target`: 0 = no disease, 1 = disease (num 1-4)."""
    if TARGET_ORIGINAL not in df.columns:
        raise ValueError(f"Expected column {TARGET_ORIGINAL!r} in dataframe")
    out = df.copy()
    out[TARGET] = (out[TARGET_ORIGINAL].astype(int) > 0).astype(int)
    return out.drop(columns=[TARGET_ORIGINAL])


def parse_cleveland(text: str) -> pd.DataFrame:
    """Parse the header-less processed.cleveland.data text ('?' = missing)."""
    df = pd.read_csv(io.StringIO(text), header=None, names=COLUMNS, na_values="?")
    for col in COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["oldpeak"] = df["oldpeak"].astype(float)
    return binarise_target(df)


def download_cleveland(dest: Path, timeout: int = 60) -> Path:
    """Download the UCI zip and extract processed.cleveland.data to `dest`."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(UCI_ZIP_URL, headers={"User-Agent": "Mozilla/5.0 (portfolio-research)"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 - fixed UCI URL
        payload = resp.read()
    with zipfile.ZipFile(io.BytesIO(payload)) as zf:
        names = [n for n in zf.namelist() if n.endswith("processed.cleveland.data")]
        if not names:
            raise RuntimeError(f"processed.cleveland.data not found in UCI archive: {zf.namelist()}")
        text = zf.read(names[0]).decode("utf-8", errors="replace")
    dest.write_text(text, encoding="utf-8")
    return dest


def load_dataset(raw_path: Path, download_if_missing: bool = True) -> pd.DataFrame:
    """Load (optionally downloading) the Cleveland dataset as a tidy frame."""
    raw_path = Path(raw_path)
    if not raw_path.exists():
        if not download_if_missing:
            raise FileNotFoundError(f"Dataset not found at {raw_path}; run the download step first.")
        download_cleveland(raw_path)
    return parse_cleveland(raw_path.read_text(encoding="utf-8"))


def deduplicate(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Drop exact duplicate rows (all features + target). Returns (df, n_dropped)."""
    before = len(df)
    out = df.drop_duplicates(subset=FEATURES + [TARGET]).reset_index(drop=True)
    return out, before - len(out)


def assert_no_split_overlap(train: pd.DataFrame, test: pd.DataFrame) -> None:
    """Raise if any exact (features+target) row appears in both splits."""
    cols = FEATURES + [TARGET]
    train_keys = set(map(tuple, train[cols].astype(str).to_numpy()))
    test_keys = set(map(tuple, test[cols].astype(str).to_numpy()))
    overlap = train_keys & test_keys
    if overlap:
        raise AssertionError(f"{len(overlap)} duplicate row(s) shared between train and test splits")


def dataset_summary(df: pd.DataFrame) -> dict:
    return {
        "n_records": int(len(df)),
        "n_features": int(len(FEATURES)),
        "features": FEATURES,
        "numeric_features": NUMERIC_FEATURES,
        "categorical_features": CATEGORICAL_FEATURES,
        "target_counts": {str(k): int(v) for k, v in df[TARGET].value_counts().sort_index().items()},
        "target_prevalence_positive": float(df[TARGET].mean()),
        "missing_by_column": {k: int(v) for k, v in df.isna().sum().items() if v},
        "total_missing_cells": int(df.isna().sum().sum()),
        "duplicate_rows_dropped": 0,  # filled by caller
        "age_range": [float(df["age"].min()), float(df["age"].max())],
        "sex_counts": {str(k): int(v) for k, v in df["sex"].value_counts().sort_index().items()},
    }
