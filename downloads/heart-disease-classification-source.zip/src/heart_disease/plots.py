"""All figures. Uses only aggregated data -- never patient-level outputs
beyond the standard EDA distributions of the public, de-identified file."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from .data import NUMERIC_FEATURES

sns.set_theme(style="whitegrid", context="notebook")
PALETTE = ["#2563eb", "#dc2626", "#059669", "#d97706"]


def _save(fig, path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return path.name


def plot_target_distribution(df, path) -> str:
    fig, ax = plt.subplots(figsize=(5, 4))
    counts = df["target"].value_counts().sort_index()
    ax.bar(["No disease (0)", "Disease (1)"], counts.values, color=PALETTE[:2])
    ax.set_ylabel("Patients"); ax.set_title("Target distribution (Cleveland, n=%d)" % len(df))
    for i, v in enumerate(counts.values):
        ax.text(i, v + 3, str(v), ha="center", fontweight="bold")
    return _save(fig, Path(path))


def plot_age_by_target(df, path) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    for label, colour in [(0, PALETTE[0]), (1, PALETTE[1])]:
        ax.hist(df.loc[df.target == label, "age"], bins=15, alpha=0.65,
                label=f"target={label}", color=colour)
    ax.set_xlabel("Age (years)"); ax.set_ylabel("Patients")
    ax.set_title("Age distribution by heart-disease status"); ax.legend()
    return _save(fig, Path(path))


def plot_correlation_heatmap(df, path) -> str:
    fig, ax = plt.subplots(figsize=(7, 6))
    corr = df[NUMERIC_FEATURES + ["target"]].corr(numeric_only=True)
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0,
                square=True, ax=ax, cbar_kws={"shrink": 0.8})
    ax.set_title("Pearson correlation -- numeric features & target")
    return _save(fig, Path(path))


def plot_feature_importance(importance: pd.DataFrame, path, top_n=15) -> str:
    top = importance.head(top_n).iloc[::-1]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(top["feature"], top["importance"], color=PALETTE[0])
    ax.set_xlabel("Random Forest impurity importance")
    ax.set_title(f"Top {len(top)} features -- Random Forest (training data)")
    return _save(fig, Path(path))


def plot_model_comparison(results: dict, path) -> str:
    metrics = ["accuracy", "precision", "recall", "f1", "roc_auc"]
    labels = ["Accuracy", "Precision", "Recall", "F1", "ROC-AUC"]
    names = list(results.keys())
    x = np.arange(len(metrics)); width = 0.8 / max(len(names), 1)
    fig, ax = plt.subplots(figsize=(10, 5))
    for i, name in enumerate(names):
        vals = [results[name][m] for m in metrics]
        ax.bar(x + i * width, vals, width=width, label=name, color=PALETTE[i % len(PALETTE)])
    ax.set_xticks(x + width * (len(names) - 1) / 2); ax.set_xticklabels(labels)
    ax.set_ylim(0, 1.05); ax.set_ylabel("Score (held-out test set)")
    ax.set_title("Model performance -- held-out test set"); ax.legend(ncol=2)
    return _save(fig, Path(path))


def plot_confusion_matrices(results: dict, path) -> str:
    names = list(results.keys())
    fig, axes = plt.subplots(2, 2, figsize=(9, 8))
    for ax, name in zip(np.ravel(axes), names):
        cm = np.array(results[name]["confusion_matrix"])
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                    xticklabels=["Pred 0", "Pred 1"], yticklabels=["Actual 0", "Actual 1"])
        ax.set_title(name); ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
    fig.suptitle("Confusion matrices -- held-out test set")
    return _save(fig, Path(path))


def plot_roc_curves(roc_data: dict, results: dict, path) -> str:
    fig, ax = plt.subplots(figsize=(7, 6))
    for i, (name, pts) in enumerate(roc_data.items()):
        ax.plot(pts["fpr"], pts["tpr"], label=f"{name} (AUC={results[name]['roc_auc']:.3f})",
                color=PALETTE[i % len(PALETTE)], linewidth=2)
    ax.plot([0, 1], [0, 1], "k--", linewidth=1, label="Chance")
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
    ax.set_title("ROC curves -- held-out test set"); ax.legend(loc="lower right")
    return _save(fig, Path(path))
