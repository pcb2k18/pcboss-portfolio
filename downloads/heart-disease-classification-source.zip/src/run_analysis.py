"""Run the complete, reproducible analysis.

Usage (from project root):
    pip install -r requirements.txt
    python src/run_analysis.py

Outputs: outputs/results.json, outputs/figures/*.png
The test set is touched exactly once per model, at final evaluation.
"""
from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import matplotlib
import numpy as np
import pandas as pd
import seaborn
import sklearn
from sklearn.model_selection import train_test_split

from heart_disease import plots
from heart_disease.data import (
    DATASET_DOI, FEATURES, TARGET, UCI_DATASET_URL, assert_no_split_overlap,
    dataset_summary, deduplicate, load_dataset,
)
from heart_disease.evaluate import (
    cross_validate_models, evaluate_predictions, random_forest_importance, roc_points,
)
from heart_disease.models import RANDOM_STATE, build_models

ROOT = Path(__file__).resolve().parents[1]
RAW_PATH = ROOT / "data" / "raw" / "processed.cleveland.data"
OUT = ROOT / "outputs"
FIG = OUT / "figures"
TEST_SIZE = 0.20


def main() -> dict:
    FIG.mkdir(parents=True, exist_ok=True)
    df_raw = load_dataset(RAW_PATH)
    n_before = len(df_raw)
    df, n_dupes = deduplicate(df_raw)

    X, y = df[FEATURES], df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y)
    assert_no_split_overlap(
        pd.concat([X_train, y_train], axis=1), pd.concat([X_test, y_test], axis=1))

    models = build_models()
    cv_results = cross_validate_models(models, X_train, y_train)

    test_results, roc_data, fitted = {}, {}, {}
    for name, pipe in models.items():
        pipe.fit(X_train, y_train)
        fitted[name] = pipe
        pred = pipe.predict(X_test)
        score = pipe.predict_proba(X_test)[:, 1]
        test_results[name] = evaluate_predictions(y_test, pred, score)
        roc_data[name] = roc_points(y_test, score)

    importance = random_forest_importance(fitted["Random Forest"])

    figures = [
        plots.plot_target_distribution(df, FIG / "01_target_distribution.png"),
        plots.plot_age_by_target(df, FIG / "02_age_by_target.png"),
        plots.plot_correlation_heatmap(df, FIG / "03_correlation_heatmap.png"),
        plots.plot_feature_importance(importance, FIG / "04_feature_importance.png"),
        plots.plot_model_comparison(test_results, FIG / "05_model_comparison.png"),
        plots.plot_confusion_matrices(test_results, FIG / "06_confusion_matrices.png"),
        plots.plot_roc_curves(roc_data, test_results, FIG / "07_roc_curves.png"),
    ]

    summary = dataset_summary(df)
    summary["duplicate_rows_dropped"] = int(n_dupes)
    summary["records_before_dedup"] = int(n_before)

    results = {
        "project": "Heart Disease Classification and Model Evaluation",
        "note": ("Educational portfolio analysis only. NOT a clinically validated "
                 "diagnostic tool. See README 'Limitations'."),
        "dataset": {
            "name": "UCI Heart Disease -- processed Cleveland database",
            "source_url": UCI_DATASET_URL,
            "doi": DATASET_DOI,
            "licence": "CC BY 4.0 (UCI Machine Learning Repository terms; attribution required)",
            "citation": ("Janosi, A., Steinbrunn, W., Pfisterer, M., & Detrano, R. (1989). "
                         "Heart Disease [Dataset]. UCI Machine Learning Repository. "
                         "https://doi.org/10.24432/C52P4X"),
            "download_url": "https://archive.ics.uci.edu/static/public/45/heart+disease.zip",
            "file_used": "processed.cleveland.data",
            **summary,
        },
        "method": {
            "target_definition": "target=1 if original 'num' in {1,2,3,4} (>50% diameter narrowing in any major vessel), else 0",
            "split": {"test_size": TEST_SIZE, "stratified": True, "random_state": RANDOM_STATE,
                      "train_records": int(len(X_train)), "test_records": int(len(X_test))},
            "preprocessing": ("Pipeline fit on training data only: numeric median-imputation + "
                              "standard scaling; categorical most-frequent imputation + one-hot encoding"),
            "cross_validation": "StratifiedKFold(n_splits=5, shuffle=True, random_state=42) on training data only",
            "hyperparameter_tuning": "None. Fixed, pre-declared configurations; test set never used for tuning.",
            "duplicate_check": "Exact duplicate (features+target) rows dropped before splitting; train/test overlap asserted as zero.",
            "models": list(models.keys()),
        },
        "cross_validation_training_only": cv_results,
        "test_results": test_results,
        "feature_importance_random_forest": [
            {"feature": r.feature, "importance": float(r.importance)}
            for r in importance.itertuples()
        ],
        "figures": [f"outputs/figures/{f}" for f in figures],
        "environment": {
            "python": platform.python_version(),
            "pandas": pd.__version__, "numpy": np.__version__,
            "scikit_learn": sklearn.__version__,
            "matplotlib": matplotlib.__version__, "seaborn": seaborn.__version__,
            "platform": platform.platform(),
        },
        "limitations": [
            "Single-centre Cleveland cohort collected in the 1980s (n~300); not representative of modern or diverse populations.",
            "Small sample: held-out test set is ~60 patients, so test metrics have wide uncertainty.",
            "Binarising 'num' (0 vs 1-4) discards disease-severity information.",
            "Angiographic label and 1980s measurement practices may not match current clinical definitions/devices.",
            "No external validation, calibration assessment, fairness/subgroup analysis, or prospective evaluation.",
            "Missing values ('?') in 'ca'/'thal' are imputed; the missingness mechanism is unknown.",
            "Models are educational demonstrations and must not be used for diagnosis or clinical decisions.",
        ],
    }
    (OUT / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(json.dumps(test_results, indent=2))
    print(f"\nWrote {OUT / 'results.json'} and {len(figures)} figures to {FIG}")
    return results


if __name__ == "__main__":
    main()
