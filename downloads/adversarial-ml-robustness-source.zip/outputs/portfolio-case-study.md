# Adversarial Machine Learning and Model Robustness

## Portfolio case study

Project page: https://pcboss.me (portfolio listing to be added by the site owner; this repository does not modify that site).

## Research question

Can small, gradient based, pixel space perturbations change the predictions of a compact convolutional image classifier, and how does the effect grow with perturbation strength?

## Threat model

This project studies untargeted white-box attacks under an L-infinity budget. The attacker knows the architecture and weights, computes exact gradients of the loss with respect to the input pixels, and may perturb every pixel by at most epsilon. FGSM takes one step of size epsilon. PGD takes 20 steps of size epsilon divided by 4, starts from a uniform random point inside the allowed ball, and projects back into the ball and into the valid image range after every step. Restarts used in the reported run: 1.

Robustness to these two attacks does not prove security against all adversaries. It says nothing about black-box transfer attacks, query based attacks, physical world perturbations, poisoning, model extraction, larger budgets, other distance norms, or adaptive attackers who know a defense is present. It also says nothing about whether a perturbation that fools the model would fool a human, and the CIFAR-10 images are small and low resolution.

## Dataset

CIFAR-10 was loaded with torchvision from the official source. The official training split has 50000 images and the official test split has 10000 images. Each image is 32 by 32 pixels with 3 colour channels. Classes: airplane, automobile, bird, cat, deer, dog, frog, horse, ship, truck. The training split class counts are balanced at 5,000 per class and the test split at 1,000 per class.

Model development used only the official training split. Training used a stratified subset of 15000 training images and a disjoint stratified validation set of 3000 images, also from the training split, for checkpoint selection. The final test labels were not used for fitting, tuning, or model selection. Final evaluation used one fixed stratified subset of 1000 test images (100 per class), and the same subset was used for every clean and adversarial comparison.

## Model and training

The classifier is a compact CNN written for this project: three convolutional blocks (32, 64, and 128 channels) with batch normalization and max pooling, followed by a 128 unit fully connected layer with dropout. Trainable parameters: 403306. Training from scratch used AdamW (learning rate 0.001, weight decay 0.0005), batch size 128, 12 epochs, and a cosine learning rate schedule, with random crop and horizontal flip augmentation. Device used: cpu. Seed: 42. Best validation accuracy on the training split holdout: 75.57%.

Clean accuracy on the fixed test subset: 75.50% (n = 1000).

## Attack results for the normally trained CNN

Epsilon values, in pixel space: 0/255, 2/255, 4/255, 8/255. Attack success rate is measured only among examples the model classified correctly before the attack.

| Epsilon | FGSM robust accuracy | FGSM attack success rate | PGD robust accuracy | PGD attack success rate |
|---|---|---|---|---|
| 0/255 | 75.50% | 0.00% | 75.50% | 0.00% |
| 2/255 | 26.10% | 65.43% | 12.60% | 83.31% |
| 4/255 | 9.00% | 88.08% | 0.30% | 99.60% |
| 8/255 | 3.00% | 96.03% | 0.00% | 100.00% |

## Findings

1. Small perturbations do affect predictions. The table above is the evidence: robust accuracy at each epsilon can be compared directly with the clean accuracy of 75.50% on the same images.
2. PGD was the stronger attack in this experiment. At every non-zero epsilon its robust accuracy is lower and its attack success rate is higher than FGSM at the same epsilon, which is consistent with PGD searching the allowed ball over 20 steps instead of taking one step.
3. Robust accuracy falls as epsilon grows from 0/255 to 8/255. The size of the fall, in percentage points, is clean accuracy minus robust accuracy at each row of the table.
4. Successful attacks are shown in figure 07 with the original image, the FGSM example, and the PGD example side by side. Unsuccessful attacks are the complement counted by the attack success rate: initially correct examples whose predicted label did not change. Figure 08 shows absolute perturbations magnified 10 times. The magnification is stated in the figure title because the raw perturbations at 8/255 are close to invisible.
5. Confusion matrices (figures 09 and 10) show which classes absorb the errors under attack on this test subset.

## Defense experiment

A second compact CNN with the same architecture was trained with FGSM adversarial training (epsilon 8/255 on every batch, 8000 training samples, 5 epochs). It was evaluated on the identical fixed test subset and attack settings.

Clean accuracy: normal 75.50%, adversarially trained 42.30%.

| Epsilon | FGSM robust accuracy | FGSM attack success rate | PGD robust accuracy | PGD attack success rate |
|---|---|---|---|---|
| 0/255 | 42.30% | 0.00% | 42.30% | 0.00% |
| 2/255 | 39.30% | 7.33% | 39.10% | 7.80% |
| 4/255 | 35.50% | 16.31% | 35.40% | 16.31% |
| 8/255 | 27.80% | 34.28% | 27.00% | 36.17% |

Any robustness difference above is a measured result for this small experiment only. The two models differ in training set size and epochs as recorded in outputs/results.json, so the comparison is indicative, not a controlled ablation.

## Limitations

- The classifier was trained on a subset of the training data for a small number of epochs on a personal computer, so its clean accuracy is below what a longer training run with the full data would reach. Robustness numbers are conditional on this model.
- Evaluation used 1000 test images, not the full 10,000 image test split. Per class results therefore rest on 100 images per class.
- PGD used 20 steps and 1 restart. A stronger attacker with more steps and restarts could reduce robust accuracy further, so the PGD figures are an upper bound on true robust accuracy under this budget, not a certificate.
- Only L-infinity FGSM and PGD were tested. No certified defense is claimed.
- Adversarial training, if reported above, used FGSM examples only and a smaller training run. It is a small experiment, not a production defense.

## Reproduction

See README.md for commands. All reported numbers come from outputs/results.json, which is produced by run_experiment.py from actual model predictions.

## Reference and license note

The public repository at https://github.com/poojakira/adversarial-ml-lab was inspected for its topic and license. Its LICENSE file states a proprietary, all rights reserved, source visible license. It is not an MIT license. No code, experiments, text, or figures were copied from it. This project is an independent implementation written from the standard published definitions of FGSM and PGD.
