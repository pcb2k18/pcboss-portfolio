"""Fixed test subset evaluation for clean, FGSM, and PGD accuracy."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
from torchvision import datasets

from src.attacks import fgsm_attack, pgd_attack
from src.data import load_cifar10, make_eval_indices, normalize, plain_transform, set_seed
from src.metrics import accuracy, attack_success_rate, confusion_matrix_np
from src.model import CompactCNN


def predict_pixel(model, images_pixel, device):
    model.eval()
    with torch.no_grad():
        return model(normalize(images_pixel.to(device), device)).argmax(1).cpu().numpy()


def evaluate_model(model, checkpoint_label: str, config: dict, device, save_examples_to: Path | None = None) -> dict:
    seed = int(config["seed"])
    set_seed(seed)
    _train_full, test_full = load_cifar10(config["data_root"])
    eval_idx = make_eval_indices(list(test_full.targets), int(config["eval_subset_size"]), seed)
    test_pixel = datasets.CIFAR10(root=config["data_root"], train=False, download=False,
                                  transform=plain_transform())
    loader = DataLoader(Subset(test_pixel, eval_idx), batch_size=int(config["eval_batch_size"]),
                        shuffle=False, num_workers=0)

    all_images, all_labels = [], []
    for x, y in loader:
        all_images.append(x)
        all_labels.append(y)
    images = torch.cat(all_images)  # pixel space [0, 1]
    labels = torch.cat(all_labels).numpy()

    clean_pred = predict_pixel(model, images, device)
    clean_acc = accuracy(clean_pred, labels)

    eps_values = [int(v) / 255.0 for v in config["epsilons_over_255"]]
    pgd_steps = int(config["pgd_steps"])
    pgd_restarts = int(config["pgd_restarts"])

    results = {
        "model": checkpoint_label,
        "eval_subset_size": int(len(labels)),
        "eval_indices_first_20": [int(i) for i in eval_idx[:20]],
        "eval_indices_sha_note": "Full index list is reproducible from seed, subset size, and the stratified selector in src/data.py.",
        "clean_accuracy": clean_acc,
        "fgsm": {},
        "pgd": {},
        "confusion_clean": confusion_matrix_np(clean_pred, labels).tolist(),
    }

    saved = {"labels": labels, "clean_pred": clean_pred}
    # Keep a small set of examples for visualization: first 8 test images.
    example_count = 8
    saved["original"] = images[:example_count].numpy()

    for eps in eps_values:
        eps_key = f"{int(round(eps * 255))}/255"
        if eps == 0:
            results["fgsm"][eps_key] = {"robust_accuracy": clean_acc, "attack_success_rate": 0.0}
            results["pgd"][eps_key] = {"robust_accuracy": clean_acc, "attack_success_rate": 0.0,
                                       "steps": pgd_steps, "alpha": 0.0, "restarts": pgd_restarts}
            continue
        fgsm_preds, pgd_preds = [], []
        alpha = eps / 4.0
        for start in range(0, len(labels), int(config["eval_batch_size"])):
            xb = images[start:start + int(config["eval_batch_size"])]
            yb = torch.from_numpy(labels[start:start + int(config["eval_batch_size"])])
            adv_f = fgsm_attack(model, xb, yb, eps, device)
            fgsm_preds.append(predict_pixel(model, adv_f, device))
            gen = torch.Generator(device="cpu")
            gen.manual_seed(seed + start)
            adv_p = pgd_attack(model, xb, yb, eps, alpha, pgd_steps, device,
                               random_start=True, restarts=pgd_restarts, generator=gen)
            pgd_preds.append(predict_pixel(model, adv_p, device))
            if start == 0 and save_examples_to is not None and eps_key == "8/255":
                saved["fgsm_adv_8"] = adv_f[:example_count].cpu().numpy()
                saved["pgd_adv_8"] = adv_p[:example_count].cpu().numpy()
                saved["fgsm_pred_8"] = fgsm_preds[-1][:example_count]
                saved["pgd_pred_8"] = pgd_preds[-1][:example_count]
        fgsm_pred_all = np.concatenate(fgsm_preds)
        pgd_pred_all = np.concatenate(pgd_preds)
        results["fgsm"][eps_key] = {
            "robust_accuracy": accuracy(fgsm_pred_all, labels),
            "attack_success_rate": attack_success_rate(clean_pred, fgsm_pred_all, labels),
        }
        results["pgd"][eps_key] = {
            "robust_accuracy": accuracy(pgd_pred_all, labels),
            "attack_success_rate": attack_success_rate(clean_pred, pgd_pred_all, labels),
            "steps": pgd_steps, "alpha": alpha, "alpha_over_255": alpha * 255.0,
            "restarts": pgd_restarts, "random_start": True,
        }
        if eps_key == "8/255":
            results["confusion_pgd_8_255"] = confusion_matrix_np(pgd_pred_all, labels).tolist()
            results["confusion_fgsm_8_255"] = confusion_matrix_np(fgsm_pred_all, labels).tolist()
        print(f"{checkpoint_label} eps {eps_key} FGSM {results['fgsm'][eps_key]['robust_accuracy']:.4f} "
              f"PGD {results['pgd'][eps_key]['robust_accuracy']:.4f}", flush=True)

    if save_examples_to is not None:
        save_examples_to.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(save_examples_to, **saved)
    return results


def load_model(checkpoint: Path, device):
    model = CompactCNN().to(device)
    payload = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(payload["state_dict"])
    model.eval()
    return model, payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/experiment.json")
    parser.add_argument("--checkpoint", default="outputs/checkpoints/model.pt")
    parser.add_argument("--label", default="normal")
    parser.add_argument("--output", default="outputs/evaluation_normal.json")
    parser.add_argument("--examples", default="outputs/examples.npz")
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model, _payload = load_model(Path(args.checkpoint), device)
    result = evaluate_model(model, args.label, config, device, Path(args.examples))
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
