"""Figures generated only from saved experiment outputs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from src.data import CIFAR10_CLASSES

FIG = Path("outputs/figures")


def save(fig, name: str) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(FIG / name, dpi=200)
    plt.close(fig)
    print(f"wrote {FIG / name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="outputs/results.json")
    args = parser.parse_args()
    results = json.loads(Path(args.results).read_text(encoding="utf-8"))
    normal = results["evaluation"]["normal"]
    eps_labels = list(normal["fgsm"].keys())
    eps_vals = [int(x.split("/")[0]) for x in eps_labels]

    # 1. Class distribution (official splits)
    info = results["dataset"]
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.5), sharey=True)
    for ax, key, title in [(axes[0], "train_class_counts", "CIFAR-10 training split (50,000)"),
                           (axes[1], "test_class_counts", "CIFAR-10 test split (10,000)")]:
        counts = [info[key][c] for c in CIFAR10_CLASSES]
        ax.barh(CIFAR10_CLASSES, counts, color="#3b6ea5")
        ax.set_title(title, fontsize=10)
        ax.set_xlabel("Images")
    save(fig, "01_class_distribution.png")

    # 2. Training progress
    hist = results["training"]["normal"]["history"]
    fig, ax1 = plt.subplots(figsize=(7, 4))
    ax1.plot(hist["epoch"], [v * 100 for v in hist["train_accuracy"]], marker="o", label="Train accuracy")
    ax1.plot(hist["epoch"], [v * 100 for v in hist["validation_accuracy"]], marker="s", label="Validation accuracy (train split holdout)")
    ax1.set_xlabel("Epoch"); ax1.set_ylabel("Accuracy (%)"); ax1.legend(); ax1.grid(alpha=0.3)
    ax1.set_title("Training progress, normally trained CNN")
    save(fig, "02_training_progress.png")

    # 3. Clean accuracy
    fig, ax = plt.subplots(figsize=(5, 4))
    labels_bar = ["Normal CNN"]
    values = [normal["clean_accuracy"] * 100]
    adv_eval = results["evaluation"].get("adversarially_trained")
    if adv_eval:
        labels_bar.append("Adv. trained CNN")
        values.append(adv_eval["clean_accuracy"] * 100)
    ax.bar(labels_bar, values, color=["#3b6ea5", "#c07a2c"][:len(values)])
    ax.set_ylim(0, 100); ax.set_ylabel("Clean accuracy (%)")
    ax.set_title(f"Clean accuracy on fixed test subset (n={normal['eval_subset_size']})")
    for i, v in enumerate(values):
        ax.text(i, v + 1, f"{v:.1f}%", ha="center")
    save(fig, "03_clean_accuracy.png")

    # 4 and 5. Robustness curves
    for attack, fname, title in [("fgsm", "04_fgsm_robustness.png", "FGSM robust accuracy by epsilon"),
                                 ("pgd", "05_pgd_robustness.png", "PGD robust accuracy by epsilon")]:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(eps_vals, [normal[attack][k]["robust_accuracy"] * 100 for k in eps_labels],
                marker="o", label="Normal CNN")
        if adv_eval:
            ax.plot(eps_vals, [adv_eval[attack][k]["robust_accuracy"] * 100 for k in eps_labels],
                    marker="s", label="Adv. trained CNN")
        ax.set_xlabel("Epsilon (in 255ths, pixel space)"); ax.set_ylabel("Robust accuracy (%)")
        ax.set_title(title); ax.grid(alpha=0.3); ax.legend(); ax.set_ylim(0, 100)
        save(fig, fname)

    # 6. Clean versus adversarial at 8/255
    fig, ax = plt.subplots(figsize=(7, 4))
    cats = ["Clean", "FGSM 8/255", "PGD 8/255"]
    normal_vals = [normal["clean_accuracy"] * 100, normal["fgsm"]["8/255"]["robust_accuracy"] * 100,
                   normal["pgd"]["8/255"]["robust_accuracy"] * 100]
    x = np.arange(len(cats)); width = 0.38
    ax.bar(x - width / 2, normal_vals, width, label="Normal CNN", color="#3b6ea5")
    if adv_eval:
        adv_vals = [adv_eval["clean_accuracy"] * 100, adv_eval["fgsm"]["8/255"]["robust_accuracy"] * 100,
                    adv_eval["pgd"]["8/255"]["robust_accuracy"] * 100]
        ax.bar(x + width / 2, adv_vals, width, label="Adv. trained CNN", color="#c07a2c")
    ax.set_xticks(x, cats); ax.set_ylabel("Accuracy (%)"); ax.set_ylim(0, 100)
    ax.set_title("Clean versus adversarial accuracy"); ax.legend(); ax.grid(axis="y", alpha=0.3)
    save(fig, "06_clean_vs_adversarial.png")

    # 7 and 8. Examples and perturbations, if saved
    ex_path = Path("outputs/examples.npz")
    if ex_path.exists():
        data = np.load(ex_path)
        orig = data["original"]; labels = data["labels"][:len(orig)]
        clean_pred = data["clean_pred"][:len(orig)]
        if "fgsm_adv_8" in data and "pgd_adv_8" in data:
            fgsm_adv = data["fgsm_adv_8"]; pgd_adv = data["pgd_adv_8"]
            n = min(6, len(orig))
            fig, axes = plt.subplots(n, 3, figsize=(6, 2.1 * n))
            for i in range(n):
                for j, (img, title) in enumerate([
                        (orig[i], f"Original: {CIFAR10_CLASSES[labels[i]]}"),
                        (fgsm_adv[i], f"FGSM 8/255 pred: {CIFAR10_CLASSES[int(data['fgsm_pred_8'][i])]}"),
                        (pgd_adv[i], f"PGD 8/255 pred: {CIFAR10_CLASSES[int(data['pgd_pred_8'][i])]}")]):
                    ax = axes[i, j] if n > 1 else axes[j]
                    ax.imshow(np.transpose(img, (1, 2, 0)))
                    ax.set_title(title, fontsize=7); ax.axis("off")
            fig.suptitle("Original and adversarial examples (adversarial changes are small at 8/255)", fontsize=9)
            save(fig, "07_adversarial_examples.png")

            fig, axes = plt.subplots(n, 2, figsize=(6, 2.1 * n))
            for i in range(n):
                for j, adv in enumerate([fgsm_adv[i], pgd_adv[i]]):
                    pert = np.abs(adv - orig[i]).transpose(1, 2, 0)
                    magnified = np.clip(pert * 10.0, 0, 1)  # 10x magnification, labelled below
                    ax = axes[i, j] if n > 1 else axes[j]
                    ax.imshow(magnified)
                    ax.set_title(("FGSM" if j == 0 else "PGD") + " perturbation, magnified 10x", fontsize=7)
                    ax.axis("off")
            fig.suptitle("Perturbations magnified 10x for visibility. Not to scale with the original images.", fontsize=9)
            save(fig, "08_perturbations_magnified.png")

    # Confusion matrices
    for key, fname, title in [("confusion_clean", "09_confusion_clean.png", "Confusion matrix, clean"),
                              ("confusion_pgd_8_255", "10_confusion_pgd_8_255.png", "Confusion matrix, PGD 8/255")]:
        if key in normal:
            matrix = np.array(normal[key])
            fig, ax = plt.subplots(figsize=(6, 5))
            im = ax.imshow(matrix, cmap="Blues")
            ax.set_xticks(range(10), CIFAR10_CLASSES, rotation=45, ha="left", fontsize=7)
            ax.set_yticks(range(10), CIFAR10_CLASSES, fontsize=7)
            ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(title)
            fig.colorbar(im, ax=ax, shrink=0.8)
            save(fig, fname)


if __name__ == "__main__":
    main()
