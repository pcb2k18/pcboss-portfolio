"""Metric helpers used by evaluation and by the automated tests."""
from __future__ import annotations

import numpy as np


def accuracy(predictions, labels) -> float:
    predictions = np.asarray(predictions)
    labels = np.asarray(labels)
    if labels.size == 0:
        raise ValueError("accuracy requires at least one sample")
    return float((predictions == labels).mean())


def attack_success_rate(clean_predictions, adv_predictions, labels) -> float:
    """Fraction of initially correct examples that the attack flips."""
    clean_predictions = np.asarray(clean_predictions)
    adv_predictions = np.asarray(adv_predictions)
    labels = np.asarray(labels)
    initially_correct = clean_predictions == labels
    if int(initially_correct.sum()) == 0:
        return 0.0
    flipped = adv_predictions[initially_correct] != labels[initially_correct]
    return float(flipped.mean())


def confusion_matrix_np(predictions, labels, num_classes: int = 10):
    matrix = np.zeros((num_classes, num_classes), dtype=int)
    for true_label, pred_label in zip(np.asarray(labels), np.asarray(predictions)):
        matrix[int(true_label), int(pred_label)] += 1
    return matrix
