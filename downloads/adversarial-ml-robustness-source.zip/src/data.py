"""CIFAR-10 loading, stratified subsets, and normalization helpers."""
from __future__ import annotations

import random
from collections import Counter

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

CIFAR10_CLASSES = [
    "airplane", "automobile", "bird", "cat", "deer",
    "dog", "frog", "horse", "ship", "truck",
]
# Channel statistics computed from the CIFAR-10 training split and widely
# reported with the dataset. They are used only to normalize model inputs.
CIFAR10_MEAN = (0.4914, 0.4822, 0.4465)
CIFAR10_STD = (0.2470, 0.2435, 0.2616)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def mean_std_tensors(device: torch.device):
    mean = torch.tensor(CIFAR10_MEAN, device=device).view(1, 3, 1, 1)
    std = torch.tensor(CIFAR10_STD, device=device).view(1, 3, 1, 1)
    return mean, std


def normalize(pixel_images: torch.Tensor, device: torch.device) -> torch.Tensor:
    """Convert images in pixel space [0, 1] to normalized model inputs."""
    mean, std = mean_std_tensors(device)
    return (pixel_images - mean) / std


def train_transform() -> transforms.Compose:
    return transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
    ])


def plain_transform() -> transforms.Compose:
    # ToTensor converts uint8 pixels in [0, 255] to floats in [0, 1].
    # No normalization here, so attack code receives true pixel space tensors.
    return transforms.Compose([transforms.ToTensor()])


def normalized_transform() -> transforms.Compose:
    return transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
    ])


def load_cifar10(root: str):
    """Download (if needed) and return the official train and test sets."""
    train_full = datasets.CIFAR10(root=root, train=True, download=True, transform=None)
    test_full = datasets.CIFAR10(root=root, train=False, download=True, transform=None)
    return train_full, test_full


def stratified_indices(labels, per_class_counts: dict, seed: int) -> list[int]:
    """Select a fixed number of indices per class with a seeded shuffle."""
    rng = random.Random(seed)
    by_class: dict[int, list[int]] = {}
    for idx, label in enumerate(labels):
        by_class.setdefault(int(label), []).append(idx)
    chosen: list[int] = []
    for cls in sorted(by_class):
        pool = list(by_class[cls])
        rng.shuffle(pool)
        chosen.extend(pool[: per_class_counts[cls]])
    rng.shuffle(chosen)
    return chosen


def make_train_validation_indices(labels, train_size: int, val_size: int, seed: int):
    """Stratified, disjoint train and validation indices from the train split."""
    n_classes = len(set(int(x) for x in labels))
    train_per = train_size // n_classes
    val_per = val_size // n_classes
    rng = random.Random(seed)
    by_class: dict[int, list[int]] = {}
    for idx, label in enumerate(labels):
        by_class.setdefault(int(label), []).append(idx)
    train_idx, val_idx = [], []
    for cls in sorted(by_class):
        pool = list(by_class[cls])
        rng.shuffle(pool)
        train_idx.extend(pool[:train_per])
        val_idx.extend(pool[train_per: train_per + val_per])
    rng.shuffle(train_idx)
    rng.shuffle(val_idx)
    assert set(train_idx).isdisjoint(val_idx)
    return train_idx, val_idx


def make_eval_indices(labels, total_size: int, seed: int) -> list[int]:
    n_classes = len(set(int(x) for x in labels))
    per = total_size // n_classes
    return stratified_indices(labels, {c: per for c in range(n_classes)}, seed)


def dataset_info(train_full, test_full) -> dict:
    train_labels = list(train_full.targets)
    test_labels = list(test_full.targets)
    sample_image, sample_label = train_full[0]
    return {
        "name": "CIFAR-10",
        "source": "https://www.cs.toronto.edu/~kriz/cifar.html via torchvision.datasets.CIFAR10",
        "license_note": "CIFAR-10 is released by the University of Toronto Learning Algorithms group for research use. See the dataset page for terms. Raw data files are not redistributed in this project ZIP.",
        "class_names": CIFAR10_CLASSES,
        "train_size_official": len(train_full),
        "test_size_official": len(test_full),
        "image_size_pil": list(sample_image.size) + [len(sample_image.getbands())],
        "image_shape_chw_after_totensor": [3, 32, 32],
        "sample_label_index": int(sample_label),
        "train_class_counts": {CIFAR10_CLASSES[k]: int(v) for k, v in sorted(Counter(train_labels).items())},
        "test_class_counts": {CIFAR10_CLASSES[k]: int(v) for k, v in sorted(Counter(test_labels).items())},
        "pixel_range_after_totensor": [0.0, 1.0],
        "normalization_mean": list(CIFAR10_MEAN),
        "normalization_std": list(CIFAR10_STD),
    }
