"""Training script for the normally trained and adversarially trained CNNs."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader, Subset
from torchvision import datasets

from src.attacks import fgsm_attack
from src.data import (CIFAR10_CLASSES, load_cifar10, make_train_validation_indices,
                      normalized_transform, set_seed, train_transform)
from src.model import CompactCNN, count_parameters


def evaluate_normalized(model, loader, device) -> float:
    model.eval()
    correct = total = 0
    with torch.no_grad():
        for x, y in loader:
            pred = model(x.to(device)).argmax(1).cpu()
            correct += int((pred == y).sum())
            total += len(y)
    return correct / max(total, 1)


def train_one(config: dict, adversarial: bool, out_checkpoint: Path, history_path: Path,
              subset_size: int, epochs: int) -> dict:
    seed = int(config["seed"])
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_full_raw, _test_full = load_cifar10(config["data_root"])
    labels = list(train_full_raw.targets)
    train_idx, val_idx = make_train_validation_indices(
        labels, subset_size, int(config["validation_size"]), seed)

    root = config["data_root"]
    train_aug = datasets.CIFAR10(root=root, train=True, download=False, transform=train_transform())
    train_plain = datasets.CIFAR10(root=root, train=True, download=False, transform=None)
    # For adversarial training we need pixel space batches, so use plain
    # ToTensor data and apply augmentation-free normalized training steps.
    from src.data import plain_transform, normalize
    train_pixel = datasets.CIFAR10(root=root, train=True, download=False, transform=plain_transform())
    val_norm = datasets.CIFAR10(root=root, train=True, download=False, transform=normalized_transform())

    train_loader = DataLoader(Subset(train_aug, train_idx), batch_size=int(config["batch_size"]),
                              shuffle=True, num_workers=0)
    train_pixel_loader = DataLoader(Subset(train_pixel, train_idx), batch_size=int(config["batch_size"]),
                                    shuffle=True, num_workers=0)
    val_loader = DataLoader(Subset(val_norm, val_idx), batch_size=256, shuffle=False, num_workers=0)

    model = CompactCNN().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(config["learning_rate"]),
                                  weight_decay=float(config["weight_decay"]))
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    criterion = nn.CrossEntropyLoss()
    eps_adv = int(config["adversarial_training"]["epsilon_over_255"]) / 255.0 if adversarial else 0.0

    history = {"epoch": [], "train_loss": [], "train_accuracy": [], "validation_accuracy": []}
    best_val = -1.0
    start = time.time()
    for epoch in range(epochs):
        model.train()
        running_loss, correct, total = 0.0, 0, 0
        loader = train_pixel_loader if adversarial else train_loader
        for x, y in loader:
            y = y.to(device)
            if adversarial:
                x_pixel = x.to(device)
                adv = fgsm_attack(model, x_pixel, y, eps_adv, device)
                inputs = normalize(adv, device)
            else:
                inputs = x.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(inputs)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()
            running_loss += float(loss.item()) * len(y)
            correct += int((logits.argmax(1) == y).sum().item())
            total += len(y)
        scheduler.step()
        val_acc = evaluate_normalized(model, val_loader, device)
        history["epoch"].append(epoch + 1)
        history["train_loss"].append(running_loss / max(total, 1))
        history["train_accuracy"].append(correct / max(total, 1))
        history["validation_accuracy"].append(val_acc)
        print(f"epoch {epoch + 1}/{epochs} loss {history['train_loss'][-1]:.4f} "
              f"train_acc {history['train_accuracy'][-1]:.4f} val_acc {val_acc:.4f}", flush=True)
        if val_acc > best_val:
            best_val = val_acc
            out_checkpoint.parent.mkdir(parents=True, exist_ok=True)
            torch.save({
                "state_dict": model.state_dict(),
                "config": config,
                "adversarial_training": adversarial,
                "train_indices": train_idx,
                "validation_indices": val_idx,
                "best_validation_accuracy": best_val,
                "classes": CIFAR10_CLASSES,
            }, out_checkpoint)
    history_path.parent.mkdir(parents=True, exist_ok=True)
    history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
    return {
        "adversarial_training": adversarial,
        "device": str(device),
        "train_subset_size": len(train_idx),
        "validation_size": len(val_idx),
        "epochs": epochs,
        "batch_size": int(config["batch_size"]),
        "learning_rate": float(config["learning_rate"]),
        "weight_decay": float(config["weight_decay"]),
        "optimizer": "AdamW",
        "scheduler": "CosineAnnealingLR",
        "parameters": count_parameters(model),
        "best_validation_accuracy": best_val,
        "validation_source": "held out portion of the official CIFAR-10 training split",
        "training_seconds": round(time.time() - start, 1),
        "adversarial_epsilon_over_255": int(config["adversarial_training"]["epsilon_over_255"]) if adversarial else None,
        "history": history,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/experiment.json")
    parser.add_argument("--adversarial", action="store_true")
    parser.add_argument("--checkpoint", default="outputs/checkpoints/model.pt")
    parser.add_argument("--history", default="outputs/training_history.json")
    parser.add_argument("--subset-size", type=int, default=None)
    parser.add_argument("--epochs", type=int, default=None)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    if args.adversarial:
        subset = args.subset_size or int(config["adversarial_training"]["train_subset_size"])
        epochs = args.epochs or int(config["adversarial_training"]["epochs"])
    else:
        subset = args.subset_size or int(config["train_subset_size"])
        epochs = args.epochs or int(config["epochs"])
    info = train_one(config, args.adversarial, Path(args.checkpoint), Path(args.history), subset, epochs)
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
