"""Untargeted white-box FGSM and PGD attacks in pixel space.

Unit contract (important):
- Inputs to these functions are float tensors in pixel space, range [0, 1].
- epsilon and alpha are also in pixel space units. An epsilon written as
  8/255 in the experiment config is passed here as the float 8/255 = 0.03137.
- Normalization to the model input distribution happens inside the attack,
  after gradients are requested with respect to the pixel space tensor.
  Epsilon is therefore never applied to normalized tensors, which would
  silently change its meaning because each channel has a different std.
- Every returned example is clamped to [0, 1] and, for PGD, projected back
  into the L-infinity ball of radius epsilon around the original image.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F

from src.data import normalize


def _validate_inputs(images: torch.Tensor, epsilon: float) -> None:
    if epsilon < 0:
        raise ValueError("epsilon must be non-negative")
    if images.numel() and (float(images.min()) < -1e-6 or float(images.max()) > 1.0 + 1e-6):
        raise ValueError("images must be in pixel space range [0, 1]")


def fgsm_attack(model, images, labels, epsilon: float, device: torch.device):
    """One step untargeted FGSM. Returns adversarial images in [0, 1]."""
    _validate_inputs(images, epsilon)
    if epsilon == 0:
        return images.detach().clone()
    model.eval()
    x = images.detach().clone().to(device).requires_grad_(True)
    labels = labels.to(device)
    logits = model(normalize(x, device))
    loss = F.cross_entropy(logits, labels)
    model.zero_grad(set_to_none=True)
    loss.backward()
    if x.grad is None:
        raise RuntimeError("FGSM received no gradient with respect to the input")
    adv = x.detach() + epsilon * x.grad.sign()
    return adv.clamp(0.0, 1.0).detach()


def pgd_attack(model, images, labels, epsilon: float, alpha: float,
               steps: int, device: torch.device, random_start: bool = True,
               restarts: int = 1, generator: torch.Generator | None = None):
    """Multi step untargeted PGD with projection and optional restarts.

    For each restart the attack keeps the adversarial example with the
    highest cross entropy loss, which is the standard worst case selection
    for an untargeted attack. With restarts equal to 1 this is plain PGD.
    """
    _validate_inputs(images, epsilon)
    if alpha <= 0 and epsilon > 0:
        raise ValueError("alpha must be positive when epsilon is positive")
    if steps < 1:
        raise ValueError("steps must be at least 1")
    if restarts < 1:
        raise ValueError("restarts must be at least 1")
    if epsilon == 0:
        return images.detach().clone()
    model.eval()
    original = images.detach().clone().to(device)
    labels = labels.to(device)
    best_adv = original.clone()
    best_loss = torch.full((original.size(0),), -1e30, device=device)

    for _ in range(restarts):
        if random_start:
            noise = torch.empty_like(original).uniform_(-epsilon, epsilon, generator=generator)
            x = (original + noise).clamp(0.0, 1.0).detach()
        else:
            x = original.clone()
        for _step in range(steps):
            x = x.detach().requires_grad_(True)
            logits = model(normalize(x, device))
            loss = F.cross_entropy(logits, labels)
            model.zero_grad(set_to_none=True)
            loss.backward()
            if x.grad is None:
                raise RuntimeError("PGD received no gradient with respect to the input")
            with torch.no_grad():
                x = x.detach() + alpha * x.grad.sign()
                # Project onto the L-infinity ball around the original image.
                x = torch.max(torch.min(x, original + epsilon), original - epsilon)
                x = x.clamp(0.0, 1.0)
        with torch.no_grad():
            final_loss = F.cross_entropy(model(normalize(x, device)), labels, reduction="none")
            replace = final_loss > best_loss
            if bool(replace.any()):
                best_adv[replace] = x[replace]
                best_loss[replace] = final_loss[replace]
    return best_adv.detach()
