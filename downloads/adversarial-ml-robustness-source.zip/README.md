# Adversarial Machine Learning and Model Robustness

An independent research project for an academic portfolio (https://pcboss.me). A compact CNN is trained from scratch on CIFAR-10, then attacked with untargeted white-box FGSM and PGD at pixel space epsilons of 0/255, 2/255, 4/255, and 8/255. Clean accuracy, robust accuracy, and attack success rate are measured on one fixed held-out test subset. A small FGSM adversarial training experiment is included when the run completes it.

All numbers in this repository come from actual model predictions saved in `outputs/results.json`. No mocked values are reported as results.

## Important license and independence note

The reference repository https://github.com/poojakira/adversarial-ml-lab was inspected before this project was built. Its LICENSE file is a proprietary, all rights reserved, source visible license. It is not an MIT license, despite any assumption to the contrary. No code, experiments, reported figures, text, or figures were copied from that repository. The code here is an original implementation based on the standard published definitions of FGSM (Goodfellow et al., 2015) and PGD (Madry et al., 2018).

CIFAR-10 itself is provided by the University of Toronto at https://www.cs.toronto.edu/~kriz/cifar.html and is loaded through torchvision. Raw CIFAR-10 files are not included in the ZIP.

## Method summary

- Dataset: CIFAR-10 via `torchvision.datasets.CIFAR10`. Official training split (50,000) for development, official test split (10,000) for final evaluation only.
- Development protocol: stratified subset of the training split for training, plus a disjoint stratified validation subset from the same training split for checkpoint selection. Test labels were not used for fitting, tuning, or model selection.
- Model: compact CNN with three convolutional blocks and a small classifier head, trained from scratch. Exact counts, epochs, and device are recorded in `outputs/results.json`.
- Attacks: untargeted white-box FGSM and PGD in pixel space. Inputs to the attack functions are in [0, 1]. Epsilon is in the same pixel units, so 8/255 means 0.03137 per pixel at most. Normalization to model inputs happens inside the attack after gradients are taken with respect to pixel space tensors, so epsilon units are never silently changed. PGD uses a random start, projection into the L-infinity ball, clamping to [0, 1], configurable step size (epsilon divided by 4 in the reported run), 20 steps, and 1 restart.
- Evaluation: one fixed stratified test subset (1,000 images, 100 per class) for every comparison. Metrics are clean accuracy, robust accuracy per attack and epsilon, attack success rate among initially correct examples, and confusion matrices.
- Defense (optional, small): a second CNN trained with FGSM adversarial examples at 8/255, evaluated with identical settings. See `outputs/results.json` for whether it completed in the run that produced the current outputs, and do not read a robustness claim into it beyond the measured table.

## Repository layout

- `configs/experiment.json`: seed, subset sizes, epochs, epsilons, PGD settings.
- `src/model.py`: compact CNN.
- `src/data.py`: CIFAR-10 loading, stratified subsets, normalization helpers.
- `src/attacks.py`: FGSM and PGD with explicit pixel space unit contract.
- `src/metrics.py`: accuracy, attack success rate, confusion matrix.
- `src/train.py`: normal and adversarial training.
- `src/evaluate.py`: fixed subset evaluation.
- `src/visualize.py`: figures from `outputs/results.json` and saved examples.
- `run_experiment.py`: full pipeline in one command.
- `scripts/make_case_study.py`: builds `outputs/portfolio-case-study.md` from measured results.
- `scripts/make_zip.py`: builds the downloadable source ZIP with exclusions.
- `tests/test_all.py`: automated tests.
- `outputs/results.json`: measured results and full configuration record.
- `outputs/figures/`: generated charts.
- `outputs/checkpoints/`: trained weights (small, included when practical).

## Reproduction

Requires Python 3.11 or later and a CPU. A GPU is used automatically if available.

```bash
pip install -r requirements.txt
python run_experiment.py
python -m pytest tests -v
python -m src.visualize
python scripts/make_case_study.py
python scripts/make_zip.py
```

To skip the defense experiment:

```bash
python run_experiment.py --skip-defense
```

Individual stages:

```bash
python -m src.train --checkpoint outputs/checkpoints/model.pt --history outputs/training_history.json
python -m src.evaluate --checkpoint outputs/checkpoints/model.pt --label normal
```

Note: `src.train` and `src.evaluate` are run as modules from the repository root so that the `src` package imports resolve.

## Figures

1. `01_class_distribution.png`: CIFAR-10 class counts for both official splits.
2. `02_training_progress.png`: train and validation accuracy by epoch.
3. `03_clean_accuracy.png`: clean accuracy on the fixed test subset.
4. `04_fgsm_robustness.png`: FGSM robust accuracy across epsilons.
5. `05_pgd_robustness.png`: PGD robust accuracy across epsilons.
6. `06_clean_vs_adversarial.png`: clean versus FGSM and PGD at 8/255.
7. `07_adversarial_examples.png`: original, FGSM, and PGD examples side by side.
8. `08_perturbations_magnified.png`: absolute perturbations magnified 10 times, labelled as magnified in the figure.
9. `09_confusion_clean.png` and `10_confusion_pgd_8_255.png`: confusion matrices.

## Threat model and limits

White-box robustness to FGSM and PGD at these epsilons does not prove security against all adversaries. It does not cover black-box, query based, physical, poisoning, or adaptive attacks, other norms, or larger budgets. PGD robust accuracy here is an empirical estimate from a finite attack, so true robust accuracy under the same budget could be lower. Full discussion is in `outputs/portfolio-case-study.md`.

## Writing and reporting standards

No em dashes or en dashes are used in project documents. Accuracy values are reported only from `outputs/results.json`.
