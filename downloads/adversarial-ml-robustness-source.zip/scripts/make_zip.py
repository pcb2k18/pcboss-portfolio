"""Build the downloadable source ZIP, excluding data, caches, and venvs."""
from __future__ import annotations

import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "adversarial-ml-robustness-source.zip"
EXCLUDED_DIRS = {"data", ".venv", "venv", "__pycache__", ".pytest_cache", ".git"}
EXCLUDED_SUFFIXES = {".pyc"}


def included(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return False
    if path.suffix in EXCLUDED_SUFFIXES:
        return False
    if path == OUT:
        return False
    # Keep only the main checkpoints, skip any temporary checkpoint files.
    if "checkpoints" in rel.parts and "_tmp" in path.name:
        return False
    return True


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob("*")):
            if path.is_file() and included(path):
                archive.write(path, path.relative_to(ROOT))
                count += 1
    print(f"wrote {OUT} with {count} files, {OUT.stat().st_size / 1e6:.2f} MB")


if __name__ == "__main__":
    main()
