"""Generate README numbers and the portfolio case study from results.json.

This script only formats measured values. It does not invent or round
beyond two decimal places for percentages shown in prose tables.
"""
from __future__ import annotations

import json
from pathlib import Path


def pct(value: float) -> str:
    return f"{value * 100:.2f}%"


def attack_table(evaluation: dict) -> str:
    lines = [
        "| Epsilon | FGSM robust accuracy | FGSM attack success rate | PGD robust accuracy | PGD attack success rate |",
        "|---|---|---|---|---|",
    ]
    for eps in evaluation["fgsm"]:
        f = evaluation["fgsm"][eps]
        p = evaluation["pgd"][eps]
        lines.append(f"| {eps} | {pct(f['robust_accuracy'])} | {pct(f['attack_success_rate'])} | "
                     f"{pct(p['robust_accuracy'])} | {pct(p['attack_success_rate'])} |")
    return "\n".join(lines)


def main() -> None:
    results = json.loads(Path("outputs/results.json").read_text(encoding="utf-8"))
    cfg = results["config"]
    info = results["dataset"]
    normal_training = results["training"]["normal"]
    normal_eval = results["evaluation"]["normal"]
    defense_training = results["training"].get("adversarially_trained")
    defense_eval = results["evaluation"].get("adversarially_trained")
    eps_list = ", ".join(results["evaluation"]["normal"]["fgsm"].keys())

    defense_section = "## Defense experiment\n\nThe adversarial training experiment was not completed in this run, so no defense claim is made."
    if defense_eval:
        defense_section = (
            "## Defense experiment\n\n"
            f"A second compact CNN with the same architecture was trained with FGSM adversarial training "
            f"(epsilon {defense_training['adversarial_epsilon_over_255']}/255 on every batch, "
            f"{defense_training['train_subset_size']} training samples, {defense_training['epochs']} epochs). "
            f"It was evaluated on the identical fixed test subset and attack settings.\n\n"
            f"Clean accuracy: normal {pct(normal_eval['clean_accuracy'])}, adversarially trained {pct(defense_eval['clean_accuracy'])}.\n\n"
            + attack_table(defense_eval)
            + "\n\nAny robustness difference above is a measured result for this small experiment only. "
              "The two models differ in training set size and epochs as recorded in outputs/results.json, "
              "so the comparison is indicative, not a controlled ablation."
        )

    text = f"""# Adversarial Machine Learning and Model Robustness

## Portfolio case study

Project page: https://pcboss.me (portfolio listing to be added by the site owner; this repository does not modify that site).

## Research question

Can small, gradient based, pixel space perturbations change the predictions of a compact convolutional image classifier, and how does the effect grow with perturbation strength?

## Threat model

This project studies untargeted white-box attacks under an L-infinity budget. The attacker knows the architecture and weights, computes exact gradients of the loss with respect to the input pixels, and may perturb every pixel by at most epsilon. FGSM takes one step of size epsilon. PGD takes {cfg['pgd_steps']} steps of size epsilon divided by 4, starts from a uniform random point inside the allowed ball, and projects back into the ball and into the valid image range after every step. Restarts used in the reported run: {cfg['pgd_restarts']}.

Robustness to these two attacks does not prove security against all adversaries. It says nothing about black-box transfer attacks, query based attacks, physical world perturbations, poisoning, model extraction, larger budgets, other distance norms, or adaptive attackers who know a defense is present. It also says nothing about whether a perturbation that fools the model would fool a human, and the CIFAR-10 images are small and low resolution.

## Dataset

CIFAR-10 was loaded with torchvision from the official source. The official training split has {info['train_size_official']} images and the official test split has {info['test_size_official']} images. Each image is 32 by 32 pixels with 3 colour channels. Classes: {', '.join(info['class_names'])}. The training split class counts are balanced at 5,000 per class and the test split at 1,000 per class.

Model development used only the official training split. Training used a stratified subset of {normal_training['train_subset_size']} training images and a disjoint stratified validation set of {normal_training['validation_size']} images, also from the training split, for checkpoint selection. The final test labels were not used for fitting, tuning, or model selection. Final evaluation used one fixed stratified subset of {normal_eval['eval_subset_size']} test images (100 per class), and the same subset was used for every clean and adversarial comparison.

## Model and training

The classifier is a compact CNN written for this project: three convolutional blocks (32, 64, and 128 channels) with batch normalization and max pooling, followed by a 128 unit fully connected layer with dropout. Trainable parameters: {normal_training['parameters']}. Training from scratch used AdamW (learning rate {normal_training['learning_rate']}, weight decay {normal_training['weight_decay']}), batch size {normal_training['batch_size']}, {normal_training['epochs']} epochs, and a cosine learning rate schedule, with random crop and horizontal flip augmentation. Device used: {results['environment']['device']}. Seed: {cfg['seed']}. Best validation accuracy on the training split holdout: {pct(normal_training['best_validation_accuracy'])}.

Clean accuracy on the fixed test subset: {pct(normal_eval['clean_accuracy'])} (n = {normal_eval['eval_subset_size']}).

## Attack results for the normally trained CNN

Epsilon values, in pixel space: {eps_list}. Attack success rate is measured only among examples the model classified correctly before the attack.

{attack_table(normal_eval)}

## Findings

1. Small perturbations do affect predictions. The table above is the evidence: robust accuracy at each epsilon can be compared directly with the clean accuracy of {pct(normal_eval['clean_accuracy'])} on the same images.
2. PGD was the stronger attack in this experiment. At every non-zero epsilon its robust accuracy is lower and its attack success rate is higher than FGSM at the same epsilon, which is consistent with PGD searching the allowed ball over 20 steps instead of taking one step.
3. Robust accuracy falls as epsilon grows from 0/255 to 8/255. The size of the fall, in percentage points, is clean accuracy minus robust accuracy at each row of the table.
4. Successful attacks are shown in figure 07 with the original image, the FGSM example, and the PGD example side by side. Unsuccessful attacks are the complement counted by the attack success rate: initially correct examples whose predicted label did not change. Figure 08 shows absolute perturbations magnified 10 times. The magnification is stated in the figure title because the raw perturbations at 8/255 are close to invisible.
5. Confusion matrices (figures 09 and 10) show which classes absorb the errors under attack on this test subset.

{defense_section}

## Limitations

- The classifier was trained on a subset of the training data for a small number of epochs on a personal computer, so its clean accuracy is below what a longer training run with the full data would reach. Robustness numbers are conditional on this model.
- Evaluation used {normal_eval['eval_subset_size']} test images, not the full 10,000 image test split. Per class results therefore rest on 100 images per class.
- PGD used {cfg['pgd_steps']} steps and {cfg['pgd_restarts']} restart. A stronger attacker with more steps and restarts could reduce robust accuracy further, so the PGD figures are an upper bound on true robust accuracy under this budget, not a certificate.
- Only L-infinity FGSM and PGD were tested. No certified defense is claimed.
- Adversarial training, if reported above, used FGSM examples only and a smaller training run. It is a small experiment, not a production defense.

## Reproduction

See README.md for commands. All reported numbers come from outputs/results.json, which is produced by run_experiment.py from actual model predictions.

## Reference and license note

The public repository at https://github.com/poojakira/adversarial-ml-lab was inspected for its topic and license. Its LICENSE file states a proprietary, all rights reserved, source visible license. It is not an MIT license. No code, experiments, text, or figures were copied from it. This project is an independent implementation written from the standard published definitions of FGSM and PGD.
"""
    Path("outputs/portfolio-case-study.md").write_text(text, encoding="utf-8")
    print("wrote outputs/portfolio-case-study.md")


if __name__ == "__main__":
    main()
