"""Parallel range download of the official CIFAR-10 tar file.

The file is the official archive from the University of Toronto site that
torchvision itself downloads. This script only speeds up the transfer with
parallel HTTP range requests. It verifies the MD5 that torchvision checks
(c58f30108f718f92721af3b95e74349a) before keeping the file, and falls back
to a plain single stream download if ranges are not supported.
"""
import concurrent.futures
import hashlib
import urllib.request
from pathlib import Path

URL = "https://cave.cs.toronto.edu/kriz/cifar-10-python.tar.gz"
EXPECTED_MD5 = "c58f30108f718f92721af3b95e74349a"
OUT = Path("data/cifar-10-python.tar.gz")
CHUNKS = 8


def fetch_range(args):
    start, end, index = args
    existing = OUT.with_suffix(f".part{index}")
    if existing.exists() and existing.stat().st_size == end - start + 1:
        print(f"chunk {index} already present, skipping", flush=True)
        return existing
    last_error = None
    for attempt in range(5):
        try:
            req = urllib.request.Request(URL, headers={"Range": f"bytes={start}-{end}"})
            with urllib.request.urlopen(req, timeout=180) as resp:
                data = resp.read()
            if len(data) != end - start + 1:
                raise IOError(f"chunk {index} got {len(data)} of {end - start + 1} bytes")
            part = OUT.with_suffix(f".part{index}")
            part.write_bytes(data)
            print(f"chunk {index} done {len(data)} bytes on attempt {attempt + 1}", flush=True)
            return part
        except Exception as exc:
            last_error = exc
            print(f"chunk {index} attempt {attempt + 1} failed: {exc}", flush=True)
    raise RuntimeError(f"chunk {index} failed after retries") from last_error


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(URL, method="HEAD")
    with urllib.request.urlopen(req, timeout=60) as resp:
        total = int(resp.headers["Content-Length"])
        ranges = resp.headers.get("Accept-Ranges", "none")
    print(f"size {total} accept-ranges {ranges}", flush=True)
    if ranges == "bytes":
        size = total // CHUNKS
        jobs = []
        for i in range(CHUNKS):
            start = i * size
            end = total - 1 if i == CHUNKS - 1 else (i + 1) * size - 1
            jobs.append((start, end, i))
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            parts = list(pool.map(fetch_range, jobs))
        with OUT.open("wb") as fh:
            for i in range(CHUNKS):
                fh.write(OUT.with_suffix(f".part{i}").read_bytes())
        for p in parts:
            p.unlink()
    else:
        print("ranges not supported, single stream download", flush=True)
        urllib.request.urlretrieve(URL, OUT)
    digest = hashlib.md5(OUT.read_bytes()).hexdigest()
    print(f"md5 {digest} expected {EXPECTED_MD5} match {digest == EXPECTED_MD5}", flush=True)
    if digest != EXPECTED_MD5:
        raise SystemExit("MD5 mismatch, refusing to keep file")


if __name__ == "__main__":
    main()
