"""One command reproduction of the full experiment.

Steps: verify dataset, train normal CNN, evaluate it, optionally train and
evaluate an adversarially trained CNN, merge everything into
outputs/results.json, then draw figures from that file.

Usage:
    python run_experiment.py
    python run_experiment.py --skip-defense
"""
from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path

import torch

from src.data import dataset_info, load_cifar10, set_seed
from src.evaluate import evaluate_model, load_model
from src.train import train_one


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/experiment.json")
    parser.add_argument("--skip-defense", action="store_true")
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    set_seed(int(config["seed"]))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device: {device} python: {platform.python_version()} torch: {torch.__version__}", flush=True)

    train_full, test_full = load_cifar10(config["data_root"])
    info = dataset_info(train_full, test_full)
    print(json.dumps({k: info[k] for k in ("train_size_official", "test_size_official", "image_shape_chw_after_totensor")}, indent=2), flush=True)

    out = Path("outputs")
    (out / "checkpoints").mkdir(parents=True, exist_ok=True)

    normal_info = train_one(config, adversarial=False,
                            out_checkpoint=out / "checkpoints" / "model.pt",
                            history_path=out / "training_history.json",
                            subset_size=int(config["train_subset_size"]),
                            epochs=int(config["epochs"]))
    model, _ = load_model(out / "checkpoints" / "model.pt", device)
    normal_eval = evaluate_model(model, "normal", config, device, out / "examples.npz")
    (out / "evaluation_normal.json").write_text(json.dumps(normal_eval, indent=2), encoding="utf-8")

    defense_info, defense_eval = None, None
    defense_cfg = config.get("adversarial_training", {})
    if not args.skip_defense and defense_cfg.get("performed_if_time", False):
        try:
            defense_info = train_one(config, adversarial=True,
                                     out_checkpoint=out / "checkpoints" / "model_adversarial.pt",
                                     history_path=out / "training_history_adversarial.json",
                                     subset_size=int(defense_cfg["train_subset_size"]),
                                     epochs=int(defense_cfg["epochs"]))
            adv_model, _ = load_model(out / "checkpoints" / "model_adversarial.pt", device)
            defense_eval = evaluate_model(adv_model, "adversarially_trained", config, device, None)
            (out / "evaluation_adversarial.json").write_text(json.dumps(defense_eval, indent=2), encoding="utf-8")
        except Exception as exc:  # Report honestly rather than claiming a defense result.
            defense_info = {"performed": False, "error": f"{type(exc).__name__}: {exc}"}
            print(f"defense experiment failed and is reported as not completed: {exc}", flush=True)

    results = {
        "project": "Adversarial Machine Learning and Model Robustness",
        "independent_implementation_note": "All code in this repository was written for this project. The reference repository was inspected only at the level of its public description and license file. Its license is proprietary (all rights reserved, source visible, not open source) and is not an MIT license, so no code, experiments, or figures were copied from it.",
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "torch": torch.__version__,
            "device": str(device),
            "cuda_available": torch.cuda.is_available(),
        },
        "config": config,
        "dataset": info,
        "training": {"normal": normal_info, "adversarially_trained": defense_info},
        "evaluation": {"normal": normal_eval, "adversarially_trained": defense_eval},
        "threat_model": "Untargeted white-box L-infinity attacks. The attacker knows the model weights and architecture and can compute exact input gradients. FGSM uses one gradient step. PGD uses iterated gradient steps with projection and a random start.",
    }
    (out / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print("wrote outputs/results.json", flush=True)


if __name__ == "__main__":
    sys.exit(main())
