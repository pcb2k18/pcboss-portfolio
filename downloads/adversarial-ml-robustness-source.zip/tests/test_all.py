"""Automated tests. Run with: python -m pytest tests -v"""
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.attacks import fgsm_attack, pgd_attack
from src.data import make_eval_indices, make_train_validation_indices
from src.metrics import accuracy, attack_success_rate, confusion_matrix_np
from src.model import CompactCNN

DEVICE = torch.device("cpu")


def tiny_model_and_data():
    torch.manual_seed(0)
    model = CompactCNN()
    model.eval()
    images = torch.rand(4, 3, 32, 32)
    labels = torch.tensor([0, 3, 5, 9])
    return model, images, labels


def test_model_prediction_dimensions():
    model, images, _labels = tiny_model_and_data()
    with torch.no_grad():
        logits = model(torch.randn(2, 3, 32, 32))
    assert logits.shape == (2, 10)
    assert model(images).shape == (4, 10)


def test_input_range_validation():
    model, _images, labels = tiny_model_and_data()
    bad = torch.full((2, 3, 32, 32), 1.5)
    try:
        fgsm_attack(model, bad, labels[:2], 0.03, DEVICE)
        raised = False
    except ValueError:
        raised = True
    assert raised


def test_fgsm_epsilon_zero_and_bounds():
    model, images, labels = tiny_model_and_data()
    adv0 = fgsm_attack(model, images, labels, 0.0, DEVICE)
    assert torch.allclose(adv0, images)
    for eps in (2 / 255, 8 / 255):
        adv = fgsm_attack(model, images, labels, eps, DEVICE)
        assert float(adv.min()) >= 0.0 and float(adv.max()) <= 1.0
        assert float((adv - images).abs().max()) <= eps + 1e-6


def test_fgsm_negative_epsilon_rejected():
    model, images, labels = tiny_model_and_data()
    try:
        fgsm_attack(model, images, labels, -0.01, DEVICE)
        raised = False
    except ValueError:
        raised = True
    assert raised


def test_pgd_projection_constraints():
    model, images, labels = tiny_model_and_data()
    eps = 8 / 255
    adv = pgd_attack(model, images, labels, eps, eps / 4, steps=5, device=DEVICE,
                     random_start=True, restarts=1)
    assert float(adv.min()) >= 0.0 and float(adv.max()) <= 1.0
    assert float((adv - images).abs().max()) <= eps + 1e-6


def test_attack_gradient_handling():
    # FGSM on a model whose loss depends on the input must move at least
    # one pixel for a non-zero epsilon, proving gradients reached the input.
    model, images, labels = tiny_model_and_data()
    adv = fgsm_attack(model, images, labels, 8 / 255, DEVICE)
    assert float((adv - images).abs().sum()) > 0.0


def test_dataset_split_separation():
    labels = [c for c in range(10) for _ in range(100)]
    train_idx, val_idx = make_train_validation_indices(labels, 500, 200, seed=42)
    assert set(train_idx).isdisjoint(val_idx)
    assert len(train_idx) == 500 and len(val_idx) == 200
    eval_idx = make_eval_indices(labels, 100, seed=42)
    assert len(eval_idx) == 100 and len(set(eval_idx)) == 100


def test_metric_calculations():
    labels = np.array([0, 1, 2, 3])
    clean = np.array([0, 1, 2, 0])
    adv = np.array([1, 1, 0, 0])
    assert accuracy(clean, labels) == 0.75
    # Initially correct are indices 0,1,2. Attack flips 0 and 2, so 2/3.
    assert abs(attack_success_rate(clean, adv, labels) - (2 / 3)) < 1e-9
    matrix = confusion_matrix_np(clean, labels)
    assert matrix.sum() == 4 and matrix[0, 0] == 1 and matrix[3, 0] == 1


def test_reproducible_evaluation_indices():
    labels = [c for c in range(10) for _ in range(50)]
    first = make_eval_indices(labels, 100, seed=123)
    second = make_eval_indices(labels, 100, seed=123)
    assert first == second
