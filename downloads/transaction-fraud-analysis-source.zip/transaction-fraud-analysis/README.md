# Machine Learning for Transaction Fraud Analysis

An independent, reproducible baseline study of payment fraud classification,
built for a PhD academic portfolio. The project audits the dataset before
modelling, checks for target leakage and duplicate contamination, compares
three classifiers, and reports only results that survive those checks.

The headline finding is not a high score. The dataset used by the reference
project contains two columns that separate fraud from legitimate rows
perfectly by construction. Tree models that appear to score 100 percent on
this file are reading those columns, not detecting fraud. After the
artefactual columns are removed and duplicate rows are dropped, no model
performs usefully. That corrected result is the result reported here.

## Dataset

- Source: Kaggle, Payment Fraud - Empowering Financial Security, by Younus Mohamed
- Page: https://www.kaggle.com/datasets/younusmohamed/payment-fraud-empowering-financial-security
- File: `payment_fraud.csv`
- Verified: 39,221 rows, 8 columns (7 predictors and the binary `label` target)
- Class distribution: 38,661 legitimate (98.57 percent) and 560 fraud (1.43 percent)
- Licence: the Kaggle page sidebar lists CC BY-NC-SA 4.0 and the README inside
  the download lists CC BY-SA 4.0. This project follows the more restrictive
  terms. The raw CSV is not included in this repository or in the source ZIP.
- The Kaggle dataset card states 38,662 rows. The downloaded CSV contains
  39,221 rows. The CSV count is used throughout.
- The uploader does not document the data as synthetic. Internal evidence
  suggests artificial generation or augmentation: fraud rows follow exact
  rules, `localTime` takes only 25 distinct values, and 3,033 rows are exact
  duplicates. The data should not be described as real transactions.

The reference repository at
https://github.com/PialGhosh2233/payment-fraud-detection pointed to this
dataset. That repository has no licence file, so none of its code was copied.
This implementation was written from scratch.

## Leakage findings

- `accountAgeDays` equals 1 for all 560 fraud rows. The minimum for
  legitimate rows is 2. One split on this column separates the classes perfectly.
- `isWeekend` is missing for all 560 fraud rows and for no legitimate row.
  Its missingness alone encodes the target.
- 3,033 rows are exact duplicates beyond the first copy, including 164
  duplicated fraud rows. A random split can place copies in both train and
  test sets.
- `paymentMethodAgeDays` is below 1 day for every fraud row but also for many
  legitimate rows. It is kept in the corrected run and removed in a
  sensitivity run.

## Method

- Stratified 80/20 train and test split, random state 42.
- Imputation, one-hot encoding, and scaling are fitted inside scikit-learn
  pipelines on training data only.
- Models: logistic regression, decision tree, and random forest, each with
  `class_weight` set to balanced. Threshold is the default 0.5.
- Three runs are reported in `outputs/results.json`:
  - As-found: all seven predictors, no deduplication. Diagnostic only.
  - Corrected: `accountAgeDays` and `isWeekend` removed, exact duplicates
    dropped before the split. This is the defensible result.
  - Sensitivity: `paymentMethodAgeDays` also removed.

## Corrected results (test set, 7,238 rows, 79 fraud)

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC |
|---|---|---|---|---|---|---|
| Logistic Regression | 0.6169 | 0.0220 | 0.7848 | 0.0428 | 0.8058 | 0.0740 |
| Decision Tree | 0.8962 | 0.0130 | 0.1139 | 0.0234 | 0.4704 | 0.0271 |
| Random Forest | 0.9436 | 0.0030 | 0.0127 | 0.0049 | 0.5216 | 0.0104 |

In the as-found run, the decision tree and random forest both score 1.0000
on every metric. Those figures are an artefact of the leakage columns and
should not be quoted as fraud detection performance. Full results for all
three runs, including confusion matrices, are in `outputs/results.json`.
The written case study is in `outputs/portfolio-case-study.md`.

## Figures

All figures are in `outputs/figures/`:

- `01_class_distribution.png`: fraud versus legitimate transactions
- `02_leakage_diagnostic.png`: account age and weekend flag missingness by class
- `03_transaction_patterns.png`: transaction time, payment method age, and
  fraud rates by payment method and category
- `04_model_comparison_corrected.png`: F1, ROC-AUC, and PR-AUC by model
- `05_feature_importance.png`: random forest importance, corrected run
- `06_confusion_matrices.png`: confusion matrices, corrected run
- `07_roc_pr_curves.png`: ROC and precision-recall curves, corrected run

## Reproduction

```bash
pip install -r requirements.txt
python -m src.download_data
python -m src.fraud_analysis
python -m pytest tests/ -q
```

`src/download_data.py` downloads the dataset from Kaggle without
credentials. If Kaggle requires a login in future, download
`payment_fraud.csv` manually and place it in `data/raw/`. See
`data/README.md`.

## Limitations

- Fraud rows follow exact generation rules, so scores do not transfer to
  real payment systems.
- Dataset provenance, row count, and licence statements are inconsistent.
- There is no transaction amount, account history, or time ordering, so no
  temporal validation was possible.
- A single stratified split was used, with no hyperparameter tuning.
- Read this project as a leakage and data quality study with baseline
  models, not as a deployable fraud detector.

## Project structure

```text
src/fraud_analysis.py    Pipeline: audit, modelling, metrics, figures, case study
src/download_data.py     Kaggle download helper
tests/test_pipeline.py   Automated tests using a synthetic fixture
data/README.md           Dataset download instructions
outputs/results.json     Machine readable results
outputs/portfolio-case-study.md
outputs/figures/         Charts listed above
```

## Licensing

The original source code in this project is licensed under the MIT License. Third-party datasets, libraries, models, and other externally sourced materials remain subject to their respective licenses.

See the [LICENSE](LICENSE) file for the full license text.
