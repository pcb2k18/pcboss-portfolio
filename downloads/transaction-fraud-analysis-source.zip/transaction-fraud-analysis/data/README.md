# Data

The raw dataset is not included in this repository or in the source ZIP.

## Download

Run:

```bash
python -m src.download_data
```

This downloads `payment_fraud.csv` from the public Kaggle dataset below and
places it in `data/raw/payment_fraud.csv`.

- Dataset: Payment Fraud - Empowering Financial Security, by Younus Mohamed
- Page: https://www.kaggle.com/datasets/younusmohamed/payment-fraud-empowering-financial-security
- Licence: the Kaggle page sidebar lists CC BY-NC-SA 4.0. The README inside
  the download lists CC BY-SA 4.0. Follow the more restrictive terms.
- Verified file: 39,221 rows and 8 columns. The dataset card states 38,662
  rows, which does not match the CSV.

If the download endpoint requires a Kaggle login in future, download the
file manually from the dataset page and place it in `data/raw/`.

## Expected columns

`accountAgeDays`, `numItems`, `localTime`, `paymentMethod`,
`paymentMethodAgeDays`, `Category`, `isWeekend`, `label`

`label` is the target: 1 means fraud, 0 means legitimate.
