"""Download the Kaggle payment fraud file used by this project.

The dataset is public on Kaggle and the download endpoint below works
without credentials at the time of writing. If Kaggle requires a login in
future, download payment_fraud.csv manually from the dataset page and place
it in data/raw/.

Dataset page:
https://www.kaggle.com/datasets/younusmohamed/payment-fraud-empowering-financial-security

Licence note: the Kaggle page sidebar lists CC BY-NC-SA 4.0 and the README
inside the download lists CC BY-SA 4.0. Follow the more restrictive terms.
Do not redistribute the raw CSV in this repository or in the source ZIP.
"""

from __future__ import annotations

import io
import urllib.request
import zipfile
from pathlib import Path

URL = (
    "https://www.kaggle.com/api/v1/datasets/download/"
    "younusmohamed/payment-fraud-empowering-financial-security"
)
TARGET = Path("data/raw/payment_fraud.csv")


def main() -> None:
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0"})
    print(f"Downloading from {URL}")
    with urllib.request.urlopen(request, timeout=120) as response:
        payload = response.read()
    print(f"Downloaded {len(payload):,} bytes")
    archive = zipfile.ZipFile(io.BytesIO(payload))
    names = archive.namelist()
    print(f"Archive contents: {names}")
    csv_names = [n for n in names if n.endswith("payment_fraud.csv")]
    if not csv_names:
        raise RuntimeError(f"payment_fraud.csv not found in archive: {names}")
    TARGET.write_bytes(archive.read(csv_names[0]))
    lines = TARGET.read_text(encoding="utf-8", errors="ignore").count("\n")
    print(f"Wrote {TARGET} with approximately {lines:,} lines including the header")


if __name__ == "__main__":
    main()
