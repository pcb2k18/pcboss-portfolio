"""Independent machine learning pipeline for transaction fraud analysis.

This code was written from scratch for a PhD portfolio project. It does not
copy code from the reference repository. It audits the Kaggle payment fraud
file used by that repository, checks for target leakage and duplicate
contamination, and compares three classifiers under two conditions:

1. As-found: all supplied predictors are used. This is a diagnostic run.
2. Corrected: two predictors with perfect, artefactual separation are
   removed and exact duplicate rows are dropped before the split.

Only the corrected run is presented as the defensible result. The as-found
run is kept to show why perfect tree scores in the source notebook should
not be reported as real fraud detection performance.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
    precision_recall_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

RANDOM_STATE = 42
TARGET = "label"
EXPECTED_COLUMNS = [
    "accountAgeDays",
    "numItems",
    "localTime",
    "paymentMethod",
    "paymentMethodAgeDays",
    "Category",
    "isWeekend",
    "label",
]
ALL_FEATURES = [c for c in EXPECTED_COLUMNS if c != TARGET]
LEAKAGE_FEATURES = ["accountAgeDays", "isWeekend"]
CORRECTED_FEATURES = [c for c in ALL_FEATURES if c not in LEAKAGE_FEATURES]
SENSITIVITY_FEATURES = [c for c in CORRECTED_FEATURES if c != "paymentMethodAgeDays"]

DATASET_SOURCE = "https://www.kaggle.com/datasets/younusmohamed/payment-fraud-empowering-financial-security"
REFERENCE_REPO = "https://github.com/PialGhosh2233/payment-fraud-detection"


def load_data(path: str | Path) -> pd.DataFrame:
    """Load and validate the raw CSV."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Run: python -m src.download_data"
        )
    df = pd.read_csv(path)
    missing = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")
    df = df[EXPECTED_COLUMNS].copy()
    if not set(df[TARGET].dropna().unique()).issubset({0, 1}):
        raise ValueError("Target column 'label' must contain only 0 and 1.")
    if df[TARGET].isna().any():
        raise ValueError("Target column 'label' contains missing values.")
    return df


def _none_if_nan(value) -> float | None:
    value = float(value)
    return None if np.isnan(value) else value


def _is_perfect_numeric_separator(df: pd.DataFrame, col: str) -> bool:
    """Return True when the fraud and legitimate ranges do not overlap."""
    fraud = df.loc[df[TARGET] == 1, col].dropna()
    legit = df.loc[df[TARGET] == 0, col].dropna()
    if fraud.empty or legit.empty:
        return False
    return bool(fraud.max() < legit.min() or legit.max() < fraud.min())


def audit_data(df: pd.DataFrame) -> dict:
    """Return data quality, duplicate, and leakage audit results."""
    fraud_n = int((df[TARGET] == 1).sum())
    legit_n = int((df[TARGET] == 0).sum())

    missing_by_label = {}
    for col in ALL_FEATURES:
        missing_by_label[col] = {
            "legitimate_missing": int(df.loc[df[TARGET] == 0, col].isna().sum()),
            "fraud_missing": int(df.loc[df[TARGET] == 1, col].isna().sum()),
            "fraud_missing_rate": float(df.loc[df[TARGET] == 1, col].isna().mean()),
            "legitimate_missing_rate": float(df.loc[df[TARGET] == 0, col].isna().mean()),
        }

    account_age_one = pd.crosstab(df["accountAgeDays"] == 1, df[TARGET]).to_dict()
    weekend_missing = pd.crosstab(df["isWeekend"].isna(), df[TARGET]).to_dict()

    numeric_separators = [
        col
        for col in df[ALL_FEATURES].select_dtypes(include=[np.number]).columns
        if _is_perfect_numeric_separator(df, col)
    ]

    audit = {
        "records": int(len(df)),
        "columns": list(df.columns),
        "class_distribution": {
            "legitimate_0": legit_n,
            "fraud_1": fraud_n,
            "fraud_rate": float(df[TARGET].mean()),
            "legitimate_rate": float(1 - df[TARGET].mean()),
        },
        "missing_values": {c: int(v) for c, v in df.isna().sum().items()},
        "missing_by_label": missing_by_label,
        "exact_duplicate_rows_extra_copies": int(df.duplicated().sum()),
        "unique_rows": int(len(df.drop_duplicates())),
        "duplicate_rows_excluding_label_extra_copies": int(
            df.duplicated(subset=ALL_FEATURES).sum()
        ),
        "numeric_ranges_by_label": {
            col: {
                "fraud_min": _none_if_nan(df.loc[df[TARGET] == 1, col].min()),
                "fraud_max": _none_if_nan(df.loc[df[TARGET] == 1, col].max()),
                "legitimate_min": _none_if_nan(df.loc[df[TARGET] == 0, col].min()),
                "legitimate_max": _none_if_nan(df.loc[df[TARGET] == 0, col].max()),
            }
            for col in df[ALL_FEATURES].select_dtypes(include=[np.number]).columns
        },
        "perfect_numeric_separators": numeric_separators,
        "account_age_days_equals_1_by_label": {
            str(k): {str(kk): int(vv) for kk, vv in v.items()}
            for k, v in account_age_one.items()
        },
        "is_weekend_missing_by_label": {
            str(k): {str(kk): int(vv) for kk, vv in v.items()}
            for k, v in weekend_missing.items()
        },
        "unique_values": {c: int(df[c].nunique(dropna=True)) for c in ALL_FEATURES},
    }
    return audit


def leakage_findings(audit: dict) -> list[str]:
    findings = []
    fraud_missing_weekend = audit["missing_by_label"]["isWeekend"]["fraud_missing_rate"]
    legit_missing_weekend = audit["missing_by_label"]["isWeekend"]["legitimate_missing_rate"]
    if fraud_missing_weekend == 1.0 and legit_missing_weekend == 0.0:
        findings.append(
            "isWeekend is missing for every fraud row and for no legitimate row. "
            "Its missingness indicator alone perfectly encodes the target."
        )
    age = audit["numeric_ranges_by_label"]["accountAgeDays"]
    if age["fraud_min"] == age["fraud_max"] == 1.0 and age["legitimate_min"] >= 2.0:
        findings.append(
            "accountAgeDays equals 1 for every fraud row, while the minimum for "
            "legitimate rows is 2. A single split on this column separates the classes perfectly."
        )
    if audit["exact_duplicate_rows_extra_copies"] > 0:
        findings.append(
            f"The file contains {audit['exact_duplicate_rows_extra_copies']} exact duplicate "
            "rows beyond the first copy. A random split can place copies of the same row in "
            "both train and test sets, so duplicates are dropped before splitting in the corrected run."
        )
    findings.append(
        "paymentMethodAgeDays is below 1 day for every fraud row but also for many legitimate "
        "rows. It is a strong signal in this file, but it may also be part of how the fraud "
        "rows were generated. A sensitivity run without it is therefore reported."
    )
    return findings


def build_pipeline(model_name: str, numeric: list[str], categorical: list[str]) -> Pipeline:
    """Build a preprocessing and modelling pipeline.

    All imputation, encoding, and scaling are fitted inside the pipeline on
    training data only. This avoids the train and test contamination caused
    by fitting a scaler on the full dataset before splitting.
    """
    numeric_pipe = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_pipe = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )
    preprocessor = ColumnTransformer(
        [
            ("num", numeric_pipe, numeric),
            ("cat", categorical_pipe, categorical),
        ]
    )
    models = {
        "logistic_regression": LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE
        ),
        "decision_tree": DecisionTreeClassifier(
            random_state=RANDOM_STATE, class_weight="balanced"
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=300,
            random_state=RANDOM_STATE,
            n_jobs=-1,
            class_weight="balanced",
        ),
    }
    if model_name not in models:
        raise ValueError(f"Unknown model: {model_name}")
    return Pipeline([("preprocessor", preprocessor), ("classifier", models[model_name])])


def _metrics(y_true, y_pred, y_prob) -> dict:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, y_prob)),
        "pr_auc": float(average_precision_score(y_true, y_prob)),
        "confusion_matrix": {
            "tn": int(tn),
            "fp": int(fp),
            "fn": int(fn),
            "tp": int(tp),
        },
        "test_support_fraud": int((y_true == 1).sum()),
        "test_support_legitimate": int((y_true == 0).sum()),
    }


def evaluate_scenario(
    df: pd.DataFrame,
    features: list[str],
    drop_exact_duplicates: bool,
) -> tuple[dict, dict]:
    """Train the three models for one feature scenario.

    Returns metrics and fitted artefacts needed for plotting.
    """
    work = df.drop_duplicates().copy() if drop_exact_duplicates else df.copy()
    X = work[features]
    y = work[TARGET].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )
    numeric = [c for c in features if pd.api.types.is_numeric_dtype(work[c])]
    categorical = [c for c in features if c not in numeric]

    results: dict = {}
    artefacts: dict = {}
    for name in ["logistic_regression", "decision_tree", "random_forest"]:
        pipe = build_pipeline(name, numeric, categorical)
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        prob = pipe.predict_proba(X_test)[:, 1]
        results[name] = _metrics(y_test, pred, prob)
        artefacts[name] = {
            "pipeline": pipe,
            "y_test": np.asarray(y_test),
            "pred": np.asarray(pred),
            "prob": np.asarray(prob),
            "numeric": numeric,
            "categorical": categorical,
        }
    scenario_info = {
        "features": features,
        "drop_exact_duplicates_before_split": bool(drop_exact_duplicates),
        "rows_modelled": int(len(work)),
        "fraud_rows_modelled": int((work[TARGET] == 1).sum()),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "models": results,
    }
    return scenario_info, artefacts


def _feature_importance(artefacts: dict) -> list[dict]:
    entry = artefacts.get("random_forest")
    if entry is None:
        return []
    pipe = entry["pipeline"]
    pre = pipe.named_steps["preprocessor"]
    clf = pipe.named_steps["classifier"]
    names: list[str] = []
    for trans_name, _trans, cols in pre.transformers_:
        if trans_name == "num":
            names.extend(list(cols))
        elif trans_name == "cat":
            encoder = pipe.named_steps["preprocessor"].named_transformers_["cat"].named_steps["onehot"]
            names.extend(list(encoder.get_feature_names_out(cols)))
    importances = clf.feature_importances_
    ranked = sorted(
        [{"feature": n, "importance": float(v)} for n, v in zip(names, importances)],
        key=lambda d: d["importance"],
        reverse=True,
    )
    return ranked


def make_figures(df: pd.DataFrame, corrected: dict, corrected_art: dict, out_dir: Path) -> list[str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid", context="notebook")
    palette = ["#2f6f8f", "#c0392b"]
    files: list[str] = []

    # 1. Class distribution
    counts = df[TARGET].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(["Legitimate (0)", "Fraud (1)"], counts.values, color=palette)
    for i, v in enumerate(counts.values):
        ax.text(i, v, f"{v:,}\n({v / len(df):.2%})", ha="center", va="bottom", fontsize=10)
    ax.set_ylabel("Transactions")
    ax.set_title("Fraud versus legitimate transactions")
    ax.set_ylim(0, counts.max() * 1.18)
    fig.tight_layout()
    p = out_dir / "01_class_distribution.png"
    fig.savefig(p, dpi=200)
    plt.close(fig)
    files.append(p.name)

    # 2. Leakage diagnostic
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
    legit_age = df.loc[df[TARGET] == 0, "accountAgeDays"]
    fraud_age = df.loc[df[TARGET] == 1, "accountAgeDays"]
    axes[0].hist([legit_age, fraud_age], bins=30, label=["Legitimate", "Fraud"], color=palette)
    axes[0].set_xlabel("accountAgeDays")
    axes[0].set_ylabel("Count")
    axes[0].set_title("Account age by class: fraud is always 1 day")
    axes[0].legend()
    missing_rate = [
        df.loc[df[TARGET] == 0, "isWeekend"].isna().mean(),
        df.loc[df[TARGET] == 1, "isWeekend"].isna().mean(),
    ]
    axes[1].bar(["Legitimate", "Fraud"], missing_rate, color=palette)
    axes[1].set_ylim(0, 1.05)
    axes[1].set_ylabel("Share with isWeekend missing")
    axes[1].set_title("Weekend flag missingness by class")
    for i, v in enumerate(missing_rate):
        axes[1].text(i, v + 0.03, f"{v:.0%}", ha="center", fontsize=10)
    fig.tight_layout()
    p = out_dir / "02_leakage_diagnostic.png"
    fig.savefig(p, dpi=200)
    plt.close(fig)
    files.append(p.name)

    # 3. Transaction patterns
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    for label, colour in [(0, palette[0]), (1, palette[1])]:
        axes[0, 0].hist(
            df.loc[df[TARGET] == label, "localTime"],
            bins=25,
            alpha=0.65,
            label="Legitimate" if label == 0 else "Fraud",
            color=colour,
            density=True,
        )
    axes[0, 0].set_xlabel("localTime")
    axes[0, 0].set_ylabel("Density")
    axes[0, 0].set_title("Local transaction time by class")
    axes[0, 0].legend()

    log_age = np.log10(df["paymentMethodAgeDays"].clip(lower=0) + 0.001)
    for label, colour in [(0, palette[0]), (1, palette[1])]:
        axes[0, 1].hist(
            log_age[df[TARGET] == label],
            bins=25,
            alpha=0.65,
            label="Legitimate" if label == 0 else "Fraud",
            color=colour,
            density=True,
        )
    axes[0, 1].set_xlabel("log10(paymentMethodAgeDays + 0.001)")
    axes[0, 1].set_ylabel("Density")
    axes[0, 1].set_title("Payment method age by class")
    axes[0, 1].legend()

    for ax, col, title in [
        (axes[1, 0], "paymentMethod", "Fraud rate by payment method"),
        (axes[1, 1], "Category", "Fraud rate by category"),
    ]:
        series = df[col].fillna("Missing") if col == "Category" else df[col]
        rates = df.assign(_group=series).groupby("_group")[TARGET].mean().sort_values(ascending=False)
        ax.bar([str(x) for x in rates.index], rates.values * 100, color="#2f6f8f")
        ax.set_ylabel("Fraud rate (%)")
        ax.set_title(title)
        for i, v in enumerate(rates.values):
            ax.text(i, v * 100, f"{v:.2%}", ha="center", va="bottom", fontsize=9)
        ax.set_ylim(0, max(rates.values * 100) * 1.3 if len(rates) else 1)
    fig.tight_layout()
    p = out_dir / "03_transaction_patterns.png"
    fig.savefig(p, dpi=200)
    plt.close(fig)
    files.append(p.name)

    # 4. Model comparison (corrected)
    model_labels = {
        "logistic_regression": "Logistic Regression",
        "decision_tree": "Decision Tree",
        "random_forest": "Random Forest",
    }
    metric_keys = ["f1", "roc_auc", "pr_auc"]
    metric_labels = ["F1-score", "ROC-AUC", "PR-AUC"]
    x = np.arange(len(model_labels))
    width = 0.24
    fig, ax = plt.subplots(figsize=(9, 5))
    for i, (key, lab) in enumerate(zip(metric_keys, metric_labels)):
        vals = [corrected["models"][m][key] for m in model_labels]
        ax.bar(x + (i - 1) * width, vals, width=width, label=lab)
        for xi, v in zip(x + (i - 1) * width, vals):
            ax.text(xi, v + 0.015, f"{v:.3f}", ha="center", fontsize=8, rotation=0)
    ax.set_xticks(x)
    ax.set_xticklabels([model_labels[m] for m in model_labels])
    ax.set_ylim(0, 1.08)
    ax.set_ylabel("Score")
    ax.set_title("Model comparison, corrected features only (test set)")
    ax.legend()
    fig.tight_layout()
    p = out_dir / "04_model_comparison_corrected.png"
    fig.savefig(p, dpi=200)
    plt.close(fig)
    files.append(p.name)

    # 5. Feature importance (corrected random forest)
    importance = _feature_importance(corrected_art)
    if importance:
        top = importance[:12][::-1]
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.barh([d["feature"] for d in top], [d["importance"] for d in top], color="#2f6f8f")
        ax.set_xlabel("Random forest importance")
        ax.set_title("Feature importance, corrected random forest")
        fig.tight_layout()
        p = out_dir / "05_feature_importance.png"
        fig.savefig(p, dpi=200)
        plt.close(fig)
        files.append(p.name)

    # 6. Confusion matrices (corrected)
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2))
    for ax, (name, lab) in zip(axes, model_labels.items()):
        cm = confusion_matrix(corrected_art[name]["y_test"], corrected_art[name]["pred"], labels=[0, 1])
        sns.heatmap(
            cm,
            annot=True,
            fmt="d",
            cmap="Blues",
            ax=ax,
            xticklabels=["Pred. legitimate", "Pred. fraud"],
            yticklabels=["True legitimate", "True fraud"],
        )
        ax.set_title(lab)
    fig.suptitle("Confusion matrices, corrected features (test set)", y=1.02)
    fig.tight_layout()
    p = out_dir / "06_confusion_matrices.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    files.append(p.name)

    # 7. ROC and precision-recall curves (corrected)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.8))
    for name, lab in model_labels.items():
        y_test = corrected_art[name]["y_test"]
        prob = corrected_art[name]["prob"]
        fpr, tpr, _ = roc_curve(y_test, prob)
        axes[0].plot(fpr, tpr, label=f"{lab} (AUC {corrected['models'][name]['roc_auc']:.3f})")
        prec, rec, _ = precision_recall_curve(y_test, prob)
        axes[1].plot(rec, prec, label=f"{lab} (AP {corrected['models'][name]['pr_auc']:.3f})")
    axes[0].plot([0, 1], [0, 1], linestyle="--", color="grey", linewidth=1)
    axes[0].set_xlabel("False positive rate")
    axes[0].set_ylabel("True positive rate")
    axes[0].set_title("ROC curves, corrected")
    axes[0].legend(fontsize=8)
    axes[1].set_xlabel("Recall")
    axes[1].set_ylabel("Precision")
    axes[1].set_title("Precision-recall curves, corrected")
    axes[1].legend(fontsize=8)
    fig.tight_layout()
    p = out_dir / "07_roc_pr_curves.png"
    fig.savefig(p, dpi=200)
    plt.close(fig)
    files.append(p.name)

    return files


def _fmt(x: float) -> str:
    return f"{x:.4f}"


def write_case_study(results: dict, path: Path) -> None:
    audit = results["dataset_audit"]
    dist = audit["class_distribution"]
    as_found = results["scenarios"]["as_found_all_features"]["models"]
    corrected = results["scenarios"]["corrected_primary"]["models"]
    sens = results["scenarios"]["sensitivity_without_payment_method_age"]["models"]

    def row(name: str, m: dict) -> str:
        return (
            f"| {name} | {_fmt(m['accuracy'])} | {_fmt(m['precision'])} | "
            f"{_fmt(m['recall'])} | {_fmt(m['f1'])} | {_fmt(m['roc_auc'])} | {_fmt(m['pr_auc'])} |"
        )

    lines = [
        "# Machine Learning for Transaction Fraud Analysis",
        "",
        "Portfolio case study. All figures below come from `outputs/results.json`, "
        "generated by running `python -m src.fraud_analysis` on the verified Kaggle file.",
        "",
        "## Dataset",
        "",
        f"- Source: Kaggle, Payment Fraud - Empowering Financial Security, by Younus Mohamed: {DATASET_SOURCE}",
        f"- Reference repository that pointed to this dataset: {REFERENCE_REPO}",
        "- File used: `payment_fraud.csv`, downloaded from the Kaggle dataset API endpoint without using any credentials.",
        f"- Verified records: {audit['records']:,} rows and {len(audit['columns'])} columns. "
        "The Kaggle dataset card states 38,662 rows, which does not match the CSV. The CSV count is used here.",
        "- License: the Kaggle page sidebar lists CC BY-NC-SA 4.0, while the README inside the "
        "download lists CC BY-SA 4.0. This project follows the more restrictive CC BY-NC-SA 4.0 "
        "terms, gives attribution, and does not redistribute the raw CSV.",
        "- The reference repository has no licence file, so none of its code was copied. "
        "This implementation was written independently.",
        "- Is it synthetic? The uploader does not document the data as synthetic and gives no "
        "collection method or citation. The file itself shows strong signs of artificial "
        "generation or augmentation: fraud rows follow exact rules (see Leakage findings), "
        "`localTime` takes only 25 distinct values, and many rows are exact duplicates. "
        "It should not be described as real transaction data. An earlier six-column version of "
        "`payment_fraud.csv` circulated in online tutorials from 2020, and the Kaggle version adds "
        "`Category` and `isWeekend` columns.",
        "",
        "## Class distribution",
        "",
        f"- Legitimate (0): {dist['legitimate_0']:,} ({dist['legitimate_rate']:.2%})",
        f"- Fraud (1): {dist['fraud_1']:,} ({dist['fraud_rate']:.2%})",
        "- Accuracy alone is misleading at this prevalence. A model that labels every row "
        "legitimate scores about 98.57 percent accuracy and detects no fraud.",
        "",
        "## Data quality and leakage findings",
        "",
    ]
    for finding in results["leakage_findings"]:
        lines.append(f"- {finding}")
    lines += [
        f"- Missing values: Category {audit['missing_values']['Category']}, "
        f"isWeekend {audit['missing_values']['isWeekend']}, all other columns 0.",
        f"- Exact duplicate rows beyond the first copy: {audit['exact_duplicate_rows_extra_copies']:,}. "
        f"Unique rows: {audit['unique_rows']:,}.",
        "- Method problems in the reference notebook, corrected here: the scaler was fitted on "
        "the full dataset before the split, categorical encoding reused one encoder object, "
        "missing values were filled before splitting, and no ROC-AUC, PR-AUC, or confusion "
        "matrices were reported. Those issues are secondary. Even with a clean pipeline, the "
        "tree models score perfectly because the leakage is in the columns themselves.",
        "",
        "## Method",
        "",
        "- Stratified 80/20 train and test split, random state 42.",
        "- All imputation, one-hot encoding, and scaling are fitted inside scikit-learn "
        "pipelines on training data only.",
        "- Models: logistic regression, decision tree, and random forest, each with "
        "class_weight set to balanced because fraud is only 1.43 percent of rows. "
        "The decision threshold is the default 0.5 throughout.",
        "- As-found run: all seven predictors, no deduplication. This replicates the "
        "reference setup with cleaner preprocessing and is diagnostic only.",
        "- Corrected run: `accountAgeDays` and `isWeekend` removed, exact duplicate rows "
        "dropped before the split. This is the result that should be quoted.",
        "- Sensitivity run: `paymentMethodAgeDays` also removed, to test how much of the "
        "remaining signal depends on that one column.",
        "",
        "## Results: as-found run (diagnostic only, do not quote as performance)",
        "",
        "| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC |",
        "|---|---|---|---|---|---|---|",
        row("Logistic Regression", as_found["logistic_regression"]),
        row("Decision Tree", as_found["decision_tree"]),
        row("Random Forest", as_found["random_forest"]),
        "",
        "The perfect decision tree and random forest scores are an artefact of the two "
        "leakage columns above. Publishing them as fraud detection performance would be misleading.",
        "",
        "## Results: corrected run (the defensible result)",
        "",
        "| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC |",
        "|---|---|---|---|---|---|---|",
        row("Logistic Regression", corrected["logistic_regression"]),
        row("Decision Tree", corrected["decision_tree"]),
        row("Random Forest", corrected["random_forest"]),
        "",
        "## Results: sensitivity run without paymentMethodAgeDays",
        "",
        "| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC |",
        "|---|---|---|---|---|---|---|",
        row("Logistic Regression", sens["logistic_regression"]),
        row("Decision Tree", sens["decision_tree"]),
        row("Random Forest", sens["random_forest"]),
        "",
        "## Findings",
        "",
        "- Once the two artefactual columns are removed and exact duplicates are dropped, no "
        "model provides useful fraud detection at the default threshold. The best corrected "
        "F1-score is 0.0428 (logistic regression). The decision tree and random forest rank "
        "cases close to chance in the corrected run (ROC-AUC 0.4704 and 0.5216).",
        "- Deduplication matters here: 164 of the 560 fraud rows are exact copies of other "
        "fraud rows, leaving 396 unique fraud rows. Keeping duplicates would let the same "
        "rows appear in both train and test sets and would flatter the tree models.",
        "- Logistic regression ranks cases better than the trees on ROC-AUC in the corrected "
        "run (0.8058), but its precision at the default threshold is 0.0220, so most of its "
        "fraud alerts are false alarms. Removing `paymentMethodAgeDays` lowers its ROC-AUC "
        "to 0.6477, which shows that much of its ranking signal comes from that one column. "
        "The random forest still assigns that column the highest importance in the corrected "
        "run, yet its overall ranking is close to chance, so importance alone is not evidence "
        "of useful performance.",
        "- In practical terms, this dataset cannot support claims about detecting real payment "
        "fraud. Its value for a portfolio is the opposite: it shows why leakage checks, "
        "duplicate checks, and scepticism about perfect scores have to come before modelling.",
        "",
        "## Limitations",
        "",
        "- Provenance is weak: no documented collection method, no citation, a row count that "
        "does not match the dataset card, and inconsistent licence statements on the Kaggle page.",
        "- The fraud rows appear to have been generated by simple rules, so model scores do not "
        "transfer to real payment systems.",
        "- Only seven predictors are available. There is no transaction amount, no merchant or "
        "account history, and no time ordering, so no temporal validation was possible.",
        "- A single stratified split was used. Results would vary with other splits, and no "
        "hyperparameter tuning was done, by design, to keep the comparison simple.",
        "- The corrected run should be read as a leakage and data quality study with baseline "
        "models, not as a deployable fraud detector.",
        "",
        "## Reproduction",
        "",
        "```bash",
        "pip install -r requirements.txt",
        "python -m src.download_data",
        "python -m src.fraud_analysis",
        "python -m pytest tests/ -q",
        "```",
        "",
        "Raw transaction-level data are excluded from the source ZIP and from version control.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(data_path: str | Path, output_dir: str | Path) -> dict:
    output_dir = Path(output_dir)
    figures_dir = output_dir / "figures"
    output_dir.mkdir(parents=True, exist_ok=True)

    df = load_data(data_path)
    audit = audit_data(df)

    as_found, _ = evaluate_scenario(df, ALL_FEATURES, drop_exact_duplicates=False)
    corrected, corrected_art = evaluate_scenario(
        df, CORRECTED_FEATURES, drop_exact_duplicates=True
    )
    sensitivity, _ = evaluate_scenario(
        df, SENSITIVITY_FEATURES, drop_exact_duplicates=True
    )

    figure_files = make_figures(df, corrected, corrected_art, figures_dir)
    importance = _feature_importance(corrected_art)

    results = {
        "project": "Machine Learning for Transaction Fraud Analysis",
        "dataset": {
            "source_url": DATASET_SOURCE,
            "reference_repository": REFERENCE_REPO,
            "file": Path(data_path).name,
            "licence_note": (
                "Kaggle page sidebar: CC BY-NC-SA 4.0. README inside download: CC BY-SA 4.0. "
                "More restrictive terms followed. Raw data not redistributed."
            ),
            "kaggle_card_claimed_rows": 38662,
            "verified_rows": audit["records"],
            "synthetic_assessment": (
                "Not documented as synthetic by the uploader, but internal evidence "
                "(exact fraud generation rules, 25 distinct localTime values, many exact "
                "duplicates) indicates artificial generation or augmentation."
            ),
        },
        "random_state": RANDOM_STATE,
        "test_size": 0.2,
        "dataset_audit": audit,
        "leakage_findings": leakage_findings(audit),
        "scenarios": {
            "as_found_all_features": as_found,
            "corrected_primary": corrected,
            "sensitivity_without_payment_method_age": sensitivity,
        },
        "corrected_random_forest_feature_importance": importance,
        "figures": [f"outputs/figures/{name}" for name in figure_files],
        "limitations": [
            "Fraud rows follow exact generation rules, so scores do not transfer to real payments.",
            "Dataset provenance, row count, and licence statements are inconsistent on Kaggle.",
            "No transaction amount, history, or time ordering is available.",
            "Single stratified split, default 0.5 threshold, no hyperparameter tuning.",
        ],
    }

    (output_dir / "results.json").write_text(
        json.dumps(results, indent=2), encoding="utf-8"
    )
    write_case_study(results, output_dir / "portfolio-case-study.md")
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default="data/raw/payment_fraud.csv")
    parser.add_argument("--output-dir", default="outputs")
    args = parser.parse_args()
    results = run(args.data, args.output_dir)
    corrected = results["scenarios"]["corrected_primary"]["models"]
    print("Pipeline complete.")
    print(f"Records: {results['dataset_audit']['records']:,}")
    for name, m in corrected.items():
        print(
            f"Corrected {name}: F1={m['f1']:.4f} ROC-AUC={m['roc_auc']:.4f} "
            f"PR-AUC={m['pr_auc']:.4f} precision={m['precision']:.4f} recall={m['recall']:.4f}"
        )
    print("Wrote outputs/results.json, outputs/portfolio-case-study.md, outputs/figures/")


if __name__ == "__main__":
    main()
