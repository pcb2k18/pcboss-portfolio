"""Automated tests for the fraud analysis pipeline.

Tests use a small synthetic fixture built in code, so they run without the
raw Kaggle file and without any transaction-level data.
"""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest

from src.fraud_analysis import (
    ALL_FEATURES,
    CORRECTED_FEATURES,
    LEAKAGE_FEATURES,
    audit_data,
    build_pipeline,
    evaluate_scenario,
    leakage_findings,
    load_data,
)


def make_fixture() -> pd.DataFrame:
    rng = np.random.default_rng(42)
    n_legit = 400
    n_fraud = 20
    legit = pd.DataFrame(
        {
            "accountAgeDays": rng.integers(2, 2000, size=n_legit),
            "numItems": rng.integers(1, 5, size=n_legit),
            "localTime": rng.uniform(0.5, 5.0, size=n_legit),
            "paymentMethod": rng.choice(["creditcard", "paypal", "storecredit"], size=n_legit),
            "paymentMethodAgeDays": rng.uniform(0, 1000, size=n_legit),
            "Category": rng.choice(["shopping", "food", "electronics"], size=n_legit),
            "isWeekend": rng.choice([0.0, 1.0], size=n_legit),
            "label": 0,
        }
    )
    fraud = pd.DataFrame(
        {
            "accountAgeDays": 1,
            "numItems": rng.integers(1, 5, size=n_fraud),
            "localTime": rng.uniform(2.5, 5.0, size=n_fraud),
            "paymentMethod": rng.choice(["creditcard", "paypal"], size=n_fraud),
            "paymentMethodAgeDays": rng.uniform(0, 0.5, size=n_fraud),
            "Category": rng.choice(["shopping", "food", "electronics"], size=n_fraud),
            "isWeekend": np.nan,
            "label": 1,
        }
    )
    df = pd.concat([legit, fraud], ignore_index=True)
    # Add one exact duplicate row to test duplicate counting.
    df = pd.concat([df, df.iloc[[0]]], ignore_index=True)
    return df.sample(frac=1.0, random_state=42).reset_index(drop=True)


def test_audit_counts_and_class_distribution():
    df = make_fixture()
    audit = audit_data(df)
    assert audit["records"] == len(df)
    assert audit["class_distribution"]["fraud_1"] == 20
    assert audit["class_distribution"]["legitimate_0"] == 401
    assert audit["exact_duplicate_rows_extra_copies"] == 1


def test_audit_detects_leakage_columns():
    df = make_fixture()
    audit = audit_data(df)
    assert "accountAgeDays" in audit["perfect_numeric_separators"]
    assert audit["missing_by_label"]["isWeekend"]["fraud_missing_rate"] == 1.0
    assert audit["missing_by_label"]["isWeekend"]["legitimate_missing_rate"] == 0.0
    findings = leakage_findings(audit)
    joined = " ".join(findings)
    assert "isWeekend" in joined
    assert "accountAgeDays" in joined


def test_corrected_features_exclude_leakage():
    for col in LEAKAGE_FEATURES:
        assert col not in CORRECTED_FEATURES
    assert set(CORRECTED_FEATURES).issubset(set(ALL_FEATURES))


def test_pipeline_trains_and_metrics_are_valid():
    df = make_fixture()
    scenario, _ = evaluate_scenario(df, CORRECTED_FEATURES, drop_exact_duplicates=True)
    for model in ["logistic_regression", "decision_tree", "random_forest"]:
        m = scenario["models"][model]
        for key in ["accuracy", "precision", "recall", "f1", "roc_auc", "pr_auc"]:
            assert 0.0 <= m[key] <= 1.0
        cm = m["confusion_matrix"]
        total = cm["tn"] + cm["fp"] + cm["fn"] + cm["tp"]
        assert total == scenario["test_rows"] if "test_rows" in scenario else total > 0
        assert cm["tp"] + cm["fn"] == m["test_support_fraud"]


def test_as_found_trees_can_separate_fixture():
    # On the fixture the leakage columns separate the classes by construction.
    # The point of the test is to confirm the pipeline exposes that artefact.
    df = make_fixture()
    scenario, _ = evaluate_scenario(df, ALL_FEATURES, drop_exact_duplicates=True)
    assert scenario["models"]["decision_tree"]["accuracy"] >= 0.95


def test_build_pipeline_rejects_unknown_model():
    with pytest.raises(ValueError):
        build_pipeline("not_a_model", ["numItems"], ["paymentMethod"])


def test_load_data_validates_columns(tmp_path):
    bad = tmp_path / "bad.csv"
    pd.DataFrame({"a": [1]}).to_csv(bad, index=False)
    with pytest.raises(ValueError):
        load_data(bad)


def test_results_are_json_serialisable():
    df = make_fixture()
    audit = audit_data(df)
    text = json.dumps({"audit": audit, "findings": leakage_findings(audit)})
    assert "accountAgeDays" in text
